# Room Database keep rules
-keep class * extends androidx.room.RoomDatabase
-keep class * {
    @androidx.room.PrimaryKey *;
    @androidx.room.ColumnInfo *;
}
-keep interface * {
    @androidx.room.Dao *;
}
-dontwarn androidx.room.paging.**

# Keep our data model classes for safety
-keep class com.example.data.** { *; }

# Moshi and Retrofit Rules
-keep class com.squareup.moshi.** { *; }
-keep interface com.squareup.moshi.** { *; }
-dontwarn com.squareup.moshi.**

-keep class retrofit2.** { *; }
-dontwarn retrofit2.**
-keepclassmembers class * {
    @retrofit2.http.* <methods>;
}
