package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.YaftaErpDatabase
import com.example.data.YaftaRepository
import com.example.ui.YaftaMainApp
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.YaftaViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val database = YaftaErpDatabase.getDatabase(applicationContext)
    val viewModel = YaftaViewModel(application)

    setContent {
      MyApplicationTheme {
        YaftaMainApp(viewModel)
      }
    }
  }
}

