package com.example.ui

object Translations {
    private val arMap = mapOf(
        "app_title" to "يافطة للدعاية والإعلان",
        "app_subtitle" to "نظام الإدارة المتكامل واستوديو التصميم الذكي",
        "role_label" to "صلاحية الحساب الحالي:",
        "lang_toggle" to "Change Language",
        
        // Modules
        "dashboard" to "لوحة القيادة",
        "customers" to "العملاء",
        "quotations" to "عروض الأسعار",
        "projects" to "المشاريع",
        "design_dept" to "إدارة التصميم",
        "production" to "ورش الإنتاج",
        "installation" to "التركيبات والموقع",
        "inventory" to "المخازن والمستودعات",
        "suppliers" to "الموردين",
        "finance" to "الحسابات والمالية",
        "staff" to "شؤون الموظفين",
        "studio" to "استوديو يافطة",
        "settings" to "الإعدادات والخيارات",
        
        // Login & Onboarding
        "login_welcome" to "أهلاً بك في نظام يافطة",
        "login_tag" to "منصة إدارة المؤسسة وتصميم اللافتات المتكاملة",
        "email_placeholder" to "البريد الإلكتروني",
        "pass_placeholder" to "كلمة المرور",
        "btn_login" to "تسجيل دخول آمن",
        "bypass_login" to "دخول سريع وتخطي",
        "choose_role" to "اختر دور للدخول والتجربة:",
        "forgot_password" to "هل نسيت كلمة المرور؟ لاسترداد الحساب تواصل مع الإدارة.",
        "welcome_back" to "مرحباً بك، تصفح البيانات الفعلية للنظام",
        
        // Smart Calculations
        "smart_calculator" to "الآلة الحاسبة الذكية لليافطات",
        "length" to "الارتفاع / الطول (بالمتر)",
        "width" to "العرض (بالمتر)",
        "area" to "المساحة الإجمالية",
        "mat_cost" to "تكلفة المواد المستهلكة",
        "lab_cost" to "تكلفة اليد العاملة والتشغيل",
        "prod_cost" to "تكلفة التصنيع الإجمالية",
        "selling_price" to "سعر البيع النهائي للمستهلك",
        "profit" to "صافي الربح المتوقع",
        "profit_margin" to "هامش الربح التجاري",
        "calc_placeholder" to "أدخل القياسات للحساب الآلي الفوري بالجنيه المصري EGP",
        "egp" to "ج.م",
        "convert_btn" to "تحويل لعقد مشروع وفاتورة",
        
        // Dashboard Stats
        "kpi_revenue" to "إيرادات المبيعات الكلية",
        "kpi_expenses" to "المصروفات والأجور الكلية",
        "kpi_profit" to "الأرباح التشغيلية الصافية",
        "kpi_projects" to "المشاريع قيد التشغيل",
        "kpi_customers" to "إجمالي عملاء المؤسسة",
        "kpi_alerts" to "أخطار نقص المخازن",
        "chart_title" to "مقارنة الدخل الشهري والمصروفات بالجنيه المصري",
        "recent_logs" to "سجل العمليات الأخير بالنظام",
        
        // Customer fields
        "cust_name" to "اسم العميل / الشركة",
        "cust_phone" to "الهاتف الجوال",
        "cust_whatsapp" to "رقم الواتساب الرسمي",
        "cust_email" to "البريد الإلكتروني",
        "cust_address" to "العنوان الجغرافي بالتفصيل",
        "cust_notes" to "ملاحظات وتفاصيل المعاينة والموقع",
        "add_cust" to "إضافة بطاقة عميل جديدة",
        "save_cust" to "حفظ العميل لقاعدة البيانات",
        "contact_actions" to "اتصالات سريعة مع العميل",
        
        // Quotation generator
        "qtn_list" to "عروض الأسعار المعتمدة قيد الانتظار",
        "qtn_no" to "رقم العرض الآلي",
        "qtn_new" to "عرض سعر تفصيلي جديد",
        "notes" to "وصف ومواصفات اليافطة المطلوب تسعيرها",
        "save_qtn" to "توليد وحفظ عرض السعر",
        
        // Projects & Design
        "proj_title" to "بطاقة تتبع وضمان المشاريع",
        "proj_status" to "الحالة التشغيلية",
        "proj_files" to "ملفات التصاميم المحملة بمستودع المشروع",
        "add_file" to "تحميل مسودة تصميم تفصيلي",
        "file_name_title" to "عنوان مسودة التصميم",
        "file_path_stub" to "رابط/مسار ملف التصوير",
        "file_notes" to "تعليمات العميل وتعديلاته المطلوبة",
        "upload" to "رفع وتأكيد الملف",
        "approve" to "اعتماد وقبول التصميم",
        "reject" to "رفض وإعادة العمل",
        
        // Production
        "prod_title" to "قسم الإنتاج والتصنيع الفعلي",
        "prod_jobs" to "أوامر تشغيل ورش التصنيع",
        "cost_breakdown" to "توزيع التكاليف والأرباح المستهدفة",
        "mark_complete" to "إنهاء وتأكيد التصنيع",
        
        // Installation
        "install_title" to "قسم التركيبات والتقرير الميداني",
        "install_jobs" to "أوامر جدولة فرق التركيب الخارجي",
        "team_assigned" to "الفريق المكلف بالتركيب",
        "before_photo" to "صورة الموقع قبل التركيب",
        "after_photo" to "صورة الموقع بعد التركيب والتشغيل",
        "signature_box" to "التوقيع الحي للعميل تأكيداً للاستلام والرضا",
        "signature_clear" to "مسح التوقيع والبدء مجدداً",
        "gps_mock" to "تتبع الموقع الجغرافي للتركيب",
        "gps_btn" to "جلب إحداثيات GPS المعاينة الحالية",
        "record_field" to "تسجيل وإغلاق طلب الموقع الميداني",
        "take_pic" to "التقط صورة محاكاة",
        
        // Inventory
        "warehouse_materials" to "مخزون الخامات وألواح الكلادينج والمقاطع",
        "add_inv" to "قيد مادة جديدة بمخزن الخامات العامة",
        "mat_name" to "اسم الخامة البرية",
        "warehouse" to "اسم المخزن التابع",
        "barcode" to "الباركود والرمز التعريفي الكودي",
        "low_alert" to "حد الطلب والتنبيه الحرج",
        "unit" to "وحدة التخزين القياسية",
        "save_material" to "إيداع الخامة بالمستودع",
        
        // Suppliers
        "supplier_management" to "ملفات وحسابات الموردين والشركاء",
        "balance_owed" to "الرصيد المستحق للمورد",
        "phone" to "رقم الهواتف",
        "add_sup" to "تسجيل مورد تجاري جديد",
        
        // Finance
        "accounting_pnl" to "قائمة الأرباح والخسائر والمصروفات العامة",
        "vat_pnl" to "تقرير ضريبة القيمة المضافة ومستحقات الدولة",
        "add_exp" to "قيد قسيمة مصروف عاجل",
        "exp_title" to "عنوان القسيمة / الغرض",
        "exp_cat" to "التصنيف المالي للمصروف",
        "exp_amount" to "القيمة المالية المدفوعة",
        "save_exp" to "ترحيل المصروف للحسابات العامة",
        "invoice_list" to "سجل الفواتير التحصيلية الصادرة للعملاء",
        "invoice_no" to "رقم الفاتورة المعتمد",
        "payment_record" to "تحصيل دفعة نقدية وسداد عجز الفاتورة",
        "pay_amount" to "القيمة التي يسددها العميل حالياً",
        "pay_method" to "طريقة التحصيل المعتمدة",
        "pay_confirm" to "ترحيل السداد وتعديل ميزان العميل",
        
        // Staff
        "staff_title" to "سجلات الحضور والغياب وأجور العاملين",
        "add_worker" to "قيد ملف تعيين عامل جديد بالورشة أو المكتب",
        "salary_month" to "الراتب الشهري الأساسي المتفق عليه",
        "mark_present" to "إثبات وتأكيد الحضور لليوم لحساب المكافآت",
        
        // Creative Editor Design Studio keys
        "editor_layers" to "لوحة التحكم وإدارة طبقات التصوير (Layers)",
        "editor_canvas" to "لوحة الكانفاس التفاعلية والتصميم الإبداعي",
        "btn_add_text" to "إدراج نص حر",
        "btn_add_shape" to "إدراج مجسم صلب",
        "font_arabic" to "اختر الخط العربي المميز",
        "font_english" to "English Fonts Spec",
        "fx_panel" to "معدل الألوان وتأثيرات فوتوشوب (FX)",
        "illustrator_curves" to "قسم منحنيات بيزير والخط المتجه الحر",
        "export_cmyk" to "إعدادات المخرجات والمطابع والفرز اللوني CMYK",
        "smart_asset_provider" to "مستودع الأصول والصور الإبداعية المجاني",
        "search_assets" to "بحث في مكتبات Stocks و vectors",
        "font_recognizer" to "ماكينة الذكاء الاصطناعي للتعرف على الخطوط من الصورة",
        "templates_desc" to "قوالب السوشيال ميديا والمطبوعات الإعلانية الفورية",
        "ai_tools_desc" to "أدوات الذكاء الاصطناعي والتحليل الذكي والبوسترات الموجهة",
        "btn_generate_image" to "توليد صورة خلفية إعلانية إبداعية",
        "bleed_line" to "تأكيد خطوط Bleed ومساحة القصاصات الآمنة",
        "export_btn_studio" to "تصدير الملف المائي النهائي للعميل",
        "font_upload_text" to "ارفع عينة صورة للتعرف التلقائي على الخط وتوجيهك لتحميله",
        "font_result" to "النتيجة: خط تجوال متطابق بنسبة 96% ومقدم من Google Fonts"
    )

    private val enMap = mapOf(
        "app_title" to "Yafita for Advertising",
        "app_subtitle" to "Integrated Enterprise Platform & Smart Design Studio",
        "role_label" to "Current Account Role Status:",
        "lang_toggle" to "تغيير للعربية (RTL)",
        
        // Modules
        "dashboard" to "Dashboard",
        "customers" to "Customers",
        "quotations" to "Quotations",
        "projects" to "Projects",
        "design_dept" to "Design Department",
        "production" to "Production Division",
        "installation" to "Installations & Site",
        "inventory" to "Warehouse Inventory",
        "suppliers" to "Suppliers Ledger",
        "finance" to "Finance & Accounts",
        "staff" to "Workforce Management",
        "studio" to "Yafta Studio",
        "settings" to "Settings & Preferences",
        
        // Login & Onboarding
        "login_welcome" to "Welcome to Yafta ERP",
        "login_tag" to "The ultimate advertising corporate management & canvas design studio",
        "email_placeholder" to "E-mail Address",
        "pass_placeholder" to "Secure Password",
        "btn_login" to "Secure Corporate Login",
        "bypass_login" to "Quick Bypass Login",
        "choose_role" to "Select simulation role to launch:",
        "forgot_password" to "Forgot your password? Please contact management for recovery helper.",
        "welcome_back" to "Welcome back, browsing live enterprise database records...",
        
        // Smart Calculations
        "smart_calculator" to "Smart Signage Pricing Estimator",
        "length" to "Height / Length (meters)",
        "width" to "Width (meters)",
        "area" to "Total Surface Area",
        "mat_cost" to "Raw Material Consumed",
        "lab_cost" to "Labor & Processing Costs",
        "prod_cost" to "Total Production Cost",
        "selling_price" to "Consumer Selling Price",
        "profit" to "Estimated Net Profit",
        "profit_margin" to "Profit Margin %",
        "calc_placeholder" to "Enter dimensions for instant real-time pricing equations below in EGP",
        "egp" to "EGP",
        "convert_btn" to "Convert To Production Project & Invoice",
        
        // Dashboard Stats
        "kpi_revenue" to "Cumulative Sales Revenues",
        "kpi_expenses" to "Cumulative Staff Salaries & Expenses",
        "kpi_profit" to "Net Operations Profits",
        "kpi_projects" to "Active Ongoing Projects",
        "kpi_customers" to "Total Corporate Clients",
        "kpi_alerts" to "Stock Depletion Warnings",
        "chart_title" to "Monthly Net Revenue vs Operating Expenses comparison (EGP)",
        "recent_logs" to "Recent Event Core Audit Trail",
        
        // Customer fields
        "cust_name" to "Company / Customer Name",
        "cust_phone" to "Mobile Phone",
        "cust_whatsapp" to "Official WhatsApp",
        "cust_email" to "E-mail Address",
        "cust_address" to "Physical Delivery Address",
        "cust_notes" to "Site Survey Measurements and Notes",
        "add_cust" to "Registers New Client Profile",
        "save_cust" to "Commit Card to Local DB",
        "contact_actions" to "Instant Client Communications",
        
        // Quotation generator
        "qtn_list" to "Verified Pending Quotations",
        "qtn_no" to "System Auto Number",
        "qtn_new" to "Create Technical Quotation",
        "notes" to "Physical Description & Materials specifications",
        "save_qtn" to "Generate & Save Estimate",
        
        // Projects & Design
        "proj_title" to "Active Order & Progress Tracker",
        "proj_status" to "Operations Status",
        "proj_files" to "Design Files Library",
        "add_file" to "Upload Design Conceptual Draft",
        "file_name_title" to "Design Draft Name",
        "file_path_stub" to "Conceptual Draft Uri/Path",
        "file_notes" to "Client Guidelines and Adjustments",
        "upload" to "Verify and Store Draft",
        "approve" to "Approve Design",
        "reject" to "Resubmit to Designer",
        
        // Production
        "prod_title" to "Signage Production Department",
        "prod_jobs" to "Active Production Orders",
        "cost_breakdown" to "Revenue vs Material Cost breakdown",
        "mark_complete" to "Complete Signs Production",
        
        // Installation
        "install_title" to "Field Installations Department",
        "install_jobs" to "On-site Installation Schedules",
        "team_assigned" to "Allocated Field Crew",
        "before_photo" to "On-site site view before installation",
        "after_photo" to "Polished signs view after installation",
        "signature_box" to "Customer Live Signature Approval",
        "signature_clear" to "Wipe drawing, sign again",
        "gps_mock" to "Field Location Geolocation Check",
        "gps_btn" to "Fetch Live GPS Koordinaten",
        "record_field" to "Commit Installation & Archive Schedule",
        "take_pic" to "Snap Simulation Camera Frame",
        
        // Inventory
        "warehouse_materials" to "Stocks, Metal sheets, and LED inventory",
        "add_inv" to "Registers Material item in Central warehouse",
        "mat_name" to "Material Description",
        "warehouse" to "Target Warehouse Section",
        "barcode" to "Barcode & Product identifier",
        "low_alert" to "Low Stock Thresh limit warning",
        "unit" to "Standard Packaging Unit",
        "save_material" to "Deposit Raw Item to warehouse",
        
        // Suppliers
        "supplier_management" to "Suppliers Portfolio & Ledgers",
        "balance_owed" to "Balance Owed to Supplier",
        "phone" to "Mobile Phone",
        "add_sup" to "Registers Commercial Supplier",
        
        // Finance
        "accounting_pnl" to "General Corporate Profit & Loss Summary",
        "vat_pnl" to "Corporate VAT 14% Taxes accounting audits",
        "add_exp" to "Post Urgent General Expense Voucher",
        "exp_title" to "Voucher Description / Purpose",
        "exp_cat" to "Bookkeeping Account Category",
        "exp_amount" to "Financial value paid",
        "save_exp" to "Commit expense transaction to Ledger",
        "invoice_list" to "Sells Invoices Ledger",
        "invoice_no" to "Invoice Number",
        "payment_record" to "Collect Payment for Outstanding Balance",
        "pay_amount" to "Amount paid by client currently",
        "pay_method" to "Collection channel",
        "pay_confirm" to "Post Payment & Update Balances",
        
        // Staff
        "staff_title" to "Workforce Roster, Attendance & Salaries",
        "add_worker" to "Registers worker file to Payroll databases",
        "salary_month" to "Agreed basic target monthly wage",
        "mark_present" to "Verify Attendance for today to accumulate wages",
        
        // Creative Editor Design Studio keys
        "editor_layers" to "Studio design layers management (Layers)",
        "editor_canvas" to "Creative Design Canvas workspace",
        "btn_add_text" to "Insert Text Layer",
        "btn_add_shape" to "Insert Geometry block",
        "font_arabic" to "Premium Arabic Fonts",
        "font_english" to "Premium English Fonts",
        "fx_panel" to "Shader Color, Brightness & Saturation FX Studio",
        "illustrator_curves" to "Bezier Shapes & Freehand Vector paths",
        "export_cmyk" to "DPI validation, Safe zones and print CMYK settings",
        "smart_asset_provider" to "Creative assets and photos search catalog",
        "search_assets" to "Search free Stocks and premium icons",
        "font_recognizer" to "Machine Learning Font Recognition engine",
        "templates_desc" to "Fast Marketing Social Media & Banner templates",
        "ai_tools_desc" to "Artificial Intelligence generative tools & posters",
        "btn_generate_image" to "Create Creative Poster backdrop with AI",
        "bleed_line" to "Verify 5mm Bleed lines & safe printing borders",
        "export_btn_studio" to "Export final draft with proof watermark",
        "font_upload_text" to "Drag and drop standard billboard clip to trace font name",
        "font_result" to "Trace Result: Tajawal Sans-Serif font detected (96% Google Fonts)"
    )

    fun get(key: String, lang: String): String {
        return if (lang == "ar") {
            arMap[key] ?: (enMap[key] ?: key)
        } else {
            enMap[key] ?: (arMap[key] ?: key)
        }
    }
}
