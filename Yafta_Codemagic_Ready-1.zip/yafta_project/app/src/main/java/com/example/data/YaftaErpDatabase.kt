package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        User::class,
        CustomRole::class,
        Customer::class,
        Quotation::class,
        QuotationItem::class,
        Project::class,
        DesignFile::class,
        ProductionJob::class,
        InstallationJob::class,
        InventoryItem::class,
        Supplier::class,
        Invoice::class,
        Payment::class,
        Expense::class,
        Employee::class,
        Notification::class,
        ActivityLog::class,
        AttachmentModel::class
    ],
    version = 3,
    exportSchema = false
)
abstract class YaftaErpDatabase : RoomDatabase() {
    abstract fun yaftaErpDao(): YaftaErpDao

    companion object {
        @Volatile
        private var INSTANCE: YaftaErpDatabase? = null

        fun getDatabase(context: Context): YaftaErpDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    YaftaErpDatabase::class.java,
                    "yafta_erp_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
