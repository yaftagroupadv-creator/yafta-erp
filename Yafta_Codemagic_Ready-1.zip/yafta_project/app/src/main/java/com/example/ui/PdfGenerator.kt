package com.example.ui

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.Customer
import com.example.data.Project
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfGenerator {

    fun generateAndShareInvoicePdf(
        context: Context,
        customer: Customer,
        projects: List<Project>
    ) {
        try {
            // 1. Initialize PdfDocument
            val pdfDocument = PdfDocument()
            
            // Standard A4 dimensions in points: 595 width x 842 height
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            val paint = Paint().apply { isAntiAlias = true }

            val colorGoldPrimary = Color.parseColor("#D4AF37")
            val colorGoldSecondary = Color.parseColor("#A67C1E")
            val colorCharcoalDark = Color.parseColor("#0D0D0D")
            val colorLightBackground = Color.parseColor("#FCFBF9")
            val colorAccentBorder = Color.parseColor("#E5DDD0")

            // 2. Draw Top Header Luxury Black Banner
            val topHeaderPaint = Paint().apply {
                color = Color.BLACK
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 0f, 595f, 130f, topHeaderPaint)

            // Draw Gold Accent Line under Top Banner
            val goldLinePaint = Paint().apply {
                color = colorGoldPrimary
                style = Paint.Style.STROKE
                strokeWidth = 3f
            }
            canvas.drawLine(0f, 130f, 595f, 130f, goldLinePaint)

            // 3. Draw Brand Logo strictly at the TOP-CENTER
            val sharedPrefs = context.getSharedPreferences("yafta_settings", Context.MODE_PRIVATE)
            val customLogoPath = sharedPrefs.getString("customLogoUri", "") ?: ""
            val logoFile = if (customLogoPath.isNotEmpty()) java.io.File(customLogoPath) else null

            val logoBitmap = if (logoFile != null && logoFile.exists()) {
                BitmapFactory.decodeFile(logoFile.absolutePath)
            } else {
                val logoResId = context.resources.getIdentifier("logo", "drawable", context.packageName)
                if (logoResId != 0) {
                    BitmapFactory.decodeResource(context.resources, logoResId)
                } else {
                    null
                }
            }

            if (logoBitmap != null) {
                val logoW = 86
                val logoH = 86
                val scaledLogo = Bitmap.createScaledBitmap(logoBitmap, logoW, logoH, true)
                canvas.drawBitmap(scaledLogo, 297.5f - (logoW / 2), 22f, paint)
            } else {
                // Draw luxury 3D-like gold typographic logo in top-center of the PDF
                val logoTitlePaint = Paint().apply {
                    color = colorGoldPrimary
                    textSize = 28f
                    typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                    isAntiAlias = true
                }
                
                // Draw YAFTA centered at X=297.5f, Y=56f
                canvas.drawText("YAFTA", 297.5f, 56f, logoTitlePaint)
                
                // Draw sweet gold crescent arc line under YAFTA
                val logoArcPaint = Paint().apply {
                    color = colorGoldSecondary
                    style = Paint.Style.STROKE
                    strokeWidth = 2f
                    isAntiAlias = true
                }
                val arcPath = android.graphics.Path().apply {
                    moveTo(247.5f, 68f)
                    quadTo(297.5f, 76f, 347.5f, 68f)
                }
                canvas.drawPath(arcPath, logoArcPaint)
                
                // Draw "للدعاية والإعلان" centered below the arc
                val logoSubPaint = Paint().apply {
                    color = colorGoldPrimary
                    textSize = 12f
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                    isAntiAlias = true
                }
                canvas.drawText("للدعاية والإعلان", 297.5f, 92f, logoSubPaint)
            }

            // Draw header textual details on left and right inside black top banner
            val sideTextPaint = Paint().apply {
                color = Color.WHITE
                textSize = 10f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
            canvas.drawText("YAFTA FOR ADVERTISING ERP", 20f, 50f, sideTextPaint)
            canvas.drawText("Official Brand Document", 20f, 70f, sideTextPaint)
            canvas.drawText("System Printed Invoice", 20f, 90f, sideTextPaint)

            val rightTextPaint = Paint().apply {
                color = Color.WHITE
                textSize = 10f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                textAlign = Paint.Align.RIGHT
            }
            val dateString = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            canvas.drawText("يافطة للدعاية والإعلان", 575f, 50f, rightTextPaint)
            canvas.drawText("تاريخ الإصدار: $dateString", 575f, 70f, rightTextPaint)
            canvas.drawText("المستند: فاتورة مشاريع رسمية", 575f, 90f, rightTextPaint)

            // 4. Draw Document Title below header
            val docTitlePaint = Paint().apply {
                color = colorCharcoalDark
                textSize = 16f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("OFFICIAL PROJECT INVOICE & CUSTOMER STATEMENT", 297.5f, 165f, docTitlePaint)
            canvas.drawText("بيان الفاتورة المعتمد ومواصفات المشاريع", 297.5f, 185f, docTitlePaint)

            // 5. Draw Customer Information section box card
            val cardBgPaint = Paint().apply {
                color = colorLightBackground
                style = Paint.Style.FILL
            }
            val cardBorderPaint = Paint().apply {
                color = colorAccentBorder
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(45f, 205f, 550f, 335f, cardBgPaint)
            canvas.drawRect(45f, 205f, 550f, 335f, cardBorderPaint)

            val detailTitlePaint = Paint().apply {
                color = colorGoldSecondary
                textSize = 10f
                isFakeBoldText = true
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            canvas.drawText("CUSTOMER METADATA / بيانات العميل المستندة", 55f, 222f, detailTitlePaint)

            val detailTextPaint = Paint().apply {
                color = Color.BLACK
                textSize = 10f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
            canvas.drawText("Name / الاسم الكريم: ${customer.name}", 55f, 245f, detailTextPaint)
            canvas.drawText("Company / الشركة: ${customer.companyName.ifEmpty { "—" }}", 55f, 262f, detailTextPaint)
            canvas.drawText("Phone / الهاتف المحمول: ${customer.phone}", 55f, 279f, detailTextPaint)
            canvas.drawText("Email / البريد الإلكتروني: ${customer.email.ifEmpty { "—" }}", 55f, 296f, detailTextPaint)
            canvas.drawText("Address / العنوان الجغرافي: ${customer.address.ifEmpty { "—" }}", 55f, 313f, detailTextPaint)

            // Draw Outstanding Balance Card inside customer metadata card
            val balanceBoxPaint = Paint().apply {
                color = Color.parseColor("#FCF7ED")
                style = Paint.Style.FILL
            }
            val balanceBoxStroke = Paint().apply {
                color = colorGoldPrimary
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(340f, 235f, 540f, 305f, balanceBoxPaint)
            canvas.drawRect(340f, 235f, 540f, 305f, balanceBoxStroke)

            val textBalanceLabelPaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 8f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("OUTSTANDING BALANCE / الرصيد المستحق", 440f, 255f, textBalanceLabelPaint)

            val textBalanceValuePaint = Paint().apply {
                color = colorGoldSecondary
                textSize = 12f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            val balanceStr = "${String.format("%,.2f", customer.balanceEgp)} EGP"
            canvas.drawText(balanceStr, 440f, 280f, textBalanceValuePaint)

            // 6. Draw Project Specifications Table
            var currentY = 360f
            val tableTitlePaint = Paint().apply {
                color = colorCharcoalDark
                textSize = 11f
                isFakeBoldText = true
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            canvas.drawText("ASSOCIATED PROJECTS DETAILS / بيان تفاصيل المشاريع", 45f, currentY, tableTitlePaint)
            currentY += 12f

            // Table Header Banner
            val tableHeaderBg = Paint().apply {
                color = colorCharcoalDark
                style = Paint.Style.FILL
            }
            canvas.drawRect(45f, currentY, 550f, currentY + 22f, tableHeaderBg)

            val tableHeaderFont = Paint().apply {
                color = Color.WHITE
                textSize = 9f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            canvas.drawText("Project Title / اسم المشروع الإعلاني", 55f, currentY + 14f, tableHeaderFont)
            canvas.drawText("Status / حالة العمل", 350f, currentY + 14f, tableHeaderFont)
            canvas.drawText("Progress / نسبة الإنجاز", 460f, currentY + 14f, tableHeaderFont)

            currentY += 22f

            val rowPaint = Paint().apply {
                color = Color.BLACK
                textSize = 9f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
            val borderRowPaint = Paint().apply {
                color = Color.parseColor("#EFECE4")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }

            val filteredProjects = projects.filter {
                it.customerName.equals(customer.name, ignoreCase = true) || 
                it.customerPhone == customer.phone
            }

            if (filteredProjects.isEmpty()) {
                canvas.drawRect(45f, currentY, 550f, currentY + 30f, cardBgPaint)
                canvas.drawRect(45f, currentY, 550f, currentY + 30f, borderRowPaint)
                val noDataPaint = Paint().apply {
                    color = Color.GRAY
                    textSize = 9f
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText("No active projects registered for this client / لا توجد مشاريع مسجلة حالياً للعميل", 297.5f, currentY + 18f, noDataPaint)
                currentY += 30f
            } else {
                filteredProjects.forEach { proj ->
                    val rowBgPaint = Paint().apply {
                        color = Color.WHITE
                        style = Paint.Style.FILL
                    }
                    canvas.drawRect(45f, currentY, 550f, currentY + 24f, rowBgPaint)
                    canvas.drawRect(45f, currentY, 550f, currentY + 24f, borderRowPaint)

                    canvas.drawText(proj.title, 55f, currentY + 15f, rowPaint)
                    canvas.drawText(proj.status, 350f, currentY + 15f, rowPaint)
                    canvas.drawText("${(proj.progress * 100).toInt()}% Completed", 460f, currentY + 15f, rowPaint)
                    
                    currentY += 24f
                }
            }

            // 7. General Terms/Specifications Box
            currentY += 25f
            val specsTitlePaint = Paint().apply {
                color = colorGoldSecondary
                textSize = 10f
                isFakeBoldText = true
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            canvas.drawText("TERMS, AGREEMENTS & WORK NOTES / شروط وملاحظات التسليم", 45f, currentY, specsTitlePaint)
            currentY += 12f

            val notesBoxPaint = Paint().apply {
                color = Color.parseColor("#FCFBF9")
                style = Paint.Style.FILL
            }
            val notesBoxStroke = Paint().apply {
                color = Color.parseColor("#EFECE4")
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRect(45f, currentY, 550f, currentY + 70f, notesBoxPaint)
            canvas.drawRect(45f, currentY, 550f, currentY + 70f, notesBoxStroke)

            val notesTextPaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 8f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }

            val noteLines = listOf(
                "1. This document acts as an official system invoice of all registered projects.",
                "2. Prices, dimensions, materials are verified and validated with the Engineering department.",
                "3. Signature represents full content and financial terms endorsement.",
                "Customer Specific Notes / ملاحظات إضافية: " + customer.notes.ifEmpty { "None recorded." }
            )

            var notesY = currentY + 15f
            noteLines.forEach { line ->
                canvas.drawText(line, 55f, notesY, notesTextPaint)
                notesY += 12f
            }

            // 8. Signatures Layout Section
            currentY += 90f
            val signLabelPaint = Paint().apply {
                color = Color.GRAY
                textSize = 9f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
            val signLinePaint = Paint().apply {
                color = Color.LTGRAY
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }

            canvas.drawText("Customer Endorsement Sign", 55f, currentY, signLabelPaint)
            canvas.drawText("توقيع المستلم والعميل", 55f, currentY + 12f, signLabelPaint)
            canvas.drawLine(55f, currentY + 50f, 185f, currentY + 50f, signLinePaint)

            canvas.drawText("Authorized Seal & Manager", 400f, currentY, signLabelPaint)
            canvas.drawText("الختم المعتمد وإدارة يافطة للدعاية", 400f, currentY + 12f, signLabelPaint)
            canvas.drawLine(400f, currentY + 50f, 530f, currentY + 50f, signLinePaint)

            // Footer info
            val footerPaint = Paint().apply {
                color = Color.GRAY
                textSize = 8f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("System Printed Ledger Sheet • YAFTA ADVERTISING ERP • Page 1 of 1", 297.5f, 800f, footerPaint)

            // Complete page design and write to File
            pdfDocument.finishPage(page)

            // 9. Write File output safely
            val pdfFile = File(context.cacheDir, "YAFTA_Invoice_${customer.name.replace("\\s+".toRegex(), "_")}.pdf")
            val fos = FileOutputStream(pdfFile)
            pdfDocument.writeTo(fos)
            fos.close()
            pdfDocument.close()

            // 10. Start Share System Chooser
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdfFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "YAFTA Invoice & Specifications - ${customer.name}")
                putExtra(Intent.EXTRA_TEXT, "Hello ${customer.name},\n\nPlease find attached your official invoice and projects specifications datasheet generated by YAFTA advertising ERP system.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Share/Export Invoice PDF")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)

            Toast.makeText(context, "Official PDF Invoice Exported Successfully!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Failed to compile/export PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
