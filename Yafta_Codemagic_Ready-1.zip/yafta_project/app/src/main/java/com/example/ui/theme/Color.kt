package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFD4AF37)
val GoldSecondary = Color(0xFFA67C1E)
val CharcoalDark = Color(0xFF000000)
val CharcoalMedium = Color(0xFF1C1C1E)
val CharcoalLight = Color(0xFF2C2C2E)

val PlatinumWhite = Color(0xFFF5F5F7)
val PlatinumGray = Color(0xFF8E8E93)

val GlassBorder = Color(0x33D4AF37)
val GlassSurface = Color(0xB31C1C1E)

