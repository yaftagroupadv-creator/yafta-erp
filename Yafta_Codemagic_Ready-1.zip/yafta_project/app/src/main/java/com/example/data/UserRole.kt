package com.example.data

enum class UserRole(
    val roleName: String,
    val displayNameAr: String,
    val displayNameEn: String,
    val accessibleModules: Set<String>
) {
    ADMIN(
        "Admin",
        "المدير العام",
        "General Manager",
        setOf(
            "dashboard", "customers", "quotations", "projects", "studio", 
            "design_dept", "production", "installation", "inventory", 
            "suppliers", "finance", "staff", "settings"
        )
    ),
    DESIGNER(
        "Designer",
        "المصمم الإبداعي",
        "Creative Designer",
        setOf(
            "dashboard", "projects", "studio", "design_dept", "settings"
        )
    ),
    PRODUCTION(
        "Production",
        "مسؤول الورشة والتصنيع",
        "Production Specialist",
        setOf(
            "dashboard", "projects", "production", "inventory", "settings"
        )
    ),
    SALES(
        "Sales",
        "مسؤول المبيعات",
        "Sales Consultant",
        setOf(
            "dashboard", "customers", "quotations", "projects", "inventory", "settings"
        )
    ),
    INSTALLER(
        "Installer",
        "فني التركيبات",
        "Field Installer",
        setOf(
            "dashboard", "projects", "installation", "settings"
        )
    ),
    ACCOUNTANT(
        "Accountant",
        "المحاسب المالي",
        "Accountant",
        setOf(
            "dashboard", "suppliers", "finance", "settings"
        )
    );

    fun hasAccess(module: String): Boolean {
        return accessibleModules.contains(module)
    }

    companion object {
        fun fromString(role: String): UserRole {
            return values().firstOrNull { it.roleName.equals(role, ignoreCase = true) } ?: ADMIN
        }
    }
}
