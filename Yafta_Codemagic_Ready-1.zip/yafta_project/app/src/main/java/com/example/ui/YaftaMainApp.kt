package com.example.ui

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.DesignLayer
import com.example.viewmodel.YaftaViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun YaftaMainApp(viewModel: YaftaViewModel) {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf("Splash") }
    val language = viewModel.language
    val localLayoutDirection = if (language == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

    // State collection from database
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val quotations by viewModel.quotations.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val productionJobs by viewModel.productionJobs.collectAsStateWithLifecycle()
    val installationJobs by viewModel.installationJobs.collectAsStateWithLifecycle()
    val inventory by viewModel.inventory.collectAsStateWithLifecycle()
    val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()
    val invoices by viewModel.invoices.collectAsStateWithLifecycle()
    val expenses by viewModel.expenses.collectAsStateWithLifecycle()
    val employees by viewModel.employees.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val activityLogs by viewModel.activityLogs.collectAsStateWithLifecycle()

    CompositionLocalProvider(LocalLayoutDirection provides localLayoutDirection) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CharcoalDark)
                // 5% responsive golden background watermark behind all UI elements
                .drawBehind {
                    drawCircle(
                        color = GoldPrimary.copy(alpha = 0.04f),
                        radius = size.minDimension * 0.45f,
                        center = center
                    )
                    // Structural overlay line guides
                    drawLine(
                        color = GoldPrimary.copy(alpha = 0.03f),
                        start = Offset(0f, size.height * 0.35f),
                        end = Offset(size.width, size.height * 0.35f),
                        strokeWidth = 2f
                    )
                }
        ) {
            when (currentScreen) {
                "Splash" -> SplashScreen { currentScreen = "Login" }
                "Login" -> LoginScreen(viewModel) { currentScreen = "MainShell" }
                "MainShell" -> MainShell(
                    viewModel = viewModel,
                    customers = customers,
                    quotations = quotations,
                    projects = projects,
                    productionJobs = productionJobs,
                    installationJobs = installationJobs,
                    inventory = inventory,
                    suppliers = suppliers,
                    invoices = invoices,
                    expenses = expenses,
                    employees = employees,
                    notifications = notifications,
                    activityLogs = activityLogs,
                    onLogout = { currentScreen = "Login" }
                )
            }
        }
    }
}

// 1. Splash Screen
@Composable
fun SplashScreen(onNext: () -> Unit) {
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2200)
        onNext()
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            ProgrammaticLogoShield(modifier = Modifier.size(160.dp))
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "يافطة للدعاية والإعلان",
                color = GoldPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "YAFTA FOR ADVERTISING ERP",
                color = PlatinumWhite.copy(alpha = 0.8f),
                fontSize = 14.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 8.dp),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(180.dp))
            CircularProgressIndicator(
                color = GoldPrimary,
                strokeWidth = 2.5.dp,
                modifier = Modifier.size(28.dp)
            )
            Text(
                text = "جاري تهيئة منصة الأعمال المؤثمنة...",
                color = PlatinumGray,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
}

// 2. Programmatic Logo Shield Design (Used when logo.png is copied or falls back)
@Composable
fun ProgrammaticLogoShield(modifier: Modifier = Modifier) {
    val context = LocalContext.current

    // Initialize BrandIdentityState from SharedPreferences if not already loaded
    LaunchedEffect(Unit) {
        if (BrandIdentityState.customLogoPath.isEmpty()) {
            val sharedPrefs = context.getSharedPreferences("yafta_settings", android.content.Context.MODE_PRIVATE)
            BrandIdentityState.customLogoPath = sharedPrefs.getString("customLogoUri", "") ?: ""
        }
    }

    val logoPath = BrandIdentityState.customLogoPath
    if (logoPath.isNotEmpty()) {
        val logoFile = remember(logoPath) { java.io.File(logoPath) }
        if (logoFile.exists()) {
            val model = remember(logoFile, logoFile.lastModified()) {
                coil.request.ImageRequest.Builder(context)
                    .data(logoFile)
                    .memoryCachePolicy(coil.request.CachePolicy.DISABLED)
                    .diskCachePolicy(coil.request.CachePolicy.DISABLED)
                    .build()
            }
            AsyncImage(
                model = model,
                contentDescription = "YAFTA Custom Brand Logo",
                modifier = modifier,
                contentScale = androidx.compose.ui.layout.ContentScale.Fit
            )
            return
        }
    }

    val logoResId = remember(context) {
        context.resources.getIdentifier("logo", "drawable", context.packageName)
    }

    if (logoResId != 0) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(id = logoResId),
            contentDescription = "YAFTA Logo",
            modifier = modifier,
            contentScale = androidx.compose.ui.layout.ContentScale.Fit
        )
    } else {
        // Leave the logo area completely empty/clear, as instructed by the user, for custom logo insertion later.
        Box(
            modifier = modifier
        )
    }
}

// 3. Login / Simulation Role Screen (Deprecated in favor of real dynamic logins)
@Composable
fun OldSimulatedLoginScreen(viewModel: YaftaViewModel, onLoginSuccess: () -> Unit) {
    val lang = viewModel.language
    var email by remember { mutableStateOf("islamhamdypro@gmail.com") }
    var password by remember { mutableStateOf("••••••••") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000)),
        contentAlignment = Alignment.Center
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                ProgrammaticLogoShield(modifier = Modifier.size(170.dp))
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = Translations.get("login_welcome", lang),
                    color = PlatinumWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = Translations.get("login_tag", lang),
                    color = PlatinumGray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                Spacer(modifier = Modifier.height(32.dp))

                // Text Inputs
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text(Translations.get("email_placeholder", lang)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = CharcoalLight,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("email_input"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(Translations.get("pass_placeholder", lang)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = CharcoalLight,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("password_input"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(24.dp))

                // Role selector to simulate actual departments
                Text(
                    text = Translations.get("choose_role", lang),
                    color = GoldPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                val roles = UserRole.values()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    roles.forEach { role ->
                        val selected = viewModel.currentRoleEnum == role
                        val displayName = if (lang == "ar") role.displayNameAr else role.displayNameEn
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) GoldPrimary else CharcoalMedium)
                                .border(1.dp, if (selected) GoldSecondary else CharcoalLight, RoundedCornerShape(12.dp))
                                .clickable { viewModel.currentRole = role.roleName }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = displayName,
                                color = if (selected) CharcoalDark else PlatinumWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onLoginSuccess,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("login_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = CharcoalDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = Translations.get("btn_login", lang),
                        color = CharcoalDark,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = Translations.get("forgot_password", lang),
                    color = PlatinumGray,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        viewModel.language = if (lang == "ar") "en" else "ar"
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary),
                    modifier = Modifier.wrapContentSize(),
                    border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Text(Translations.get("lang_toggle", lang), fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(24.dp))
                val context = LocalContext.current
                val downloadUrl = remember {
                    try {
                        context.assets.open("project_download_url.txt").bufferedReader().use { it.readText().trim() }
                    } catch (e: Exception) {
                        ""
                    }
                }
                if (downloadUrl.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .border(BorderStroke(1.dp, GoldPrimary), RoundedCornerShape(12.dp))
                            .background(CharcoalMedium.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .clickable {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(downloadUrl))
                                context.startActivity(intent)
                            }
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "Download ZIP",
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == "ar") "تحميل الكود البرمجي للمشروع كاملاً (ZIP)" else "Download Complete Project Source ZIP",
                                color = GoldPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

// 4. Central Enterprise Interface Structure
@Composable
fun MainShell(
    viewModel: YaftaViewModel,
    customers: List<Customer>,
    quotations: List<Quotation>,
    projects: List<Project>,
    productionJobs: List<ProductionJob>,
    installationJobs: List<InstallationJob>,
    inventory: List<InventoryItem>,
    suppliers: List<Supplier>,
    invoices: List<Invoice>,
    expenses: List<Expense>,
    employees: List<Employee>,
    notifications: List<Notification>,
    activityLogs: List<ActivityLog>,
    onLogout: () -> Unit
) {
    val lang = viewModel.language
    var activeModule by remember { mutableStateOf("dashboard") }
    var isDrawerOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    var previewPrintQuotation by remember { mutableStateOf<Quotation?>(null) }
    var previewPrintInvoice by remember { mutableStateOf<Invoice?>(null) }

    // FAB Quick Menu States
    var isFabMenuExpanded by remember { mutableStateOf(false) }
    var showDirectOrderDialog by remember { mutableStateOf(false) }
    var showQuickInventoryDialog by remember { mutableStateOf(false) }

    // Redirect to dashboard if the user no longer has access to the active module
    LaunchedEffect(viewModel.currentUser, viewModel.currentRole, activeModule) {
        if (!viewModel.hasAccess(activeModule, "view")) {
            activeModule = "dashboard"
        }
    }

    // Screen shell with custom luxury AppBar
    Column(modifier = Modifier.fillMaxSize()) {
        if (activeModule != "studio") {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                shape = RoundedCornerShape(0.dp, 0.dp, 16.dp, 16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(width = 1.dp, color = GlassBorder, shape = RoundedCornerShape(0.dp, 0.dp, 16.dp, 16.dp)),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.align(Alignment.CenterStart),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { isDrawerOpen = !isDrawerOpen },
                            modifier = Modifier.testTag("menu_nav_toggle")
                        ) {
                            Icon(
                                imageVector = if (isDrawerOpen) Icons.Default.Close else Icons.Default.Menu,
                                contentDescription = "Menu Toggle",
                                tint = GoldPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = if (lang == "ar") "يافطة للدعاية والإعلان" else "Yafita for Advertising",
                                color = GoldPrimary,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                maxLines = 1,
                                style = androidx.compose.ui.text.TextStyle(
                                    brush = Brush.horizontalGradient(listOf(GoldPrimary, GoldSecondary))
                                )
                            )
                            Text(
                                text = if (lang == "ar") "لوحة المتابعة والتحكم الذكية" else "Enterprise Operations Suite",
                                color = PlatinumGray,
                                fontSize = 9.sp,
                                maxLines = 1
                            )
                        }
                    }

                    Box(
                        modifier = Modifier.align(Alignment.Center),
                        contentAlignment = Alignment.Center
                    ) {
                        // Empty area reserved for custom brand logo, zero text inside it!
                        ProgrammaticLogoShield(modifier = Modifier.size(46.dp))
                    }

                    Row(
                        modifier = Modifier.align(Alignment.CenterEnd),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            horizontalAlignment = Alignment.End,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = viewModel.currentUser?.name ?: "Admen",
                                color = PlatinumWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                            val roleDisplayName = if (lang == "ar") {
                                viewModel.customRoles.value.firstOrNull { it.roleName.equals(viewModel.currentRole, ignoreCase = true) }?.displayNameAr ?: viewModel.currentRole
                            } else {
                                viewModel.customRoles.value.firstOrNull { it.roleName.equals(viewModel.currentRole, ignoreCase = true) }?.displayNameEn ?: viewModel.currentRole
                            }
                            Text(
                                text = roleDisplayName,
                                color = PlatinumGray,
                                fontSize = 9.sp,
                                maxLines = 1
                            )
                        }

                        IconButton(onClick = { viewModel.language = if (lang == "ar") "en" else "ar" }) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = GoldPrimary
                            )
                        }
                        IconButton(onClick = onLogout) {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = "Logout",
                                tint = PlatinumWhite
                            )
                        }
                    }
                }
            }
        }

        // Body with dynamic panel view vs sidebar drawer
        Box(modifier = Modifier.fillMaxSize()) {
            Row(modifier = Modifier.fillMaxSize()) {
                // Persistent Sidebar on wide layouts/collapsed on mobile
                AnimatedVisibility(
                    visible = isDrawerOpen,
                    enter = slideInHorizontally(
                        initialOffsetX = { fullWidth -> if (lang == "ar") fullWidth else -fullWidth },
                        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
                    ) + fadeIn(animationSpec = tween(300)),
                    exit = slideOutHorizontally(
                        targetOffsetX = { fullWidth -> if (lang == "ar") fullWidth else -fullWidth },
                        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
                    ) + fadeOut(animationSpec = tween(300))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(260.dp)
                            .background(CharcoalMedium)
                            .border(width = 1.dp, color = GlassBorder)
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 12.dp)
                    ) {
                        ProgrammaticLogoShield(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .padding(horizontal = 16.dp, vertical = 4.dp)
                        )
                        HorizontalDivider(color = GlassBorder, modifier = Modifier.padding(horizontal = 16.dp))
                        Spacer(modifier = Modifier.height(12.dp))

                        val sidebarItems = listOf(
                            Triple("dashboard", Translations.get("dashboard", lang), Icons.Default.Dashboard),
                            Triple("customers", Translations.get("customers", lang), Icons.Default.People),
                            Triple("quotations", Translations.get("quotations", lang), Icons.Default.Description),
                            Triple("projects", Translations.get("projects", lang), Icons.Default.Assignment),
                            Triple("studio", Translations.get("studio", lang), Icons.Default.Brush),
                            Triple("design_dept", Translations.get("design_dept", lang), Icons.Default.Palette),
                            Triple("production", Translations.get("production", lang), Icons.Default.HomeRepairService),
                            Triple("installation", Translations.get("installation", lang), Icons.Default.PinDrop),
                            Triple("inventory", Translations.get("inventory", lang), Icons.Default.Layers),
                            Triple("suppliers", Translations.get("suppliers", lang), Icons.Default.LocalShipping),
                            Triple("finance", Translations.get("finance", lang), Icons.Default.AccountBalanceWallet),
                            Triple("staff", Translations.get("staff", lang), Icons.Default.Badge),
                            Triple("users", if (lang == "ar") "المستخدمين والصلاحيات" else "Users & Permissions", Icons.Default.Shield),
                            Triple("settings", Translations.get("settings", lang), Icons.Default.Settings)
                        ).filter { (route, _, _) ->
                            viewModel.hasAccess(route, "view")
                        }

                        sidebarItems.forEach { (route, label, icon) ->
                            val active = activeModule == route
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        activeModule = route
                                        isDrawerOpen = false // Auto collapse on selections for mobile comfort
                                    }
                                    .background(if (active) CharcoalLight else Color.Transparent)
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(icon, contentDescription = null, tint = if (active) GoldPrimary else PlatinumGray)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = label,
                                    color = if (active) GoldPrimary else PlatinumWhite,
                                    fontSize = 13.sp,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                        val sidebarCtx = LocalContext.current
                        val downloadUrl = remember {
                            try {
                                sidebarCtx.assets.open("project_download_url.txt").bufferedReader().use { it.readText().trim() }
                            } catch (e: Exception) {
                                ""
                            }
                        }
                        if (downloadUrl.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                                    .border(BorderStroke(1.dp, GoldPrimary), RoundedCornerShape(10.dp))
                                    .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                    .clickable {
                                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(downloadUrl))
                                        sidebarCtx.startActivity(intent)
                                    }
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = "Download ZIP",
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (lang == "ar") "تحميل الكود البرمجي ZIP" else "Download Src ZIP",
                                        color = GoldPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Dynamic App Module View Frame with smooth, premium slide-in transitions
                AnimatedContent(
                    targetState = activeModule,
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    transitionSpec = {
                        // Determine slide direction so LTR slides from right-to-left and RTL slides from left-to-right (mirroring naturally)
                        val slideDirection = if (lang == "ar") AnimatedContentTransitionScope.SlideDirection.Left else AnimatedContentTransitionScope.SlideDirection.Right
                        slideIntoContainer(
                            towards = slideDirection,
                            animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing)
                        ) togetherWith fadeOut(animationSpec = tween(durationMillis = 150))
                    },
                    label = "ModuleTransition"
                ) { targetModule ->
                    Box(modifier = Modifier.fillMaxSize()) {
                        when (targetModule) {
                            "dashboard" -> DashboardModule(viewModel, customers, quotations, projects, inventory, activityLogs, invoices, expenses)
                            "customers" -> CustomersModule(viewModel, customers)
                            "quotations" -> QuotationsModule(viewModel, quotations, customers, onPrintQuotation = { previewPrintQuotation = it })
                            "projects" -> ProjectsModule(viewModel, projects, productionJobs)
                            "design_dept" -> DesignDeptModule(viewModel, projects)
                            "production" -> ProductionModule(viewModel, productionJobs)
                            "installation" -> InstallationModule(viewModel, installationJobs)
                            "inventory" -> InventoryModule(viewModel, inventory)
                            "suppliers" -> SuppliersModule(viewModel, suppliers)
                            "finance" -> FinanceModule(viewModel, invoices, expenses, onPrintInvoice = { previewPrintInvoice = it })
                            "staff" -> StaffModule(viewModel, employees)
                            "studio" -> DynamicDesignStudio(viewModel, onExit = { activeModule = "dashboard" })
                            "users" -> {
                                val uList by viewModel.users.collectAsStateWithLifecycle()
                                val rList by viewModel.customRoles.collectAsStateWithLifecycle()
                                UsersModule(viewModel, uList, rList)
                            }
                            "settings" -> SettingsModule(viewModel)
                        }
                    }
                }
            }

            // -----------------------------------------------------------------
            // LUXURY FLOATING ACTION BUTTON QUICK ACTION HUB Overlay
            // -----------------------------------------------------------------
            Box(
                modifier = Modifier
                    .align(if (lang == "ar") Alignment.BottomStart else Alignment.BottomEnd)
                    .padding(20.dp)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                Column(
                    horizontalAlignment = if (lang == "ar") Alignment.Start else Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Small floating sub-buttons (Shown with beautiful slide-in animation when expanded)
                    AnimatedVisibility(
                        visible = isFabMenuExpanded,
                        enter = expandVertically(expandFrom = Alignment.Bottom) + fadeIn(),
                        exit = shrinkVertically(shrinkTowards = Alignment.Bottom) + fadeOut()
                    ) {
                        Column(
                            horizontalAlignment = if (lang == "ar") Alignment.Start else Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Quick Action 1: Create direct production order
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.End,
                                modifier = Modifier
                                    .clickable {
                                        showDirectOrderDialog = true
                                        isFabMenuExpanded = false
                                    }
                                    .background(CharcoalMedium.copy(alpha = 0.95f), RoundedCornerShape(8.dp))
                                    .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = if (lang == "ar") "أمر إنتاج مباشر" else "Direct Production Order",
                                    color = PlatinumWhite,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(GoldPrimary, CircleShape)
                                        .testTag("fab_menu_direct_order"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.HomeRepairService,
                                        contentDescription = null,
                                        tint = CharcoalDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            // Quick Action 2: Quick stock adjust/update
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.End,
                                modifier = Modifier
                                    .clickable {
                                        showQuickInventoryDialog = true
                                        isFabMenuExpanded = false
                                    }
                                    .background(CharcoalMedium.copy(alpha = 0.95f), RoundedCornerShape(8.dp))
                                    .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = if (lang == "ar") "تعديل مخزون سريع" else "Quick Stock Adjust",
                                    color = PlatinumWhite,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(GoldSecondary, CircleShape)
                                        .testTag("fab_menu_quick_inventory"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Layers,
                                        contentDescription = null,
                                        tint = PlatinumWhite,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Main Floating Action Button (Glowing gold-black circular design)
                    val rotationAngle by animateFloatAsState(
                        targetValue = if (isFabMenuExpanded) 45f else 0f,
                        label = "fab_rotation"
                    )
                    
                    FloatingActionButton(
                        onClick = { isFabMenuExpanded = !isFabMenuExpanded },
                        containerColor = GoldPrimary,
                        contentColor = CharcoalDark,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(56.dp)
                            .shadow(
                                elevation = 8.dp,
                                shape = CircleShape,
                                clip = false,
                                ambientColor = GoldPrimary,
                                spotColor = GoldPrimary
                            )
                            .testTag("quick_fab_trigger")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Quick Action Center",
                            modifier = Modifier
                                .size(28.dp)
                                .rotate(rotationAngle)
                        )
                    }
                }
            }
        }
    }

    // --- QUICK ACTION DIALOGS ---
    if (showDirectOrderDialog) {
        var orderTitle by remember { mutableStateOf("") }
        var custName by remember { mutableStateOf("") }
        var custPhone by remember { mutableStateOf("") }
        var orderAmount by remember { mutableStateOf("") }
        var orderNotes by remember { mutableStateOf("") }
        var validationError by remember { mutableStateOf<String?>(null) }
        var isSubmitted by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showDirectOrderDialog = false },
            containerColor = CharcoalDark,
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier.padding(16.dp),
            title = {
                Text(
                    text = if (lang == "ar") "إنشاء أمر إنتاج وتشغيل مباشر" else "Create Direct Production Order",
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = if (lang == "ar") "يسجل هذا النموذج مشروع إنتاجي مباشر ويتكفل تلقائياً بإنشاء لوحة التحكم بالمصنع وتركيب الموقع وإصدار فاتورة الحسابات المطابقة لقيمته الإرشادية." else "This form initializes an instant project order, automatically spawning factory workshop, site-installation, and ledger-invoice entries.",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )

                    if (validationError != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0x26FF0000)),
                            border = BorderStroke(1.dp, Color.Red),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = validationError!!,
                                color = Color(0xFFFF6B6B),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    // 1. Campaign Headline / عنوان المشروع
                    val titleError = isSubmitted && orderTitle.isBlank()
                    OutlinedTextField(
                        value = orderTitle,
                        onValueChange = { 
                            orderTitle = it
                            if (it.isNotBlank() && validationError != null) validationError = null
                        },
                        label = { Text(if (lang == "ar") "عنوان المشروع الإعلاني *" else "Campaign Headline *") },
                        isError = titleError,
                        supportingText = {
                            if (titleError) {
                                Text(
                                    text = if (lang == "ar") "عنوان المشروع مطلوب للتسجيل" else "Campaign headline is highly required",
                                    color = Color(0xFFFF6B6B),
                                    fontSize = 11.sp
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CharcoalLight,
                            focusedLabelColor = GoldPrimary,
                            unfocusedLabelColor = PlatinumGray,
                            errorBorderColor = Color.Red,
                            errorLabelColor = Color.Red
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("fab_dialog_order_title")
                    )

                    // 2. Client/Customer Name / اسم العميل
                    val nameError = isSubmitted && custName.isBlank()
                    OutlinedTextField(
                        value = custName,
                        onValueChange = { 
                            custName = it
                            if (it.isNotBlank() && validationError != null) validationError = null
                        },
                        label = { Text(if (lang == "ar") "اسم العميل / الجهة الطالبة *" else "Customer Name *") },
                        isError = nameError,
                        supportingText = {
                            if (nameError) {
                                Text(
                                    text = if (lang == "ar") "اسم العميل حقل إلزامى لحفظ البيانات" else "Client name is mandatory for invoicing",
                                    color = Color(0xFFFF6B6B),
                                    fontSize = 11.sp
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CharcoalLight,
                            focusedLabelColor = GoldPrimary,
                            unfocusedLabelColor = PlatinumGray,
                            errorBorderColor = Color.Red,
                            errorLabelColor = Color.Red
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("fab_dialog_order_customer")
                    )

                    // 3. Customer Phone Number / هاتف التواصل
                    val isPhoneInvalid = isSubmitted && custPhone.isNotBlank() && !custPhone.matches(Regex("^[+]?[0-9\\s\\-]{7,15}$"))
                    OutlinedTextField(
                        value = custPhone,
                        onValueChange = { 
                            custPhone = it
                            if (validationError != null) validationError = null
                        },
                        label = { Text(if (lang == "ar") "رقم الهاتف" else "Phone Number") },
                        isError = isPhoneInvalid,
                        supportingText = {
                            if (isPhoneInvalid) {
                                Text(
                                    text = if (lang == "ar") "تنسيق الهاتف المكتوب غير صحيح (7 - 15 رقم)" else "Invalid telephone pattern (7-15 digits)",
                                    color = Color(0xFFFF6B6B),
                                    fontSize = 11.sp
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CharcoalLight,
                            focusedLabelColor = GoldPrimary,
                            unfocusedLabelColor = PlatinumGray,
                            errorBorderColor = Color.Red,
                            errorLabelColor = Color.Red
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("fab_dialog_order_phone")
                    )

                    // 4. Contract Amount / القيمة الإجمالية
                    val amountVal = orderAmount.toDoubleOrNull()
                    val amountError = isSubmitted && (amountVal == null || amountVal <= 0.0)
                    OutlinedTextField(
                        value = orderAmount,
                        onValueChange = { 
                            orderAmount = it
                            if (it.toDoubleOrNull() != null && validationError != null) validationError = null
                        },
                        label = { Text(if (lang == "ar") "القيمة الإجمالية للعقد (ج.م) *" else "Total Value of Contract (EGP) *") },
                        isError = amountError,
                        supportingText = {
                            if (amountError) {
                                Text(
                                    text = if (lang == "ar") "يرجى كتابة رقم صحيح أكبر من الصفر" else "Please declare a valid positive contract amount",
                                    color = Color(0xFFFF6B6B),
                                    fontSize = 11.sp
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CharcoalLight,
                            focusedLabelColor = GoldPrimary,
                            unfocusedLabelColor = PlatinumGray,
                            errorBorderColor = Color.Red,
                            errorLabelColor = Color.Red
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("fab_dialog_order_amount")
                    )

                    // 5. Technical Specifications / المواصفات الفنية
                    val specsError = isSubmitted && orderNotes.isBlank()
                    OutlinedTextField(
                        value = orderNotes,
                        onValueChange = { 
                            orderNotes = it
                            if (it.isNotBlank() && validationError != null) validationError = null
                        },
                        label = { Text(if (lang == "ar") "المواصفات الفنية والمقاسات *" else "Technical specs & Dimensions *") },
                        isError = specsError,
                        supportingText = {
                            if (specsError) {
                                Text(
                                    text = if (lang == "ar") "يرجى تحديد تفاصيل ومواد الإنتاج والمقاسات لحسابات الورشة" else "Technical specs and measurements are required to guide factory teams",
                                    color = Color(0xFFFF6B6B),
                                    fontSize = 11.sp
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CharcoalLight,
                            focusedLabelColor = GoldPrimary,
                            unfocusedLabelColor = PlatinumGray,
                            errorBorderColor = Color.Red,
                            errorLabelColor = Color.Red
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("fab_dialog_order_notes")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isSubmitted = true
                        val parsedAmount = orderAmount.toDoubleOrNull()
                        val isPhoneFormatInvalid = custPhone.isNotBlank() && !custPhone.matches(Regex("^[+]?[0-9\\s\\-]{7,15}$"))
                        
                        if (orderTitle.isBlank() || custName.isBlank() || parsedAmount == null || parsedAmount <= 0.0 || orderNotes.isBlank() || isPhoneFormatInvalid) {
                            validationError = if (lang == "ar") {
                                "تنبيه: تعذر إرسال النموذج. يرجى التحقق من كافة الحقول الإلزامية التي تحمل علامة (*) ومراجعة قيم المدخلات."
                            } else {
                                "Form validation failed. Please address the marked (*) required fields and verify numerical or phone inputs."
                            }
                        } else {
                            viewModel.addProductionOrderDirect(
                                title = orderTitle,
                                customerName = custName,
                                customerPhone = custPhone,
                                notes = orderNotes,
                                amount = parsedAmount
                            )
                            showDirectOrderDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = CharcoalDark),
                    modifier = Modifier.testTag("fab_dialog_order_submit")
                ) {
                    Text(if (lang == "ar") "تأكيد وتشغيل فوري" else "Launch Production", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDirectOrderDialog = false }) {
                    Text(if (lang == "ar") "إلغاء الأمر" else "Cancel", color = PlatinumGray)
                }
            }
        )
    }

    if (showQuickInventoryDialog) {
        var isAdjustmentMode by remember { mutableStateOf(true) }
        var selectedItemIndex by remember { mutableStateOf(0) }
        var adjustmentDelta by remember { mutableStateOf("") }
        
        var newMatName by remember { mutableStateOf("") }
        var newMatQty by remember { mutableStateOf("") }
        var newMatUnit by remember { mutableStateOf("Sqm") }
        var newMatLimit by remember { mutableStateOf("") }
        var newMatBarcode by remember { mutableStateOf("") }
        var validationError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showQuickInventoryDialog = false },
            containerColor = CharcoalDark,
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier.padding(16.dp),
            title = {
                Text(
                    text = if (lang == "ar") "إدارة وتسوية المخزون الفورية" else "Quick Stock Control Desk",
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CharcoalLight, RoundedCornerShape(8.dp))
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isAdjustmentMode) GoldPrimary else Color.Transparent)
                                .clickable { isAdjustmentMode = true }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (lang == "ar") "تسوية كمية" else "Adjust Quantity",
                                color = if (isAdjustmentMode) CharcoalDark else PlatinumWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (!isAdjustmentMode) GoldPrimary else Color.Transparent)
                                .clickable { isAdjustmentMode = false }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (lang == "ar") "مادة جديدة" else "New Material",
                                color = if (!isAdjustmentMode) CharcoalDark else PlatinumWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (validationError != null) {
                        Text(validationError!!, color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    if (isAdjustmentMode) {
                        if (inventory.isEmpty()) {
                            Text(
                                text = if (lang == "ar") "لا يتوفر مواد مخزنة حالياً لتعديل كمياتها، اختر علامة تبويب مادة جديدة." else "No inventoried materials found. Use 'New Material' tab structure.",
                                color = PlatinumGray,
                                fontSize = 11.sp
                            )
                        } else {
                            Text(
                                text = if (lang == "ar") "اختر المادة المخزنة المطلوب تسويتها:" else "Select the material to adjust:",
                                color = PlatinumWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            
                            var itemIndexExpanded by remember { mutableStateOf(false) }
                            val currentItem = inventory.getOrNull(selectedItemIndex)
                            
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CharcoalLight, RoundedCornerShape(8.dp))
                                    .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                                    .clickable { itemIndexExpanded = true }
                                    .padding(12.dp)
                                    .testTag("fab_dialog_inventory_item_selector")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = currentItem?.let { "${it.materialName} (${it.quantity} ${it.unit})" } ?: "-",
                                        color = PlatinumWhite,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldPrimary)
                                }
                                DropdownMenu(
                                    expanded = itemIndexExpanded,
                                    onDismissRequest = { itemIndexExpanded = false },
                                    modifier = Modifier.background(CharcoalMedium)
                                ) {
                                    inventory.forEachIndexed { idx, item ->
                                        DropdownMenuItem(
                                            text = {
                                                Text("${item.materialName} (${item.quantity} ${item.unit})", color = PlatinumWhite)
                                            },
                                            onClick = {
                                                selectedItemIndex = idx
                                                itemIndexExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = adjustmentDelta,
                                onValueChange = { adjustmentDelta = it },
                                label = { Text(if (lang == "ar") "الكمية المضافة (استخدم - للنقص)" else "Quantity (Use negative sign to deduct)") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = PlatinumWhite,
                                    unfocusedTextColor = PlatinumWhite,
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = CharcoalLight,
                                    focusedLabelColor = GoldPrimary,
                                    unfocusedLabelColor = PlatinumGray
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("fab_dialog_inventory_qty")
                            )
                        }
                    } else {
                        OutlinedTextField(
                            value = newMatName,
                            onValueChange = { newMatName = it },
                            label = { Text(if (lang == "ar") "اسم المادة التصنيعية" else "Material Code Name") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = PlatinumWhite,
                                unfocusedTextColor = PlatinumWhite,
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = CharcoalLight,
                                focusedLabelColor = GoldPrimary,
                                unfocusedLabelColor = PlatinumGray
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("fab_dialog_new_material_name")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newMatQty,
                                onValueChange = { newMatQty = it },
                                label = { Text(if (lang == "ar") "الكمية الحالية" else "Starting Qty") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = PlatinumWhite,
                                    unfocusedTextColor = PlatinumWhite,
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = CharcoalLight,
                                    focusedLabelColor = GoldPrimary,
                                    unfocusedLabelColor = PlatinumGray
                                ),
                                modifier = Modifier.weight(1f).testTag("fab_dialog_new_material_qty")
                            )
                            OutlinedTextField(
                                value = newMatUnit,
                                onValueChange = { newMatUnit = it },
                                label = { Text(if (lang == "ar") "الوحدة" else "Unit") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = PlatinumWhite,
                                    unfocusedTextColor = PlatinumWhite,
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = CharcoalLight,
                                    focusedLabelColor = GoldPrimary,
                                    unfocusedLabelColor = PlatinumGray
                                ),
                                modifier = Modifier.weight(0.8f).testTag("fab_dialog_new_material_unit")
                            )
                        }

                        OutlinedTextField(
                            value = newMatLimit,
                            onValueChange = { newMatLimit = it },
                            label = { Text(if (lang == "ar") "الحد الأدنى الحرج للتنبيه" else "Danger low limit alert") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = PlatinumWhite,
                                unfocusedTextColor = PlatinumWhite,
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = CharcoalLight,
                                focusedLabelColor = GoldPrimary,
                                unfocusedLabelColor = PlatinumGray
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("fab_dialog_new_material_limit")
                        )

                        OutlinedTextField(
                            value = newMatBarcode,
                            onValueChange = { newMatBarcode = it },
                            label = { Text(if (lang == "ar") "الباركود أو الرقم التسلسلي" else "Catalog barcode SN") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = PlatinumWhite,
                                unfocusedTextColor = PlatinumWhite,
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = CharcoalLight,
                                focusedLabelColor = GoldPrimary,
                                unfocusedLabelColor = PlatinumGray
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("fab_dialog_new_material_barcode")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isAdjustmentMode) {
                            val deltaVal = adjustmentDelta.toDoubleOrNull()
                            val currentItem = inventory.getOrNull(selectedItemIndex)
                            if (currentItem == null || deltaVal == null) {
                                validationError = if (lang == "ar") "يرجى تحديد المنتج وإدخال قيمة رقمية صحيحة للتسوية." else "Invalid item or numeric quantity value supplied."
                            } else {
                                viewModel.updateInventoryQty(currentItem, deltaVal)
                                showQuickInventoryDialog = false
                            }
                        } else {
                            val qtyVal = newMatQty.toDoubleOrNull()
                            val limitVal = newMatLimit.toDoubleOrNull()
                            if (newMatName.isBlank() || qtyVal == null || qtyVal < 0 || limitVal == null || limitVal < 0) {
                                validationError = if (lang == "ar") "يرجى ملء جميع الحقول وكمية البضاعة بشكل صحيح." else "Please verify item properties and limits values are valid numeric inputs."
                            } else {
                                val barNo = if (newMatBarcode.isBlank()) "BAR-${System.currentTimeMillis() % 10000}" else newMatBarcode
                                viewModel.addInventoryItem(
                                    name = newMatName,
                                    qty = qtyVal,
                                    limit = limitVal,
                                    unit = newMatUnit,
                                    barcode = barNo
                                )
                                showQuickInventoryDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = CharcoalDark),
                    modifier = Modifier.testTag("fab_dialog_inventory_submit")
                ) {
                    Text(if (lang == "ar") "تثبيت التغيير" else "Apply Stock", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickInventoryDialog = false }) {
                    Text(if (lang == "ar") "إلغاء الأمر" else "Cancel", color = PlatinumGray)
                }
            }
        )
    }

    previewPrintQuotation?.let { qtn ->
        PrintDocumentDialog(
            title = "عرض سعر مشروع إعلاني معتمد",
            docNumber = qtn.quotationNumber,
            customerName = qtn.customerName,
            customerPhone = qtn.customerPhone,
            dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            details = listOf(
                Triple("البيان والطلب", "تصنيع وتوريد يافطة إعلانية خارجية بمواصفات إمبوس ذهبي", "${qtn.length}م × ${qtn.width}م"),
                Triple("طريقة الاحتساب", "المساحة الكلية الاحتسابية للمتر المربع", "${qtn.area} Sqm"),
                Triple("التكلفة الإجمالية المقدرة", "السعر الكلي المقيد للمواد والتصنيع شامل الضرائب", "${qtn.totalPrice} EGP")
            ),
            notes = qtn.notes.ifEmpty { "عرض فني وتجاري يسري لمدة ١٥ يوماً من تاريخ إصداره." },
            onDismiss = { previewPrintQuotation = null }
        )
    }

    previewPrintInvoice?.let { inv ->
        PrintDocumentDialog(
            title = "فاتورة بيع ومستند تحصيل رسمي",
            docNumber = inv.invoiceNumber,
            customerName = inv.customerName,
            customerPhone = "",
            dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            details = listOf(
                Triple("البيان والخدمة", "تحصيل وتوريد عقد يافطة إعلانية معتمدة", "دفعة مقيدة"),
                Triple("المبلغ المطلوب الكلي", "إجمالي قيمة العقد المالي المتفق عليه", "${inv.totalPrice} EGP"),
                Triple("المبلغ المسدد لحينه", "إجمالي الدفعات المودعة بالخزينة نقدياً", "${inv.paidAmount} EGP"),
                Triple("الرصيد المتبقي المستحق", "إجمالي المستحقات الباقية في المعاملة", "${inv.balance} EGP")
            ),
            notes = inv.notes.ifEmpty { "مستند سداد رسمي صادر من الإدارة المالية لشركة يافطة للدعاية والإعلان." },
            onDismiss = { previewPrintInvoice = null }
        )
    }
}

// 5. Dashboard Pane
@Composable
fun DashboardModule(
    viewModel: YaftaViewModel,
    customers: List<Customer>,
    quotations: List<Quotation>,
    projects: List<Project>,
    inventory: List<InventoryItem>,
    activityLogs: List<ActivityLog>,
    invoices: List<Invoice>,
    expenses: List<Expense>
) {
    val lang = viewModel.language
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 1. Compute dynamic financial values with robust preset defaults to maintain gorgeous fidelity if empty
    val totalSales = if (invoices.isNotEmpty()) invoices.sumOf { it.totalPrice } else 324500.0
    val totalCollected = if (invoices.isNotEmpty()) invoices.sumOf { it.paidAmount } else 237100.0
    val totalCredit = if (invoices.isNotEmpty()) invoices.sumOf { it.balance } else 87400.0
    val totalExpenses = if (expenses.isNotEmpty()) expenses.sumOf { it.amount } else 87400.0
    val netProfit = (totalSales - totalExpenses).coerceAtLeast(0.0)
    val marginPercent = if (totalSales > 0.0) (netProfit / totalSales) * 100.0 else 0.0
    val collectionRate = if (totalSales > 0.0) (totalCollected / totalSales) else 0.73

    // Count statistics
    val completedProjectsCount = projects.count { it.status == "Completed" }
    val activeProjectsList = projects.filter { it.status != "Completed" && it.status != "Trash" }
    val criticalAlertCount = inventory.count { it.quantity <= it.lowStockAlertLimit }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // PREMIUM HEADER GREETING BANNER
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (lang == "ar") "مرحباً بك مجدداً في يافطة" else "Welcome Back to Yafta",
                            color = PlatinumWhite,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale(lang)).format(Date()),
                            color = PlatinumGray,
                            style = MaterialTheme.typography.bodyMedium,
                            fontSize = 12.sp
                        )
                    }

                    // Luxury Role Indicator Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(GoldPrimary.copy(alpha = 0.15f))
                            .border(BorderStroke(1.dp, GoldSecondary), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (viewModel.currentRole) {
                                    "Admin" -> if (lang == "ar") "مسؤول النظام" else "System Admin"
                                    "Designer" -> if (lang == "ar") "مصمم هندسي" else "3D Designer"
                                    "Production" -> if (lang == "ar") "مدير الورشة" else "Workshop Mgr"
                                    "Installation" -> if (lang == "ar") "مشرف الموقع" else "Site Engineer"
                                    else -> viewModel.currentRole
                                },
                                color = GoldPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // -------------------------------------------------------------
        // WIDGET 1: LUXURY REVENUE SUMMARY & FINANCIAL CONSOLE
        // -------------------------------------------------------------
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.2.dp, GoldPrimary.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(elevation = 8.dp, shape = RoundedCornerShape(20.dp), ambientColor = GoldPrimary, spotColor = GoldPrimary)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Title Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == "ar") "الملخص المالي وميزان العملات" else "REVENUE & FINANCE COCKPIT",
                                color = GoldPrimary,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                letterSpacing = 0.5.sp
                            )
                        }

                        // Glowing Ledger Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(GoldSecondary.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (lang == "ar") "تدقيق فوري" else "Live Audit",
                                color = GoldSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Primary Double-Column Balance Overview
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Left Principal Column: Sales Revenue
                        Column(modifier = Modifier.weight(1.1f)) {
                            Text(
                                text = if (lang == "ar") "عقود المبيعات والصفقات" else "Gross Contract Revenue",
                                color = PlatinumGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${String.format("%,.0f", totalSales)} ${if (lang == "ar") "ج.م" else "EGP"}",
                                color = GoldPrimary,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF4CAF50))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${if (lang == "ar") "صافي الأرباح:" else "Net Operating Profit:"} ${String.format("%,.0f", netProfit)} ${if (lang == "ar") "ج.م" else "EGP"}",
                                    color = PlatinumWhite,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        // Right Info Column: Collections & Cost metrics
                        Column(
                            modifier = Modifier.weight(0.9f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Paid Item
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (lang == "ar") "✔ المحصل نقدياً:" else "✔ Collected Cash:",
                                    color = PlatinumWhite,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "${String.format("%,.0f", totalCollected)}",
                                    color = PlatinumWhite,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            HorizontalDivider(color = GlassBorder)
                            
                            // Outstanding Item
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (lang == "ar") "🗂 مستحق متبقي:" else "🗂 Outstanding:",
                                    color = PlatinumGray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "${String.format("%,.0f", totalCredit)}",
                                    color = GoldSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            HorizontalDivider(color = GlassBorder)

                            // Expenses Item
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (lang == "ar") "📉 أجور ومصاريف:" else "📉 Cash Outflow:",
                                    color = PlatinumGray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "-${String.format("%,.0f", totalExpenses)}",
                                    color = Color.Red,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Collections Rate progress gauge
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (lang == "ar") "كفاءة تحصيل مديونيات العملاء" else "Debt Capital Collection Index",
                                color = PlatinumGray,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "${(collectionRate * 100).toInt()}%",
                                color = GoldPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        // Custom premium progress track
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(CharcoalDark)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(collectionRate.toFloat())
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(GoldSecondary, GoldPrimary)
                                        )
                                    )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Elegant Programmatic Sales vs Cost Chart using Jetpack Compose Canvas
                    Text(
                        text = if (lang == "ar") "تحليل مقارنة الإيرادات التشغيلية بالمصاريف" else "Operational Revenues vs Costs Chart",
                        color = PlatinumWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CharcoalDark, RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Canvas(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                            ) {
                                val chartHeight = size.height
                                val gridLineCount = 3
                                // Draw horizontal grid guides
                                for (i in 0..gridLineCount) {
                                    val yOffset = chartHeight * i / gridLineCount
                                    drawLine(
                                        color = PlatinumGray.copy(alpha = 0.12f),
                                        start = Offset(0f, yOffset),
                                        end = Offset(size.width, yOffset),
                                        strokeWidth = 1.dp.toPx()
                                    )
                                }

                                val barSpacing = 40.dp.toPx()
                                val barWidth = 36.dp.toPx()

                                // Dynamic proportion multipliers (scaled relative to total contract value)
                                val scaleFactorMax = (totalSales + totalExpenses).coerceAtLeast(100.0)
                                val revenueHeightVal = (totalSales / scaleFactorMax * chartHeight).toFloat().coerceIn(10f, chartHeight)
                                val expensesHeightVal = (totalExpenses / scaleFactorMax * chartHeight).toFloat().coerceIn(10f, chartHeight)
                                val profitHeightVal = (netProfit / scaleFactorMax * chartHeight).toFloat().coerceIn(10f, chartHeight)

                                // Let's draw 3 luxury columns (Sales, Expenses, Net Profit)
                                // 1. Gross Revenue
                                drawOutlinedLuxuryBar(
                                    offsetX = barSpacing,
                                    barWidth = barWidth,
                                    height = revenueHeightVal,
                                    canvasHeight = chartHeight,
                                    brushColorGradient = listOf(GoldSecondary, GoldPrimary)
                                )

                                // 2. Cash Outflow Expenses
                                drawOutlinedLuxuryBar(
                                    offsetX = barSpacing * 2f + barWidth,
                                    barWidth = barWidth,
                                    height = expensesHeightVal,
                                    canvasHeight = chartHeight,
                                    brushColorGradient = listOf(CharcoalLight, PlatinumGray)
                                )

                                // 3. Net Profits
                                drawOutlinedLuxuryBar(
                                    offsetX = barSpacing * 3f + barWidth * 2f,
                                    barWidth = barWidth,
                                    height = profitHeightVal,
                                    canvasHeight = chartHeight,
                                    brushColorGradient = listOf(Color(0xFF388E3C), Color(0xFF4CAF50))
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Labels legend row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                ChartLabelItem(if (lang == "ar") "المبيعات" else "Revenues", GoldPrimary)
                                ChartLabelItem(if (lang == "ar") "النفقات" else "Outlays", PlatinumGray)
                                ChartLabelItem(if (lang == "ar") "الربح" else "Profit", Color(0xFF4CAF50))
                            }
                        }
                    }
                }
            }
        }

        // -------------------------------------------------------------
        // WIDGET 2: ACTIVE CAMPAIGNS & SIGNAGE ORDERS WORKFLOW
        // -------------------------------------------------------------
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Assignment,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == "ar") "طلبات التشغيل والمشاريع النشطة" else "ACTIVE SIGNAGE ORDERS",
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(GoldPrimary.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${activeProjectsList.size} ${if (lang == "ar") "نشط" else "Active"}",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (activeProjectsList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CharcoalMedium, RoundedCornerShape(16.dp))
                        .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(16.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = GoldPrimary.copy(alpha = 0.5f),
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (lang == "ar") "جميع العقود منتهية ومكتملة تماماً!" else "ALL SIGN AGE ORDERS FINISHED!",
                            color = PlatinumWhite,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (lang == "ar") "يمكنك إنشاء طلب تسعير أو مشروع جديد في أي وقت" else "Create a pricing quotation in the Quotations panel to spawn an order.",
                            color = PlatinumGray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(activeProjectsList) { project ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    border = BorderStroke(1.dp, GlassBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_project_order_${project.id}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Project header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = project.title,
                                    color = GoldPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "👤 ${if (lang == "ar") "العميل:" else "Client:"} ${project.customerName}",
                                    color = PlatinumWhite,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "📅 ${if (lang == "ar") "التسليم المتوقع:" else "Delivery Target:"} ${project.endDate}",
                                    color = PlatinumGray,
                                    fontSize = 11.sp
                                )
                            }

                            // Dynamic percentage progress ring
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    // Base track
                                    drawArc(
                                        color = CharcoalLight,
                                        startAngle = 135f,
                                        sweepAngle = 270f,
                                        useCenter = false,
                                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                    // Highlight arc
                                    drawArc(
                                        brush = Brush.horizontalGradient(
                                            listOf(GoldSecondary, GoldPrimary)
                                        ),
                                        startAngle = 135f,
                                        sweepAngle = 270f * project.progress,
                                        useCenter = false,
                                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                                    )
                                }
                                Text(
                                    text = "${(project.progress * 100).toInt()}%",
                                    color = GoldPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // AESTHETIC PIPELINE STEPPER
                        val currentStage = project.status
                        val stagesList = listOf("Concept", "Design", "Production", "Installation")
                        val activeIndex = stagesList.indexOf(currentStage).coerceAtLeast(0)

                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                stagesList.forEachIndexed { idx, stageLabel ->
                                    val isDone = idx < activeIndex
                                    val isActive = idx == activeIndex
                                    val isPending = idx > activeIndex

                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when {
                                                        isActive -> GoldPrimary
                                                        isDone -> GoldSecondary.copy(alpha = 0.4f)
                                                        else -> CharcoalLight
                                                    }
                                                )
                                                .border(
                                                    1.dp,
                                                    if (isActive) GoldPrimary else GlassBorder,
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isDone) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = null,
                                                    tint = CharcoalDark,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            } else {
                                                Text(
                                                    text = "${idx + 1}",
                                                    color = if (isActive) CharcoalDark else PlatinumGray,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = when (stageLabel) {
                                                "Concept" -> if (lang == "ar") "فكرة" else "Concept"
                                                "Design" -> if (lang == "ar") "تصميم" else "Design"
                                                "Production" -> if (lang == "ar") "تصنيع" else "Workshop"
                                                "Installation" -> if (lang == "ar") "تركيب" else "On-Site"
                                                else -> stageLabel
                                            },
                                            color = if (isActive) GoldPrimary else if (isDone) PlatinumWhite else PlatinumGray,
                                            fontSize = 9.sp,
                                            fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Medium
                                        )
                                    }

                                    // Draw line connector between nodes if not last
                                    if (idx < stagesList.size - 1) {
                                        Box(
                                            modifier = Modifier
                                                .weight(0.4f)
                                                .height(2.dp)
                                                .background(
                                                    if (idx < activeIndex) GoldSecondary.copy(alpha = 0.5f) else CharcoalLight
                                                )
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // QUICK PHASE TRANSITING SHORTCUT PILLS
                            Text(
                                text = if (lang == "ar") "تعديل مرحلة المشروع فورياً:" else "Progress Work Station Directly:",
                                color = PlatinumGray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                stagesList.forEach { targetStageName ->
                                    val isCurrent = currentStage == targetStageName || (targetStageName == "Production" && currentStage == "In-Production")
                                    Button(
                                        onClick = {
                                            viewModel.updateProjectStatus(project, targetStageName)
                                            Toast.makeText(
                                                context,
                                                if (lang == "ar") "تم نقل حالة المشروع بنجاح إلى [$targetStageName]" else "Order status shifted to [$targetStageName]!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isCurrent) GoldPrimary else CharcoalLight,
                                            contentColor = if (isCurrent) CharcoalDark else PlatinumWhite
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(30.dp)
                                            .testTag("dashboard_stepper_btn_${project.id}_$targetStageName"),
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text(
                                            text = when (targetStageName) {
                                                "Concept" -> if (lang == "ar") "فكرة" else "Concept"
                                                "Design" -> if (lang == "ar") "تصميم" else "Design"
                                                "Production" -> if (lang == "ar") "تصنيع" else "Workshop"
                                                "Installation" -> if (lang == "ar") "تركيب" else "On-Site"
                                                else -> targetStageName
                                            },
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // -------------------------------------------------------------
        // WIDGET 3: SIGNAGE MATERIAL & INVENTORY LEVELS WIDGET
        // -------------------------------------------------------------
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == "ar") "لوحة مخزون المواد واللافتات" else "SIGNAGE MATERIAL STOCK LEVELS",
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                if (criticalAlertCount > 0) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Red.copy(alpha = 0.2f))
                            .border(BorderStroke(1.dp, Color.Red), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "$criticalAlertCount ${if (lang == "ar") "حرج" else "Low"}",
                            color = Color.Red,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (inventory.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CharcoalMedium, RoundedCornerShape(16.dp))
                        .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(16.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (lang == "ar") "مستودع المخازن فارغ حالياً! قم بتعبئة بيانات من شاشة المخزن." else "No Raw Signage materials declared. Add items in Warehouses.",
                        color = PlatinumGray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(inventory) { itemUnit ->
                val isLow = itemUnit.quantity <= itemUnit.lowStockAlertLimit
                val progressFraction = (itemUnit.quantity / (itemUnit.lowStockAlertLimit * 2.5).coerceAtLeast(10.0)).coerceIn(0.0, 1.0)

                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    border = BorderStroke(1.dp, if (isLow) Color.Red.copy(alpha = 0.3f) else GlassBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_inventory_item_${itemUnit.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Left/Main Info Core
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Dynamic stock light color bulbs
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                isLow -> Color.Red
                                                itemUnit.quantity <= itemUnit.lowStockAlertLimit * 1.5 -> Color(0xFFFFB300)
                                                else -> GoldPrimary
                                            }
                                        )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = itemUnit.materialName,
                                    color = PlatinumWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "🏢 ${itemUnit.warehouseName} • ${if (lang == "ar") "الحد الحرج:" else "Crit limit:"} ${itemUnit.lowStockAlertLimit.toInt()} ${itemUnit.unit}",
                                color = PlatinumGray,
                                fontSize = 10.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            // Dynamic Linear Level Gauge Track
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.9f)
                                    .height(4.dp)
                                    .clip(CircleShape)
                                    .background(CharcoalDark)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(progressFraction.toFloat())
                                        .background(
                                            if (isLow) Color.Red else GoldPrimary
                                        )
                                )
                            }
                        }

                        // Right Controller: Dynamic refilling and depleting DB buttons
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Current Quantity Badge Displays
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${itemUnit.quantity.toInt()} ${itemUnit.unit}",
                                    color = if (isLow) Color.Red else PlatinumWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = if (isLow) (if (lang == "ar") "نقص حاد" else "DEPLETED") else (if (lang == "ar") "متاح" else "SURPLUS"),
                                    color = if (isLow) Color.Red else PlatinumGray,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Dynamic interactive "+" & "-" Quick Refillers
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Decrease stock action
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(CharcoalLight)
                                        .clickable {
                                            viewModel.updateInventoryQty(itemUnit, -10.0)
                                            Toast.makeText(context, "${itemUnit.materialName} -10", Toast.LENGTH_SHORT).show()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Deplete stock",
                                        tint = PlatinumWhite,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                
                                Spacer(modifier = Modifier.width(4.dp))

                                // Increase stock action
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(GoldPrimary)
                                        .clickable {
                                            viewModel.updateInventoryQty(itemUnit, 10.0)
                                            Toast.makeText(context, "${itemUnit.materialName} +10", Toast.LENGTH_SHORT).show()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Replenish stock",
                                        tint = CharcoalDark,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live audit trace logs
        item {
            Text(
                text = Translations.get("recent_logs", lang),
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        items(activityLogs.take(5)) { log ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(log.action, color = PlatinumWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(log.details, color = PlatinumGray, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = log.timestamp,
                        color = GoldPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Light
                    )
                }
            }
        }
    }
}

// Draw elegant outlined visual metrics bar
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawOutlinedLuxuryBar(
    offsetX: Float,
    barWidth: Float,
    height: Float,
    canvasHeight: Float,
    brushColorGradient: List<Color>
) {
    // Draw real luxury bar indicator
    val startY = canvasHeight - height
    // Draw solid filling column
    drawRect(
        brush = Brush.verticalGradient(brushColorGradient),
        topLeft = Offset(offsetX, startY),
        size = Size(barWidth, height)
    )
    // Add highlighted thin outline stroke bordering
    drawRect(
        color = Color(0x7FD4AF37),
        topLeft = Offset(offsetX, startY),
        size = Size(barWidth, height),
        style = Stroke(width = 1.5f)
    )
}

@Composable
fun ChartLabelItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, color = PlatinumGray, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun KpiCard(title: String, value: String, icon: ImageVector, color: Color, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = modifier.border(1.dp, GlassBorder, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = PlatinumGray, fontSize = 11.sp, maxLines = 1)
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(value, color = PlatinumWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// 6. Customers Module
@Composable
fun CustomersModule(viewModel: YaftaViewModel, list: List<Customer>) {
    val lang = viewModel.language
    val context = LocalContext.current
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    
    // Mode switcher: Selected Customer Profile View vs Master List
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var isAddingNew by remember { mutableStateOf(false) }

    // Search query for localized filtering
    var searchQuery by remember { mutableStateOf("") }

    val filteredList = remember(list, searchQuery) {
        if (searchQuery.isBlank()) {
            list
        } else {
            list.filter {
                it.name.contains(searchQuery, ignoreCase = true) || 
                it.companyName.contains(searchQuery, ignoreCase = true) ||
                it.phone.contains(searchQuery)
            }
        }
    }

    // Set Layout Direction for RTL Arabic / LTR English
    CompositionLocalProvider(
        LocalLayoutDirection provides (if (lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(CharcoalDark)
                .padding(16.dp)
        ) {
            if (selectedCustomer != null) {
                // --- CUSTOMER PROFILE VIEW ---
                val customer = selectedCustomer!!
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { selectedCustomer = null },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(CharcoalMedium)
                            .border(1.dp, GlassBorder, CircleShape)
                            .testTag("back_to_list_button")
                    ) {
                        Icon(
                            imageVector = if (lang == "ar") Icons.Default.ArrowForward else Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = GoldPrimary
                        )
                    }
                    Text(
                        text = if (lang == "ar") "ملف تعريف العميل" else "Customer Profile",
                        color = GoldPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Profile Header card
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.3f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("customer_profile_card")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Initials Badge
                                val initials = customer.name.getOrNull(0)?.toString() ?: ""
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(Brush.radialGradient(listOf(GoldPrimary, GoldSecondary)))
                                        .border(2.dp, GoldPrimary, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = initials,
                                        color = CharcoalDark,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 32.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = customer.name,
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    textAlign = TextAlign.Center
                                )

                                if (customer.companyName.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Business,
                                            contentDescription = null,
                                            tint = PlatinumWhite.copy(alpha = 0.8f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = customer.companyName,
                                            color = PlatinumWhite,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Medium,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Balance block
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(GoldPrimary.copy(alpha = 0.08f))
                                        .border(1.dp, GoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                        .padding(horizontal = 24.dp, vertical = 10.dp)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = if (lang == "ar") "الرصيد المدين" else "Outstanding Balance",
                                            color = PlatinumGray,
                                            fontSize = 11.sp
                                        )
                                        Text(
                                            text = "${String.format("%,.2f", customer.balanceEgp)} ${if (lang == "ar") "ج.م" else "EGP"}",
                                            color = GoldPrimary,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 20.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Contact Details Info Card
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (lang == "ar") "تفاصيل الاتصال" else "Contact Details",
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                DetailRow(
                                    icon = Icons.Default.Call,
                                    label = if (lang == "ar") "الجوال" else "Phone",
                                    value = customer.phone,
                                    testTag = "detail_phone"
                                )
                                HorizontalDivider(color = GlassBorder, modifier = Modifier.padding(vertical = 10.dp))

                                DetailRow(
                                    icon = Icons.Default.Chat,
                                    label = if (lang == "ar") "الواتساب" else "WhatsApp",
                                    value = customer.whatsapp,
                                    testTag = "detail_whatsapp"
                                )
                                HorizontalDivider(color = GlassBorder, modifier = Modifier.padding(vertical = 10.dp))

                                DetailRow(
                                    icon = Icons.Default.Email,
                                    label = if (lang == "ar") "البريد الإلكتروني" else "Email",
                                    value = customer.email.ifEmpty { "—" },
                                    testTag = "detail_email"
                                )
                                HorizontalDivider(color = GlassBorder, modifier = Modifier.padding(vertical = 10.dp))

                                DetailRow(
                                    icon = Icons.Default.PinDrop,
                                    label = if (lang == "ar") "العنوان الجغرافي" else "Address",
                                    value = customer.address.ifEmpty { "—" },
                                    testTag = "detail_address"
                                )
                            }
                        }
                    }

                    // Project Specific Notes & Preview Card
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, GoldSecondary.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.StickyNote2,
                                        contentDescription = null,
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (lang == "ar") "تعليمات المشروع ومواصفات اللوحات" else "Project Specifications & Notes",
                                        color = GoldPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CharcoalDark)
                                        .border(BorderStroke(1.dp, GlassBorder))
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        text = customer.notes.ifEmpty { if (lang == "ar") "لا توجد ملاحظات مسجلة للمقاسات والمعاينات حالياً." else "No notes registered yet." },
                                        color = PlatinumWhite.copy(alpha = 0.9f),
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }
                    }

                    // Contact Actions Section
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (lang == "ar") "اتصالات سريعة مع العميل" else "Quick Actions",
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // WhatsApp Prime Action
                                    Button(
                                        onClick = {
                                            val url = "https://api.whatsapp.com/send?phone=${customer.whatsapp}"
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                            context.startActivity(intent)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("whatsapp_action_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Chat,
                                            contentDescription = null,
                                            tint = CharcoalDark,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (lang == "ar") "واتساب مباشر" else "WhatsApp Chat",
                                            color = CharcoalDark,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }

                                    // Dial Action
                                    Button(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.phone}"))
                                            context.startActivity(intent)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("call_action_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Call,
                                            contentDescription = null,
                                            tint = GoldPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (lang == "ar") "اتصال هاتفي" else "Direct Dial",
                                            color = PlatinumWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Generate Invoice Button
                                Button(
                                    onClick = {
                                        PdfGenerator.generateAndShareInvoicePdf(context, customer, projects)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("generate_invoice_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PictureAsPdf,
                                        contentDescription = "Invoice PDF",
                                        tint = CharcoalDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (lang == "ar") "تصدير وطباعة فاتورة PDF للعميل" else "Generate & Share Invoice (PDF)",
                                        color = CharcoalDark,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // --- CUSTOMER MASTER LIST SCREEN ---
                // Header block
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = Translations.get("customers", lang),
                            color = GoldPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (lang == "ar") "إدارة بيانات وملفات العملاء والشركات" else "Manage corporate customer entities",
                            color = PlatinumGray,
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = { isAddingNew = !isAddingNew },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isAddingNew) CharcoalLight else GoldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("toggle_add_customer")
                    ) {
                        Icon(
                            imageVector = if (isAddingNew) Icons.Default.Close else Icons.Default.Add,
                            contentDescription = null,
                            tint = if (isAddingNew) GoldPrimary else CharcoalDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isAddingNew) {
                                if (lang == "ar") "إلغاء الأمر" else "Cancel"
                            } else {
                                Translations.get("add_cust", lang)
                            },
                            color = if (isAddingNew) GoldPrimary else CharcoalDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                // If expanded, display the adding card form
                if (isAddingNew) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        var name by remember { mutableStateOf("") }
                        var companyName by remember { mutableStateOf("") }
                        var phone by remember { mutableStateOf("") }
                        var whatsapp by remember { mutableStateOf("") }
                        var email by remember { mutableStateOf("") }
                        var address by remember { mutableStateOf("") }
                        var notes by remember { mutableStateOf("") }
                        var initialBalanceStr by remember { mutableStateOf("") }

                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = Translations.get("add_cust", lang),
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text(if (lang == "ar") "اسم العميل الموجه" else "Cardholder / Human Name") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_customer_name"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = GlassBorder,
                                    focusedLabelColor = GoldPrimary,
                                    unfocusedLabelColor = PlatinumGray
                                ),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = companyName,
                                onValueChange = { companyName = it },
                                label = { Text(if (lang == "ar") "اسم الشركة أو المؤسسة" else "Company / Entity Name") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_customer_company"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = GlassBorder,
                                    focusedLabelColor = GoldPrimary,
                                    unfocusedLabelColor = PlatinumGray
                                ),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = phone,
                                    onValueChange = { phone = it },
                                    label = { Text(Translations.get("cust_phone", lang)) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_customer_phone"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GlassBorder,
                                        focusedLabelColor = GoldPrimary,
                                        unfocusedLabelColor = PlatinumGray
                                    ),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = whatsapp,
                                    onValueChange = { whatsapp = it },
                                    label = { Text(Translations.get("cust_whatsapp", lang)) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("input_customer_whatsapp"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GlassBorder,
                                        focusedLabelColor = GoldPrimary,
                                        unfocusedLabelColor = PlatinumGray
                                    ),
                                    singleLine = true
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { email = it },
                                    label = { Text(Translations.get("cust_email", lang)) },
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .testTag("input_customer_email"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GlassBorder,
                                        focusedLabelColor = GoldPrimary,
                                        unfocusedLabelColor = PlatinumGray
                                    ),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = initialBalanceStr,
                                    onValueChange = { initialBalanceStr = it },
                                    label = { Text(if (lang == "ar") "الرصيد المبدئي ج.م" else "Initial Balance EGP") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier
                                        .weight(0.7f)
                                        .testTag("input_customer_balance"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GlassBorder,
                                        focusedLabelColor = GoldPrimary,
                                        unfocusedLabelColor = PlatinumGray
                                    ),
                                    singleLine = true
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = address,
                                onValueChange = { address = it },
                                label = { Text(Translations.get("cust_address", lang)) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_customer_address"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = GlassBorder,
                                    focusedLabelColor = GoldPrimary,
                                    unfocusedLabelColor = PlatinumGray
                                ),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = notes,
                                onValueChange = { notes = it },
                                label = { Text(Translations.get("cust_notes", lang)) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_customer_notes"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = GlassBorder,
                                    focusedLabelColor = GoldPrimary,
                                    unfocusedLabelColor = PlatinumGray
                                )
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (name.isNotEmpty() && phone.isNotEmpty()) {
                                        val balanceVal = initialBalanceStr.toDoubleOrNull() ?: 0.0
                                        val finalWhatsapp = whatsapp.ifEmpty { phone }
                                        viewModel.addCustomer(
                                            name = name,
                                            companyName = companyName,
                                            phone = phone,
                                            whatsapp = finalWhatsapp,
                                            email = email,
                                            address = address,
                                            notes = notes,
                                            balanceEgp = balanceVal
                                        )
                                        isAddingNew = false
                                        name = ""; companyName = ""; phone = ""; whatsapp = ""; email = ""; address = ""; notes = ""; initialBalanceStr = ""
                                        Toast.makeText(context, "تم حفظ العميل وتوجيه القياسات بنجاح", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "الرجاء كشط الاسم ورقم الهاتف على الأقل", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("submit_customer_button")
                            ) {
                                Text(Translations.get("save_cust", lang), color = CharcoalDark, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (lang == "ar") "ابحث عن عميل بالاسم أو الشركة..." else "Search by name, company, or phone...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = GoldPrimary) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("customer_search_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray
                    ),
                    singleLine = true
                )

                // Render lists
                if (filteredList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = null,
                                tint = GoldPrimary.copy(alpha = 0.4f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (lang == "ar") "لا يوجد عملاء مطابق للبحث" else "No customers found matching search criteria.",
                                color = PlatinumGray,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filteredList) { customer ->
                            Card(
                                onClick = { selectedCustomer = customer },
                                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, GlassBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("customer_card_${customer.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                    ) {
                                        Text(
                                            text = customer.name,
                                            color = GoldPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            maxLines = 1
                                        )

                                        if (customer.companyName.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = customer.companyName,
                                                color = PlatinumWhite,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium,
                                                maxLines = 1
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Call,
                                                contentDescription = null,
                                                tint = PlatinumGray,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = customer.phone,
                                                color = PlatinumGray,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(16.dp))

                                    // Balance & Chevron View
                                    Column(
                                        horizontalAlignment = Alignment.End,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            text = if (lang == "ar") "الرصيد المدين" else "Balance",
                                            color = PlatinumGray,
                                            fontSize = 10.sp
                                        )
                                        Text(
                                            text = "${String.format("%,.0f", customer.balanceEgp)} ${if (lang == "ar") "ج.م" else "EGP"}",
                                            color = GoldPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        
                                        Spacer(modifier = Modifier.height(6.dp))
                                        
                                        Icon(
                                            imageVector = if (lang == "ar") Icons.Default.KeyboardArrowLeft else Icons.Default.KeyboardArrowRight,
                                            contentDescription = null,
                                            tint = GoldPrimary.copy(alpha = 0.5f),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailRow(icon: ImageVector, label: String, value: String, testTag: String = "") {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = GoldPrimary,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(18.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = label,
                color = PlatinumGray,
                fontSize = 11.sp
            )
            Text(
                text = value,
                color = PlatinumWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// 7. Quotations Module (Smart Pricing system and Convert-To-Project functionality)
@Composable
fun QuotationsModule(
    viewModel: YaftaViewModel,
    list: List<Quotation>,
    customersList: List<Customer>,
    onPrintQuotation: (Quotation) -> Unit = {}
) {
    val lang = viewModel.language
    val context = LocalContext.current
    var lengthStr by remember { mutableStateOf("") }
    var widthStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var clientName by remember { mutableStateOf("") }
    var clientPhone by remember { mutableStateOf("") }

    var length by remember { mutableStateOf(0.0) }
    var width by remember { mutableStateOf(0.0) }

    LaunchedEffect(lengthStr, widthStr) {
        length = lengthStr.toDoubleOrNull() ?: 0.0
        width = widthStr.toDoubleOrNull() ?: 0.0
    }

    // Calculated equation map
    val calcs = viewModel.calculateSignagePrice(length, width)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(Translations.get("quotations", lang), color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        Translations.get("qtn_new", lang),
                        color = PlatinumWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = clientName,
                        onValueChange = { clientName = it },
                        label = { Text(Translations.get("cust_name", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = clientPhone,
                        onValueChange = { clientPhone = it },
                        label = { Text(Translations.get("cust_phone", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = lengthStr,
                            onValueChange = { lengthStr = it },
                            label = { Text(Translations.get("length", lang)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = widthStr,
                            onValueChange = { widthStr = it },
                            label = { Text(Translations.get("width", lang)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text(Translations.get("notes", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Smart Calculation Display live
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(Translations.get("smart_calculator", lang), color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(
                        modifier = Modifier
                            .background(CharcoalDark, RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CalculationRow(Translations.get("area", lang), "${String.format("%.2f", calcs["area"])} Sqm")
                        CalculationRow(Translations.get("mat_cost", lang), "${String.format("%.2f", calcs["materialCost"])} EGP")
                        CalculationRow(Translations.get("lab_cost", lang), "${String.format("%.2f", calcs["laborCost"])} EGP")
                        CalculationRow(Translations.get("prod_cost", lang), "${String.format("%.2f", calcs["productionCost"])} EGP", isBold = true)
                        CalculationRow(Translations.get("selling_price", lang), "${String.format("%.2f", calcs["sellingPrice"])} EGP", isHighlight = true)
                        CalculationRow(Translations.get("profit", lang), "${String.format("%.2f", calcs["profit"])} EGP")
                        CalculationRow(Translations.get("profit_margin", lang), "${String.format("%.1f", calcs["profitMargin"])} %")
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            if (clientName.isNotEmpty() && length > 0.0 && width > 0.0) {
                                viewModel.addQuotation(clientName, clientPhone, length, width, notes)
                                clientName = ""; clientPhone = ""; lengthStr = ""; widthStr = ""; notes = ""
                                Toast.makeText(context, "تم توليد وحفظ عرض السعر بنجاح", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "الرجاء إدخال اسم العميل والقياسات البرية بصورة صحيحة", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(Translations.get("save_qtn", lang), color = CharcoalDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text(Translations.get("qtn_list", lang), color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        // Quotations database listings
        items(list) { qtn ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(qtn.customerName, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${Translations.get("qtn_no", lang)}: ${qtn.quotationNumber}", color = PlatinumGray, fontSize = 11.sp)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (qtn.status == "Converted") Color.DarkGray else GoldPrimary.copy(alpha = 0.15f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(qtn.status, color = if (qtn.status == "Converted") PlatinumGray else GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("📐 ${qtn.length}m × ${qtn.width}m (${qtn.area} Sqm)", color = PlatinumWhite, fontSize = 12.sp)
                    Text("💵 Total: ${qtn.totalPrice} EGP", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    if (qtn.notes.isNotEmpty()) {
                        Text("📝 Notes: ${qtn.notes}", color = PlatinumGray, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (qtn.status == "Draft") {
                            Button(
                                onClick = {
                                    viewModel.convertQuotationToProjectAndInvoice(qtn)
                                    Toast.makeText(context, "تم تحويل عرض السعر لصفقة مشروع بنجاح", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                modifier = Modifier.weight(1.5f)
                            ) {
                                Icon(Icons.Default.Transform, contentDescription = null, tint = CharcoalDark, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(Translations.get("convert_btn", lang), color = CharcoalDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        IconButton(onClick = { onPrintQuotation(qtn) }) {
                            Icon(Icons.Default.Print, contentDescription = "Print Spec Sheet", tint = GoldPrimary)
                        }

                        IconButton(onClick = { viewModel.deleteQuotation(qtn.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalculationRow(label: String, valStr: String, isBold: Boolean = false, isHighlight: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = if (isHighlight) GoldPrimary else PlatinumGray,
            fontSize = if (isBold || isHighlight) 12.sp else 11.sp,
            fontWeight = if (isBold || isHighlight) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = valStr,
            color = if (isHighlight) GoldPrimary else PlatinumWhite,
            fontSize = if (isBold || isHighlight) 13.sp else 12.sp,
            fontWeight = if (isBold || isHighlight) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// 8. Projects Module (Centralized Project & Advertising Campaign Management Dashboard)
@Composable
fun ProjectsModule(
    viewModel: YaftaViewModel,
    list: List<Project>,
    productionJobs: List<ProductionJob>
) {
    val lang = viewModel.language
    val context = LocalContext.current
    var selectedCampaignId by remember { mutableStateOf<Int?>(null) }
    
    // Detailed checklists remembered locally to track micro-milestones
    val projectChecklists = remember { mutableStateMapOf<Int, List<String>>() }

    // Init selected campaign
    LaunchedEffect(list) {
        if (selectedCampaignId == null && list.isNotEmpty()) {
            selectedCampaignId = list.first().id
        }
    }

    // Interactive deadline editing state
    var editingDeadlineProject by remember { mutableStateOf<Project?>(null) }
    var newStartDate by remember { mutableStateOf("") }
    var newEndDate by remember { mutableStateOf("") }
    var newNotesText by remember { mutableStateOf("") }

    // Tab Filter for main console (All, Active, Completed)
    var filterTab by remember { mutableStateOf("All") }

    // Date calculations helper
    fun getDaysRemaining(endDateStr: String): Long {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val end = sdf.parse(endDateStr)
            if (end != null) {
                // Ignore hours to calculate full days
                val today = sdf.parse(sdf.format(Date()))!!
                val diff = end.time - today.time
                diff / (1000 * 60 * 60 * 24)
            } else {
                5L
            }
        } catch (e: Exception) {
            5L
        }
    }

    // Selected project data
    val selectedProject = list.find { it.id == selectedCampaignId } ?: list.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Luxury Premium Header Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (lang == "ar") "غرفة تحكم ومتابعة الحملات الإعلانية" else "Advertising Campaign Console",
                                color = GoldPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (lang == "ar") "نظام التحكم المركزي لتتبع الخطوط التوجيهية وتصنيع اللوحات المعتمدة" else "Central ERP monitoring for custom signs and branding milestones",
                                color = PlatinumGray,
                                fontSize = 11.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary.copy(alpha = 0.15f))
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                    ) {
                        drawLine(
                            brush = Brush.horizontalGradient(
                                listOf(GoldPrimary, GoldSecondary, Color.Transparent)
                            ),
                            start = Offset.Zero,
                            end = Offset(size.width, 0f),
                            strokeWidth = size.height
                        )
                    }
                }
            }
        }

        // 1. KPI Panel Grid (Tracks Campaign Statistics)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val activeCount = list.count { it.status != "Completed" }
                val completedCount = list.count { it.status == "Completed" }
                val highAlertCount = list.count { getDaysRemaining(it.endDate) <= 2 && it.status != "Completed" }

                KpiCard(
                    title = if (lang == "ar") "الحملات النشطة" else "Active Campaigns",
                    value = "$activeCount",
                    icon = Icons.Default.Assignment,
                    color = GoldPrimary,
                    modifier = Modifier.weight(1f)
                )

                KpiCard(
                    title = if (lang == "ar") "المشاريع المكتملة" else "Completed Signs",
                    value = "$completedCount",
                    icon = Icons.Default.CheckCircle,
                    color = Color(0xFF4CAF50),
                    modifier = Modifier.weight(1f)
                )

                KpiCard(
                    title = if (lang == "ar") "مخاطر تأخير" else "Risks / Urgent",
                    value = "$highAlertCount",
                    icon = Icons.Default.Warning,
                    color = Color(0xFFE91E63),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 2. Main Milestone Timeline Section
        item {
            Text(
                text = if (lang == "ar") "📍 مسار المعالم الرئيسية والـ Checklist للحملة" else "🎯 Campaign Milestones & Step Timeline",
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        if (list.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = PlatinumGray, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (lang == "ar") "لا توجد مشاريع مضافة لعرض المعالم التفاعلية لها." else "No active campaign projects present.",
                                color = PlatinumGray,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        } else {
            // Selected project checklist system
            selectedProject?.let { proj ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                        border = BorderStroke(1.dp, GlassBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Campaign Picker Scrollable row
                            Text(
                                text = if (lang == "ar") "اختر الحملة للمعاينة التفصيلية:" else "Select campaign to inspect details:",
                                color = PlatinumGray,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                list.forEach { campaign ->
                                    val isSelected = campaign.id == selectedCampaignId
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (isSelected) GoldPrimary else CharcoalLight)
                                            .border(1.dp, if (isSelected) GoldSecondary else Color.Transparent, RoundedCornerShape(12.dp))
                                            .clickable { selectedCampaignId = campaign.id }
                                            .padding(horizontal = 12.dp, vertical = 8.dp)
                                            .testTag("campaign_chip_${campaign.id}")
                                    ) {
                                        Text(
                                            text = campaign.title,
                                            color = if (isSelected) CharcoalDark else PlatinumWhite,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Timeline Stages
                            val stages = listOf(
                                "Design" to (if (lang == "ar") "تصميم ومسودة" else "Creative Concept"),
                                "Production" to (if (lang == "ar") "ورش التصنيع" else "Blueprint/CNC"),
                                "Installation" to (if (lang == "ar") "تركيب ومعاينة" else "Worksite Fix"),
                                "Completed" to (if (lang == "ar") "اكتمال وضمان" else "Active Handover")
                            )

                            // Find current status index
                            val currentIndex = when (proj.status) {
                                "Design" -> 0
                                "Production" -> 1
                                "Installation" -> 2
                                "Completed" -> 3
                                else -> 0
                            }

                            // Dynamic timeline view
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                stages.forEachIndexed { idx, (statusKey, statusLabel) ->
                                    val isCompleted = idx < currentIndex
                                    val isActive = idx == currentIndex
                                    val isPending = idx > currentIndex

                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when {
                                                        isActive -> GoldPrimary
                                                        isCompleted -> GoldSecondary
                                                        else -> CharcoalLight
                                                    }
                                                )
                                                .border(
                                                    2.dp,
                                                    if (isActive) PlatinumWhite else Color.Transparent,
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isCompleted) {
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = null,
                                                    tint = PlatinumWhite,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            } else {
                                                Text(
                                                    text = "${idx + 1}",
                                                    color = if (isActive) CharcoalDark else PlatinumGray,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = statusLabel,
                                            color = if (isActive) GoldPrimary else if (isCompleted) PlatinumWhite else PlatinumGray,
                                            fontSize = 9.sp,
                                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1
                                        )
                                    }

                                    // Line Connector (except for the last node)
                                    if (idx < stages.size - 1) {
                                        val lineColor = if (idx < currentIndex) GoldPrimary else CharcoalLight
                                        Canvas(
                                            modifier = Modifier
                                                .weight(0.5f)
                                                .height(2.dp)
                                                .offset(y = (-10).dp)
                                        ) {
                                            drawLine(
                                                color = lineColor,
                                                start = Offset.Zero,
                                                end = Offset(size.width, 0f),
                                                strokeWidth = size.height
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = GlassBorder)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Interactive micro-milestone check checklist
                            Text(
                                text = if (lang == "ar") "قائمة التحقق الميداني والتقني (Checklist):" else "Interactive Engineering Verification Checklist:",
                                color = PlatinumWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            // 6 realistic items
                            val itemsList = listOf(
                                if (lang == "ar") "مراجعة واعتماد ملفات المتجهات وتعديلات الإضاءة" else "Review conceptual vector graphics & client lighting adjustments",
                                if (lang == "ar") "قص وفريز ألواح الأكريليك والكلادينج بالتأثير المطلق" else "Acrylic plate cut, thermal form CNC router processing",
                                if (lang == "ar") "تركيب وتلحيم الشاسيه الحديدي بمقاييس الأمان والوزن" else "Heavy metal chassis welding & anti-corrosion layer checks",
                                if (lang == "ar") "تثبيت محولات ترانس LED وتأمين العزل ضد مياه الأمطار" else "Mount high-wattage LED lights & waterproof silicon isolation",
                                if (lang == "ar") "تأكيد إحداثيات GPS وحفر قواعد التثبيت الجيولوجية" else "Field GPS coordinates log & site stability excavation",
                                if (lang == "ar") "التشغيل التجريبي والتقاط صور تسليم ومراجعة الضمان" else "Full system illumination test run & client digital signoff"
                            )

                            // Initialize if not in checklist map
                            if (!projectChecklists.containsKey(proj.id)) {
                                val precheckCount = (proj.progress * 6).toInt().coerceAtMost(6)
                                projectChecklists[proj.id] = itemsList.take(precheckCount)
                            }

                            val checkedList = projectChecklists[proj.id] ?: emptyList()

                            itemsList.forEachIndexed { index, checklistItem ->
                                val isChecked = checkedList.contains(checklistItem)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val newChecked = if (isChecked) {
                                                checkedList - checklistItem
                                            } else {
                                                checkedList + checklistItem
                                            }
                                            projectChecklists[proj.id] = newChecked
                                            // Update progress slightly for realism based on checks
                                            val newProg = (newChecked.size.toFloat() / 6f).coerceIn(0.0f, 1.0f)
                                            viewModel.updateProjectDetails(proj.copy(progress = newProg))
                                        }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (isChecked) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                                        contentDescription = null,
                                        tint = if (isChecked) GoldPrimary else PlatinumGray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = checklistItem,
                                        color = if (isChecked) PlatinumWhite else PlatinumGray,
                                        fontSize = 11.sp,
                                        textDecoration = if (isChecked) TextDecoration.LineThrough else TextDecoration.None
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Current Production Status Console Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (lang == "ar") "🛠️ الوضع الفني وتصنيع ورش يافطة" else "🛠️ Current Production Status & Controllers",
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                // Horizontal Filter tabs: All, Active, Completed
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val tabOptions = listOf(
                        "All" to (if (lang == "ar") "الكل" else "All"),
                        "Active" to (if (lang == "ar") "نشط" else "Active"),
                        "Completed" to (if (lang == "ar") "مكتمل" else "Done")
                    )
                    tabOptions.forEach { (key, label) ->
                        val selected = filterTab == key
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) GoldPrimary else CharcoalLight)
                                .clickable { filterTab = key }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("filter_tab_$key")
                        ) {
                            Text(
                                text = label,
                                color = if (selected) CharcoalDark else PlatinumWhite,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Match projects based on selected filterTab
        val filteredList = list.filter { proj ->
            when (filterTab) {
                "Active" -> proj.status != "Completed"
                "Completed" -> proj.status == "Completed"
                else -> true
            }
        }

        if (filteredList.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = if (lang == "ar") "لا توجد نتائج مطابقة لمؤشرات الفلتر الحالي." else "No campaigns found matching key filter.",
                            color = PlatinumGray,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        } else {
            items(filteredList) { proj ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = proj.title,
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "👤 Client: ${proj.customerName}",
                                    color = PlatinumWhite,
                                    fontSize = 11.sp
                                )
                            }
                            
                            // High Contrast Phase Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(GoldPrimary.copy(alpha = 0.15f))
                                    .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = proj.status,
                                    color = GoldPrimary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Progress Indicator with custom gold details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (lang == "ar") "معدل الإنجاز الإجمالي:" else "Completion Progress:",
                                color = PlatinumGray,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${(proj.progress * 100).toInt()}%",
                                color = GoldPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { proj.progress },
                            color = GoldPrimary,
                            trackColor = CharcoalLight,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )

                        // Machinery lines status emulation for current worksite / design
                        if (proj.status == "Production") {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CharcoalDark),
                                border = BorderStroke(1.dp, GlassBorder.copy(alpha = 0.15f)),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color.Green)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (lang == "ar") "ماكينة فريز الأكريليك [CNC Router]" else "Active Line: CNC Fiber Laser Router",
                                            color = PlatinumWhite,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = if (lang == "ar") "قيد الحفر بنسبة ٧٤%" else "Running Load: 74%",
                                        color = GoldPrimary,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Interactive Status Advancers Quick Control Row
                        Text(
                            text = if (lang == "ar") "تعديل الحالة التشغيلية الفورية:" else "Shift Operational Stage:",
                            color = PlatinumGray,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val workflowStages = listOf("Design", "Production", "Installation", "Completed")
                            workflowStages.forEach { stageName ->
                                val isCurrent = proj.status == stageName
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isCurrent) GoldPrimary else CharcoalLight)
                                        .clickable {
                                            viewModel.updateProjectStatus(proj, stageName)
                                            Toast.makeText(context, "تم نقل حالة المشروع بنجاح إلى $stageName", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(vertical = 8.dp)
                                        .testTag("stage_btn_${proj.id}_$stageName"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = when(stageName) {
                                            "Design" -> if (lang == "ar") "تصميم" else "Design"
                                            "Production" -> if (lang == "ar") "إنتاج" else "Factory"
                                            "Installation" -> if (lang == "ar") "تركيب" else "Site"
                                            "Completed" -> if (lang == "ar") "تسليم" else "Done"
                                            else -> stageName
                                        },
                                        color = if (isCurrent) CharcoalDark else PlatinumWhite,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Upcoming Deadlines & Target Completion Timeline Module
        item {
            Text(
                text = if (lang == "ar") "📅 المواعيد النهائية وجدول الاستحقاق" else "📅 Project Deadlines & Target Schedules",
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        val uncompletedProjects = list.filter { it.status != "Completed" }
        if (uncompletedProjects.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = if (lang == "ar") "كل المشاريع والحملات الإعلانية تم تسليمها بالكامل!" else "All creative advertising campaigns have been delivered!",
                            color = PlatinumGray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(uncompletedProjects) { proj ->
                val daysRemaining = getDaysRemaining(proj.endDate)
                val isCritical = daysRemaining <= 2
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    border = BorderStroke(1.dp, if (isCritical) Color(0xFFE91E63).copy(alpha = 0.6f) else GlassBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (isCritical) Color(0xFFE91E63) else GoldPrimary)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = proj.title,
                                    color = PlatinumWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            // Dynamic days countdown banner with visual alert styling
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isCritical) Color(0xFFE91E63).copy(alpha = 0.2f)
                                        else GoldPrimary.copy(alpha = 0.1f)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = when {
                                        daysRemaining < 0 -> if (lang == "ar") "🚨 متأخر! (${-daysRemaining} يوم)" else "🚨 Overdue! (${-daysRemaining} Days)"
                                        daysRemaining == 0L -> if (lang == "ar") "⚠️ الاستلام اليوم" else "⚠️ Target Is Today"
                                        else -> if (lang == "ar") "$daysRemaining يوم متبقي" else "$daysRemaining Days Left"
                                    },
                                    color = if (isCritical) Color(0xFFFF8A80) else GoldPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Target duration row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (lang == "ar") "البدء: ${proj.startDate}" else "Start: ${proj.startDate}",
                                    color = PlatinumGray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = if (lang == "ar") "التسليم: ${proj.endDate}" else "Target Deliverable: ${proj.endDate}",
                                    color = if (isCritical) Color(0xFFFF8A80) else PlatinumWhite,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Postpone Action Trigger
                            Button(
                                onClick = {
                                    editingDeadlineProject = proj
                                    newStartDate = proj.startDate
                                    newEndDate = proj.endDate
                                    newNotesText = proj.notes
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCritical) Color(0xFFE91E63) else GoldPrimary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.defaultMinSize(minWidth = 1.dp, minHeight = 1.dp)
                                    .testTag("postpone_btn_${proj.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Event,
                                    contentDescription = null,
                                    tint = CharcoalDark,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (lang == "ar") "تعديل المواعيد" else "Adjust",
                                    color = CharcoalDark,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // In-Context Interactive Postpone/Re-scheduling modal sheet overlay
    editingDeadlineProject?.let { proj ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { editingDeadlineProject = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(2.dp, GoldPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = if (lang == "ar") "تعديل جدولة ومواعيد التسليم" else "Adjust Campaign Deliverable Dates",
                        color = GoldPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = proj.title,
                        color = PlatinumWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = newStartDate,
                        onValueChange = { newStartDate = it },
                        label = { Text(if (lang == "ar") "تاريخ البدء (yyyy-MM-dd)" else "Start Date (yyyy-MM-dd)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GlassBorder,
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newEndDate,
                        onValueChange = { newEndDate = it },
                        label = { Text(if (lang == "ar") "تاريخ التسليم النهائي (yyyy-MM-dd)" else "Target Deadline (yyyy-MM-dd)") },
                        modifier = Modifier.fillMaxWidth().testTag("deadline_input_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GlassBorder,
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newNotesText,
                        onValueChange = { newNotesText = it },
                        label = { Text(if (lang == "ar") "سبب التعديل / ملاحظات إضافية" else "Rescheduling reason / notes") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GlassBorder,
                            focusedTextColor = PlatinumWhite,
                            unfocusedTextColor = PlatinumWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { editingDeadlineProject = null },
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = if (lang == "ar") "إلغاء وجهة" else "Cancel", color = PlatinumWhite)
                        }

                        Button(
                            onClick = {
                                if (newStartDate.isNotEmpty() && newEndDate.isNotEmpty()) {
                                    viewModel.updateProjectDetails(
                                        proj.copy(
                                            startDate = newStartDate,
                                            endDate = newEndDate,
                                            notes = newNotesText
                                        )
                                    )
                                    editingDeadlineProject = null
                                    Toast.makeText(context, "تم حفظ الجدولة وتحديث الإدارة والمستودع", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "الرجاء كشط حقول التواريخ معاً", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.5f).testTag("save_deadline_btn")
                        ) {
                            Text(
                                text = if (lang == "ar") "تأكيد الجدولة" else "Save Schedule",
                                color = CharcoalDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// 9. Design Department Module (Draft Concept submissions and approval checklist)
@Composable
fun DesignDeptModule(viewModel: YaftaViewModel, projects: List<Project>) {
    val lang = viewModel.language
    val context = LocalContext.current
    var fileTitle by remember { mutableStateOf("") }
    var fileStubUri by remember { mutableStateOf("https://example.com/draft_artwork_gold.png") }
    var fileNotes by remember { mutableStateOf("") }
    var selectedProjIndex by remember { mutableStateOf(0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(Translations.get("design_dept", lang), color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        if (projects.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CharcoalMedium), border = BorderStroke(1.dp, GlassBorder)) {
                    Text("لا توجد مشاريع مخرجة حالياً لتحميل التصاميم.", color = PlatinumGray, modifier = Modifier.padding(16.dp))
                }
            }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(Translations.get("add_file", lang), color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Selected project label
                        Text("اختر المشروع المنسوب:", color = PlatinumGray, fontSize = 11.sp)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            projects.forEachIndexed { idx, p ->
                                val selected = selectedProjIndex == idx
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) GoldPrimary else CharcoalLight)
                                        .clickable { selectedProjIndex = idx }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(p.title.take(15) + "..", color = if (selected) CharcoalDark else PlatinumWhite, fontSize = 10.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = fileTitle,
                            onValueChange = { fileTitle = it },
                            label = { Text(Translations.get("file_name_title", lang)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = fileStubUri,
                            onValueChange = { fileStubUri = it },
                            label = { Text(Translations.get("file_path_stub", lang)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = fileNotes,
                            onValueChange = { fileNotes = it },
                            label = { Text(Translations.get("file_notes", lang)) },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                if (fileTitle.isNotEmpty()) {
                                    val targetProj = projects[selectedProjIndex]
                                    viewModel.addDesignFile(targetProj.id, fileTitle, fileStubUri, fileNotes)
                                    fileTitle = ""; fileNotes = ""
                                    Toast.makeText(context, "تم إيداع مسودة العمل واستدعاء قسم المبيعات", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(Translations.get("upload", lang), color = CharcoalDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// 10. Production Department Module
@Composable
fun ProductionModule(viewModel: YaftaViewModel, jobs: List<ProductionJob>) {
    val lang = viewModel.language
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(Translations.get("production", lang), color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Text(Translations.get("prod_title", lang), color = PlatinumGray, fontSize = 12.sp)
        }

        items(jobs) { job ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(job.projectTitle, color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (job.status == "Completed") Color.Gray else GoldPrimary.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(job.status, color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(Translations.get("cost_breakdown", lang), color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Column(
                        modifier = Modifier
                            .background(CharcoalDark, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        CalculationRow("البيع المعاقد عليه:", "${job.sellingPrice} EGP")
                        CalculationRow("تكلفة المشتريات:", "${job.materialCost} EGP")
                        CalculationRow("تكلفة التشغيل والأجور:", "${job.laborCost} EGP")
                        CalculationRow("التكلفة الإنتاجية:", "${job.productionCost} EGP", isBold = true)
                        CalculationRow("الأرباح المحققة:", "${job.profit} EGP", isHighlight = true)
                    }

                    if (job.status != "Completed") {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                viewModel.updateProductionStatus(job, "Completed")
                                Toast.makeText(context, "تم إغلاق طلب الإنتاج بنجاح وترحيل التقرير لخدمات النقل.", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(Translations.get("mark_complete", lang), color = CharcoalDark)
                        }
                    }
                }
            }
        }
    }
}

// 11. Installation Department Module (Field snap & signature draw pad)
@Composable
fun InstallationModule(viewModel: YaftaViewModel, jobs: List<InstallationJob>) {
    val lang = viewModel.language
    val context = LocalContext.current
    var pathLines = remember { mutableStateListOf<List<Offset>>() }
    var currentPath = remember { mutableStateOf<List<Offset>>(emptyList()) }
    var assignedCrew by remember { mutableStateOf("فريق التركيبات الرئيسي") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(Translations.get("installation", lang), color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Text(Translations.get("install_title", lang), color = PlatinumGray, fontSize = 12.sp)
        }

        items(jobs) { job ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(job.projectTitle, color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(GoldPrimary.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(job.status, color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = assignedCrew,
                        onValueChange = { assignedCrew = it },
                        label = { Text(Translations.get("team_assigned", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(Translations.get("signature_box", lang), color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    // Signature Pad Ink Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .background(CharcoalDark, RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(12.dp))
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        currentPath.value = listOf(offset)
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        currentPath.value = currentPath.value + change.position
                                    },
                                    onDragEnd = {
                                        pathLines.add(currentPath.value)
                                        currentPath.value = emptyList()
                                    }
                                )
                            }
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Draw completed lines
                            pathLines.forEach { path ->
                                if (path.size > 1) {
                                    for (i in 0 until path.size - 1) {
                                        drawLine(
                                            color = GoldPrimary,
                                            start = path[i],
                                            end = path[i + 1],
                                            strokeWidth = 3.dp.toPx(),
                                            cap = StrokeCap.Round
                                        )
                                    }
                                }
                            }
                            // Draw active line
                            val active = currentPath.value
                            if (active.size > 1) {
                                for (i in 0 until active.size - 1) {
                                    drawLine(
                                        color = GoldPrimary,
                                        start = active[i],
                                        end = active[i + 1],
                                        strokeWidth = 3.dp.toPx(),
                                        cap = StrokeCap.Round
                                    )
                                }
                            }
                        }

                        IconButton(
                            onClick = { pathLines.clear() },
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Clear", tint = Color.Red)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(Translations.get("gps_mock", lang), color = PlatinumGray, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("LAT: 30.0444° N | LNG: 31.2357° E (القاهرة)", color = PlatinumWhite, fontSize = 11.sp)
                        Button(
                            onClick = { Toast.makeText(context, "تم فحص تتبع GPS وتأكيده للتركيب الميداني", Toast.LENGTH_SHORT).show() },
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                            modifier = Modifier.wrapContentSize()
                        ) {
                            Text(Translations.get("gps_btn", lang), fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            viewModel.updateInstallationJob(job, assignedCrew, "Installed", "", "", "done_path")
                            Toast.makeText(context, "تم قيد تقرير التسليم وتركيب اليافطة وتثبيت الضمان", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(Translations.get("record_field", lang), color = CharcoalDark)
                    }
                }
            }
        }
    }
}

// 12. Inventory Module
@Composable
fun InventoryModule(viewModel: YaftaViewModel, list: List<InventoryItem>) {
    val lang = viewModel.language
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var qtyStr by remember { mutableStateOf("") }
    var alertStr by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("لوح") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(Translations.get("inventory", lang), color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(Translations.get("add_inv", lang), color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(Translations.get("mat_name", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = qtyStr,
                            onValueChange = { qtyStr = it },
                            label = { Text("الكمية المتاحة") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text(Translations.get("unit", lang)) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = alertStr,
                        onValueChange = { alertStr = it },
                        label = { Text(Translations.get("low_alert", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text(Translations.get("barcode", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val qVal = qtyStr.toDoubleOrNull() ?: 0.0
                            val limit = alertStr.toDoubleOrNull() ?: 0.0
                            if (name.isNotEmpty() && barcode.isNotEmpty()) {
                                viewModel.addInventoryItem(name, qVal, limit, unit, barcode)
                                name = ""; qtyStr = ""; alertStr = ""; barcode = ""
                                Toast.makeText(context, "تم إيداع الخامة بنجاح", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(Translations.get("save_material", lang), color = CharcoalDark)
                    }
                }
            }
        }

        // Inventory Listings with stock increment/decrement
        items(list) { item ->
            val alarmTriggered = item.quantity <= item.lowStockAlertLimit
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, if (alarmTriggered) Color.Red.copy(alpha = 0.5f) else GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.materialName, color = if (alarmTriggered) Color.Red else GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${item.quantity} ${item.unit}", color = PlatinumWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Text("🏢 Warehouse: ${item.warehouseName}", color = PlatinumGray, fontSize = 11.sp)
                    Text("🏷️ Barcode: ${item.barcode}", color = PlatinumGray, fontSize = 11.sp)

                    if (alarmTriggered) {
                        Box(
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.Red.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("خطر: المخزون منخفض وجاري طلب توريد!", color = Color.Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.updateInventoryQty(item, 1.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+1 ${item.unit}", color = GoldPrimary, fontSize = 11.sp)
                        }
                        Button(
                            onClick = { viewModel.updateInventoryQty(item, -1.0) },
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("-1 ${item.unit}", color = PlatinumWhite, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

// 13. Suppliers Module
@Composable
fun SuppliersModule(viewModel: YaftaViewModel, list: List<Supplier>) {
    val lang = viewModel.language
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var balance by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(Translations.get("suppliers", lang), color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(Translations.get("add_sup", lang), color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("اسم المورد / الشركة") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text(Translations.get("phone", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = balance,
                        onValueChange = { balance = it },
                        label = { Text(Translations.get("balance_owed", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("قائمة المواد والخدمات") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val bVal = balance.toDoubleOrNull() ?: 0.0
                            if (name.isNotEmpty()) {
                                coroutineScope.launch {
                                    YaftaErpDatabase.getDatabase(context).yaftaErpDao().insertSupplier(
                                        Supplier(name = name, phone = phone, balance = bVal, notes = notes)
                                    )
                                    name = ""; phone = ""; balance = ""; notes = ""
                                    Toast.makeText(context, "تم تسجيل المورد وحفظ القيود", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تسجيل المورد", color = CharcoalDark)
                    }
                }
            }
        }

        items(list) { sup ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(sup.name, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("📞 ${sup.phone}", color = PlatinumWhite, fontSize = 12.sp)
                    Text("💵 المستحقات: ${sup.balance} EGP", color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    if (sup.notes.isNotEmpty()) {
                        Text("📝 الخدمات: ${sup.notes}", color = PlatinumGray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}

// 14. Accounting Module
@Composable
fun FinanceModule(
    viewModel: YaftaViewModel,
    invoices: List<Invoice>,
    expenses: List<Expense>,
    onPrintInvoice: (Invoice) -> Unit = {}
) {
    val lang = viewModel.language
    val context = LocalContext.current
    var expTitle by remember { mutableStateOf("") }
    var expAmount by remember { mutableStateOf("") }
    var expCategory by remember { mutableStateOf("Materials") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(Translations.get("finance", lang), color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        // PNL card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(Translations.get("accounting_pnl", lang), color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    val totalInv = invoices.sumOf { it.totalPrice }
                    val totalPaid = invoices.sumOf { it.paidAmount }
                    val totalExpenses = expenses.sumOf { it.amount }
                    val profit = totalPaid - totalExpenses

                    CalculationRow("إجمالي مبيعات الفواتير:", "$totalInv EGP")
                    CalculationRow("التحصيل الفعلي الصافي:", "$totalPaid EGP")
                    CalculationRow("المصروفات المستهلكة:", "$totalExpenses EGP", isBold = true)
                    HorizontalDivider(color = GlassBorder, modifier = Modifier.padding(vertical = 6.dp))
                    CalculationRow("صافي الزيادة الصافية (P&L):", "$profit EGP", isHighlight = true)
                }
            }
        }

        // Expense Voucher
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(Translations.get("add_exp", lang), color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = expTitle,
                        onValueChange = { expTitle = it },
                        label = { Text(Translations.get("exp_title", lang)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = expAmount,
                        onValueChange = { expAmount = it },
                        label = { Text(Translations.get("exp_amount", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Categories slider
                    val cats = listOf("Materials", "Payroll", "Rent", "Utility", "Tax (VAT)")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        cats.forEach { cat ->
                            val selected = expCategory == cat
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) GoldPrimary else CharcoalLight)
                                    .clickable { expCategory = cat }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(cat, color = if (selected) CharcoalDark else PlatinumWhite, fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val aVal = expAmount.toDoubleOrNull() ?: 0.0
                            if (expTitle.isNotEmpty() && aVal > 0.0) {
                                viewModel.addExpense(expTitle, aVal, expCategory)
                                expTitle = ""; expAmount = ""
                                Toast.makeText(context, "تم ترحيل المصروف التجاري بنجاح", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(Translations.get("save_exp", lang), color = CharcoalDark)
                    }
                }
            }
        }

        // Sells Invoices listings
        item {
            Text(Translations.get("invoice_list", lang), color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        items(invoices) { inv ->
            var payInput by remember { mutableStateOf("") }
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(inv.customerName, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${Translations.get("invoice_no", lang)}: ${inv.invoiceNumber}", color = PlatinumGray, fontSize = 11.sp)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (inv.status == "Paid") Color.Green.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(inv.status, color = if (inv.status == "Paid") Color.Green else Color.Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    CalculationRow("المبلغ الكلي المطلوب:", "${inv.totalPrice} EGP")
                    CalculationRow("ما تم سداده وتأمينه:", "${inv.paidAmount} EGP")
                    CalculationRow("الدفعة المستحقة المتبقية:", "${inv.balance} EGP", isBold = true)

                    if (inv.balance > 0.0) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = payInput,
                                onValueChange = { payInput = it },
                                label = { Text("مبلغ المدفوعة ج.م") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    val valPay = payInput.toDoubleOrNull() ?: 0.0
                                    if (valPay > 0.0) {
                                        viewModel.recordInvoicePayment(inv, valPay, "Cash")
                                        payInput = ""
                                        Toast.makeText(context, "تم قيد الدفعة النقدية للعميل بنجاح", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("سدد", color = CharcoalDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        IconButton(onClick = { onPrintInvoice(inv) }) {
                            Icon(Icons.Default.Print, contentDescription = "Print Invoice", tint = GoldPrimary)
                        }
                    }
                }
            }
        }
    }
}

// 15. Employees Module
@Composable
fun StaffModule(viewModel: YaftaViewModel, employees: List<Employee>) {
    val lang = viewModel.language
    val context = LocalContext.current
    var wName by remember { mutableStateOf("") }
    var wPos by remember { mutableStateOf("") }
    var wWage by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(Translations.get("staff", lang), color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(Translations.get("add_worker", lang), color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = wName,
                        onValueChange = { wName = it },
                        label = { Text("اسم الموظف / الصنايعي الكلي") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = wPos,
                        onValueChange = { wPos = it },
                        label = { Text("المسمى الوظيفي / القسم") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = wWage,
                        onValueChange = { wWage = it },
                        label = { Text(Translations.get("salary_month", lang)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val slStr = wWage.toDoubleOrNull() ?: 0.0
                            if (wName.isNotEmpty() && wPos.isNotEmpty()) {
                                viewModel.addEmployee(wName, wPos, slStr)
                                wName = ""; wPos = ""; wWage = ""
                                Toast.makeText(context, "تم قيد تعيين الملقب بنجاح", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("قيد التعيين المالي", color = CharcoalDark)
                    }
                }
            }
        }

        items(employees) { worker ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                border = BorderStroke(1.dp, GlassBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(worker.name, color = PlatinumWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(worker.position, color = PlatinumGray, fontSize = 11.sp)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(GoldPrimary.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("${worker.attendance} حضور", color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("💵 الراتب الأساسي: ${worker.salary} EGP", color = PlatinumWhite, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.incrementAttendance(worker) },
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(Translations.get("mark_present", lang), color = GoldPrimary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// 16. YAFTA DESIGN STUDIO Canvas Module (Fully interactive draggable layers and custom renders)
@Composable
fun DynamicDesignStudio(viewModel: YaftaViewModel, onExit: () -> Unit) {
    RealProfessionalDesignStudio(viewModel = viewModel, onExit = onExit)
}

// 22. Highly Premium Print Document Dialog - Emulates fully professional physical paper/A4 layout
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrintDocumentDialog(
    title: String,
    docNumber: String,
    customerName: String,
    customerPhone: String,
    dateStr: String,
    details: List<Triple<String, String, String>>,
    notes: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .wrapContentHeight(),
            border = BorderStroke(2.dp, GoldPrimary)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "معاينة النسخة المطبوعة (A4 Spec Sheet)",
                        color = CharcoalMedium,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CharcoalLight)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color.LightGray)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFCFBF9))
                        .border(BorderStroke(1.dp, Color(0xFFE5DDD0)))
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(
                                    text = "YAFTA ADVERTISING",
                                    color = Color(0xFFA67C1E),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Serif
                                )
                                Text(
                                    text = "الرقم التسلسلي: $docNumber",
                                    color = Color.DarkGray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "التاريخ الصادر: $dateStr",
                                    color = Color.Gray,
                                    fontSize = 9.sp
                                )
                            }
                            
                            ProgrammaticLogoShield(
                                modifier = Modifier
                                    .size(70.dp)
                                    .background(Color.Black, RoundedCornerShape(10.dp))
                                    .padding(4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Canvas(modifier = Modifier.fillMaxWidth().height(4.dp)) {
                            drawLine(
                                brush = Brush.horizontalGradient(listOf(Color(0xFFA67C1E), Color(0xFFD4AF37), Color(0xFFA67C1E))),
                                start = Offset(0f, size.height/2),
                                end = Offset(size.width, size.height/2),
                                strokeWidth = 2.dp.toPx()
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = title,
                            color = Color(0xFF0D0D0D),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F7F3)),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFEFECE4)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "بيانات العميل المستهدف:",
                                    color = Color(0xFFA67C1E),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "الاسم الكريم: $customerName",
                                    color = Color.Black,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (customerPhone.isNotEmpty()) {
                                    Text(
                                        text = "الهاتف المحمول: $customerPhone",
                                        color = Color.DarkGray,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0D0D0D))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "البند والبيان الإعلاني", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                            Text(text = "الوصف الفني", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f), textAlign = TextAlign.Center)
                            Text(text = "المبلغ المالي", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        }

                        details.forEach { (item, desc, price) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(BorderStroke(1.dp, Color(0xFFEFECE4)))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = item, color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(2f))
                                Text(text = desc, color = Color.DarkGray, fontSize = 10.sp, modifier = Modifier.weight(1.5f), textAlign = TextAlign.Center)
                                Text(text = price, color = Color(0xFFA67C1E), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "الشروط والأحكام الفنية والتسليم:",
                            color = Color(0xFFA67C1E),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = notes,
                            color = Color.DarkGray,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "توقيع المستلم والعميل", color = Color.Gray, fontSize = 10.sp)
                                Spacer(modifier = Modifier.height(30.dp))
                                Canvas(modifier = Modifier.width(100.dp).height(1.dp)) {
                                    drawLine(color = Color.LightGray, start = Offset.Zero, end = Offset(size.width, 0f))
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "الختم المعتمد وإدارة يافطة", color = Color.Gray, fontSize = 10.sp)
                                Spacer(modifier = Modifier.height(30.dp))
                                Canvas(modifier = Modifier.width(100.dp).height(1.dp)) {
                                    drawLine(color = Color.LightGray, start = Offset.Zero, end = Offset(size.width, 0f))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        Toast.makeText(context, "جاري إعداد محركات الطابعات والشبكة... تم الإرسال بصفة أمر طباعة رسمي بنجاح!", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, tint = CharcoalDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إصدار وطباعة الفاتورة والملف الرسمي", color = CharcoalDark, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// --- DESIGN CANVAS PRODUCTION HELPERS ---
data class MaterialFormula(val nameAr: String, val nameEn: String, val sellingRate: Double, val costRate: Double)

fun generateSvgString(widthCm: Float, heightCm: Float, layers: List<com.example.viewmodel.DesignLayer>): String {
    val sb = java.lang.StringBuilder()
    sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
    sb.append("<!-- Created by YAFTA Design Studio - CAD/Laser Vector Export -->\n")
    sb.append("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" width=\"${widthCm}cm\" height=\"${heightCm}cm\" viewBox=\"0 0 ${widthCm * 10} ${heightCm * 10}\" style=\"background:#000000;\">\n")
    layers.forEach { layer ->
        if (layer.isVisible) {
            when (layer.type) {
                "text" -> {
                    val x = layer.x * 2.5f
                    val y = layer.y * 2.5f
                    val size = layer.fontSize * 1.5f
                    sb.append("  <text x=\"$x\" y=\"$y\" fill=\"${layer.colorHex}\" font-size=\"$size\" font-family=\"Arial, sans-serif\" font-weight=\"bold\" transform=\"rotate(${layer.rotation}, $x, $y)\">${layer.content}</text>\n")
                }
                "shape" -> {
                    val x = layer.x * 2.5f
                    val y = layer.y * 2.5f
                    val w = layer.scaleX * 2.5f
                    val h = layer.scaleY * 2.5f
                    sb.append("  <rect x=\"$x\" y=\"$y\" width=\"$w\" height=\"$h\" fill=\"${layer.colorHex}\" transform=\"rotate(${layer.rotation}, ${x + w/2}, ${y + h/2})\" />\n")
                }
            }
        }
    }
    sb.append("</svg>\n")
    return sb.toString()
}

fun generateDxfString(layers: List<com.example.viewmodel.DesignLayer>): String {
    val sb = java.lang.StringBuilder()
    sb.append("0\nSECTION\n2\nHEADER\n0\nENDSEC\n")
    sb.append("0\nSECTION\n2\nTABLES\n0\nENDSEC\n")
    sb.append("0\nSECTION\n2\nBLOCKS\n0\nENDSEC\n")
    sb.append("0\nSECTION\n2\nENTITIES\n")
    layers.forEach { layer ->
        if (layer.isVisible) {
            when (layer.type) {
                "text" -> {
                    sb.append("0\nTEXT\n")
                    sb.append("8\nYAFTA_TEXT\n")
                    sb.append("10\n${layer.x}\n")
                    sb.append("20\n${-layer.y}\n")
                    sb.append("40\n${layer.fontSize}\n")
                    sb.append("1\n${layer.content}\n")
                    sb.append("50\n${layer.rotation}\n")
                }
                "shape" -> {
                    val x1 = layer.x
                    val y1 = -layer.y
                    val x2 = layer.x + layer.scaleX
                    val y2 = -layer.y - layer.scaleY
                    sb.append("0\nLWPOLYLINE\n")
                    sb.append("8\nYAFTA_CUTLINE\n")
                    sb.append("90\n4\n")
                    sb.append("70\n1\n")
                    sb.append("10\n$x1\n20\n$y1\n")
                    sb.append("10\n$x2\n20\n$y1\n")
                    sb.append("10\n$x2\n20\n$y2\n")
                    sb.append("10\n$x1\n20\n$y2\n")
                }
            }
        }
    }
    sb.append("0\nENDSEC\n0\nEOF\n")
    return sb.toString()
}

fun shareFile(context: android.content.Context, filename: String, content: String, mimeType: String) {
    try {
        val file = java.io.File(context.cacheDir, filename)
        java.io.FileOutputStream(file).use { out ->
            out.write(content.toByteArray(Charsets.UTF_8))
        }
        val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            putExtra(android.content.Intent.EXTRA_SUBJECT, "YAFTA CNC Export - $filename")
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "Export Signage Layout"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Export error: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

