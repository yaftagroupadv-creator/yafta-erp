package com.example.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ActivityLog
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

// Category identifiers
enum class SettingsCategory(val titleAr: String, val titleEn: String, val icon: ImageVector) {
    GENERAL("الإعدادات العامة", "General & Account", Icons.Default.Settings),
    WORKSPACE("بيئة العمل والتصميم", "Workspace & Design", Icons.Default.Brush),
    INTELLIGENCE("الذكاء الاصطناعي", "AI & Intelligence", Icons.Default.Psychology),
    PERFORMANCE("الأداء ومراقبة النظام", "Performance & Monitor", Icons.Default.Speed),
    BACKUP("النسخ الاحتياطي والاستعادة", "Backup & Restore", Icons.Default.Backup)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsModule(viewModel: YaftaViewModel) {
    val context = LocalContext.current
    val lang = viewModel.language
    val clipboardManager = LocalClipboardManager.current

    var selectedCat by remember { mutableStateOf(SettingsCategory.GENERAL) }

    // Dialog state for reset
    var showResetDialog by remember { mutableStateOf(false) }
    // Dialog state for backup JSON
    var showBackupDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }
    // Dialog state for restore JSON
    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreJsonInput by remember { mutableStateOf("") }

    // Search query for logs
    var logSearchQuery by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalDark)
            .testTag("settings_module_root")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalMedium)
                    .border(width = 1.dp, color = GlassBorder)
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(GoldPrimary.copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (lang == "ar") "لوحة التحكم والخيارات الشاملة" else "Settings & Preferences Engine",
                                color = PlatinumWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (lang == "ar") "تحكم كامل ببيئة العمل، الخيارات الافتراضية، وخدمات المزامنة" else "Configure workstation behavior, AI prompts, and database exports",
                                color = PlatinumGray,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Save / Apply Button
                    Button(
                        onClick = {
                            viewModel.saveSettingsToPrefs()
                            viewModel.logOperation("Manual preference synchronization trigger")
                            Toast.makeText(context, if (lang == "ar") "تم حفظ وتطبيق الإعدادات بنجاح!" else "Settings applied and saved successfully!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("apply_settings_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = CharcoalDark)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (lang == "ar") "حفظ وتطبيق الخيارات" else "Save & Sync",
                            color = CharcoalDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Category Selector Hub & Settings Details Side-by-side Layout
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                // Left Tabs Sidebar (Categories)
                Column(
                    modifier = Modifier
                        .width(240.dp)
                        .fillMaxHeight()
                        .background(CharcoalMedium)
                        .border(1.dp, GlassBorder)
                        .padding(vertical = 12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    SettingsCategory.values().forEach { cat ->
                        val isSelected = selectedCat == cat
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedCat = cat }
                                .background(if (isSelected) CharcoalLight else Color.Transparent)
                                .border(
                                    width = if (isSelected) 1.dp else 0.dp,
                                    color = if (isSelected) GlassBorder else Color.Transparent
                                )
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = cat.icon,
                                contentDescription = null,
                                tint = if (isSelected) GoldPrimary else PlatinumGray,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = if (lang == "ar") cat.titleAr else cat.titleEn,
                                color = if (isSelected) GoldPrimary else PlatinumWhite,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))
                    HorizontalDivider(color = GlassBorder, modifier = Modifier.padding(16.dp))

                    // Short Cut Default Reset Footer
                    TextButton(
                        onClick = { showResetDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .testTag("reset_defaults_btn"),
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF5350))
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == "ar") "إعادة ضبط المصنع" else "Reset to Defaults",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Detail Panel View Frame
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(20.dp)
                ) {
                    AnimatedContent(
                        targetState = selectedCat,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(150))
                        },
                        label = "SettingsDetailTransition"
                    ) { activeCat ->
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            when (activeCat) {
                                SettingsCategory.GENERAL -> {
                                    GeneralAccountSettingsBlock(viewModel, lang)
                                }
                                SettingsCategory.WORKSPACE -> {
                                    WorkspaceDesignSettingsBlock(viewModel, lang)
                                }
                                SettingsCategory.INTELLIGENCE -> {
                                    AiSettingsBlock(viewModel, lang)
                                }
                                SettingsCategory.PERFORMANCE -> {
                                    PerformanceMonitorSettingsBlock(viewModel, lang, logSearchQuery) {
                                        logSearchQuery = it
                                    }
                                }
                                SettingsCategory.BACKUP -> {
                                    BackupRestoreSettingsBlock(
                                        viewModel = viewModel,
                                        lang = lang,
                                        onExportBackup = {
                                            backupJsonText = viewModel.exportSettingsJson()
                                            clipboardManager.setText(AnnotatedString(backupJsonText))
                                            showBackupDialog = true
                                        },
                                        onImportRestore = {
                                            restoreJsonInput = ""
                                            showRestoreDialog = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Dialog: Confirm Reset
        if (showResetDialog) {
            AlertDialog(
                onDismissRequest = { showResetDialog = false },
                containerColor = CharcoalMedium,
                title = {
                    Text(
                        text = if (lang == "ar") "تأكيد إعادة الضبط الافتراضي" else "Confirm Reset Defaults",
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = if (lang == "ar")
                            "هل أنت متأكد من رغبتك في إعادة ضبط جميع الإعدادات والخيارات الفنية للقيم القياسية للمصنع؟ هذا الإجراء فوري وسيلغي التخصيصات الحالية الحالية."
                        else
                            "Are you sure you want to revert all system parameters and customization options to factory standards? This cannot be undone.",
                        color = PlatinumWhite,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF5350)),
                        onClick = {
                            viewModel.resetSettingsToDefaults()
                            showResetDialog = false
                            Toast.makeText(context, if (lang == "ar") "تمت إعادة ضبط القيم بنجاح!" else "Variables reverted to standard defaults!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text(text = if (lang == "ar") "إعادة ضبط وإلغاء التخصيص" else "Yes, Reset", color = PlatinumWhite)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showResetDialog = false }) {
                        Text(text = if (lang == "ar") "إلغاء التراجع" else "Cancel", color = PlatinumGray)
                    }
                }
            )
        }

        // Dialog: Export Backup JSON
        if (showBackupDialog) {
            AlertDialog(
                onDismissRequest = { showBackupDialog = false },
                containerColor = CharcoalMedium,
                title = {
                    Text(
                        text = if (lang == "ar") "طلب ملف النسخة الاحتياطية" else "Settings Backup Archive",
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (lang == "ar")
                                "تم توليد أرقام الإعدادات الكلية وحفظها بنجاح داخل الحافظة للجهاز تلقائياً! يمكنك استخدام هذا الرمز لاستيراد الإعدادات في أي جهاز آخر:"
                            else
                                "Preferences archived and copied to clipboard successfully! Use this encoded JSON structure to re-import at any time:",
                            color = PlatinumWhite,
                            fontSize = 12.sp
                        )
                        OutlinedTextField(
                            value = backupJsonText,
                            onValueChange = {},
                            readOnly = true,
                            textStyle = androidx.compose.ui.text.TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = GoldSecondary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = GlassBorder,
                                focusedContainerColor = CharcoalDark,
                                unfocusedContainerColor = CharcoalDark
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        onClick = { showBackupDialog = false }
                    ) {
                        Text(text = if (lang == "ar") "إغلاق النافذة" else "Done", color = CharcoalDark)
                    }
                }
            )
        }

        // Dialog: Import Restore JSON
        if (showRestoreDialog) {
            AlertDialog(
                onDismissRequest = { showRestoreDialog = false },
                containerColor = CharcoalMedium,
                title = {
                    Text(
                        text = if (lang == "ar") "استيراد واستعادة الإعدادات" else "Import Settings Backup",
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (lang == "ar")
                                "ألصق رمز الإعدادات المشفر (JSON) المستخرج سابقاً هنا ليقوم محرك النظام بتحليله وتطبيقه:"
                            else
                                "Paste the archived settings JSON payload below to reconstruct settings across modules:",
                            color = PlatinumWhite,
                            fontSize = 12.sp
                        )
                        OutlinedTextField(
                            value = restoreJsonInput,
                            onValueChange = { restoreJsonInput = it },
                            placeholder = { Text("{ ... }", color = PlatinumGray) },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = PlatinumWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .testTag("import_settings_field"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = GlassBorder,
                                focusedContainerColor = CharcoalDark,
                                unfocusedContainerColor = CharcoalDark
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        onClick = {
                            val success = viewModel.importSettingsJson(restoreJsonInput)
                            showRestoreDialog = false
                            if (success) {
                                viewModel.logOperation("Backup settings imported archive")
                                Toast.makeText(context, if (lang == "ar") "تم استيراد النسخة الاحتياطية بنجاح!" else "Backup applied and loaded perfectly!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, if (lang == "ar") "فشل استيراد التنسيق غير صالح!" else "Error: Invalid JSON payload structure!", Toast.LENGTH_LONG).show()
                            }
                        }
                    ) {
                        Text(text = if (lang == "ar") "استعادة وتطبيق الآن" else "Restore Now", color = CharcoalDark)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showRestoreDialog = false }) {
                        Text(text = if (lang == "ar") "إلغاء الأمر" else "Cancel", color = PlatinumGray)
                    }
                }
            )
        }
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            color = GoldPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// -------------------------------------------------------------
// 1. GENERAL & ACCOUNT SETTINGS BLOCK
// -------------------------------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GeneralAccountSettingsBlock(viewModel: YaftaViewModel, lang: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "خيارات النظام العامة واللغة" else "General Options & Language",
                icon = Icons.Default.Public
            )

            // Language Switch Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "لغة واجهة التطبيق الافتراضية" else "Primary Localization Language",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "قم باختيار اللغة الافتراضية لتغيير نصوص وجداول الـ ERP فورا" else "Change system navigation elements and database tables quickly",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                Row(
                    modifier = Modifier
                        .background(CharcoalDark, RoundedCornerShape(8.dp))
                        .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val activeColor = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                    val inactiveColor = ButtonDefaults.buttonColors(containerColor = Color.Transparent)

                    Button(
                        onClick = {
                            viewModel.language = "ar"
                            viewModel.saveSettingsToPrefs()
                        },
                        colors = if (lang == "ar") activeColor else inactiveColor,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            "العربية",
                            color = if (lang == "ar") CharcoalDark else PlatinumWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.language = "en"
                            viewModel.saveSettingsToPrefs()
                        },
                        colors = if (lang == "en") activeColor else inactiveColor,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            "English",
                            color = if (lang == "en") CharcoalDark else PlatinumWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            HorizontalDivider(color = GlassBorder)

            // Currency Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "وحدة العملة المقررة بالحسابات" else "Default Accounting Currency",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "تحديد العملة الافتراضية للبيع والإنتاج والمصروفات بالتقارير الماليّة" else "Decide default symbol on quotation invoices and receipts",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                var currencyExpanded by remember { mutableStateOf(false) }
                Box {
                    Button(
                        onClick = { currencyExpanded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                        border = BorderStroke(1.dp, GlassBorder),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(viewModel.defaultCurrency, color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = currencyExpanded,
                        onDismissRequest = { currencyExpanded = false },
                        modifier = Modifier.background(CharcoalMedium)
                    ) {
                        listOf("EGP", "USD", "SAR", "AED", "EUR").forEach { curr ->
                            DropdownMenuItem(
                                text = { Text(curr, color = PlatinumWhite, fontSize = 13.sp) },
                                onClick = {
                                    viewModel.defaultCurrency = curr
                                    viewModel.saveSettingsToPrefs()
                                    viewModel.logOperation("Changed default transaction currency to $curr")
                                    currencyExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = GlassBorder)

            // System notifications
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "تفعيل التنبيهات وإشعارات الحركة" else "Enable Operations Alerts & Push",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "تنبيهك فور تغيير حالة تصميم أو اقتراب نفاذ خامة من المخازن" else "Warn automatically when materials hit thresholds or jobs change state",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = viewModel.notificationEnabled,
                    onCheckedChange = {
                        viewModel.notificationEnabled = it
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Toggled system notifications to $it")
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldPrimary,
                        checkedTrackColor = GoldPrimary.copy(alpha = 0.4f),
                        uncheckedThumbColor = PlatinumGray,
                        uncheckedTrackColor = CharcoalDark
                    )
                )
            }

            HorizontalDivider(color = GlassBorder)

            // App secure lock
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "القفل الآمن وتأكيد الهوية" else "Biometric Application Lock",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "طلب كلمة مرور لتأكيد الدخول للنظام لحماية البيانات السرية" else "Require passkey authentication before accessing workspace records",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = viewModel.appLockEnabled,
                    onCheckedChange = {
                        viewModel.appLockEnabled = it
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Toggled security passkey lock to $it")
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldPrimary,
                        checkedTrackColor = GoldPrimary.copy(alpha = 0.4f),
                        uncheckedThumbColor = PlatinumGray,
                        uncheckedTrackColor = CharcoalDark
                    )
                )
            }
        }
    }

    // Account settings
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "بيانات الحساب والصلاحيات الفعالة" else "Account Profile & Permissions",
                icon = Icons.Default.Badge
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Profile Avatar with user initial
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(
                            brush = Brush.verticalGradient(listOf(GoldPrimary, GoldSecondary)),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    val initial = (viewModel.currentUser?.name?.take(1)?.uppercase() ?: "A")
                    Text(
                        text = initial,
                        color = CharcoalDark,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = viewModel.currentUser?.name ?: "Admen",
                        color = PlatinumWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = viewModel.currentUser?.email ?: "admin@yafta.com",
                        color = GoldSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (lang == "ar") "الصلاحية الأساسية بالنظام: مدير النظام العام Admin" else "Primary Role: Fully-Privileged Admin Authority",
                        color = PlatinumGray,
                        fontSize = 10.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .background(GoldPrimary.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                        .border(1.dp, GoldPrimary, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (lang == "ar") "مُفَعَّل" else "ACTIVE",
                        color = GoldPrimary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                var showEditProfileDialog by remember { mutableStateOf(false) }
                
                TextButton(
                    onClick = { showEditProfileDialog = true },
                    colors = ButtonDefaults.textButtonColors(contentColor = GoldPrimary)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (lang == "ar") "تعديل الملف الشخصي" else "Edit Profile Credentials",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (showEditProfileDialog) {
                    var editName by remember { mutableStateOf(viewModel.currentUser?.name ?: "") }
                    var editEmail by remember { mutableStateOf(viewModel.currentUser?.email ?: "") }
                    var editPassword by remember { mutableStateOf(viewModel.currentUser?.password ?: "") }
                    
                    AlertDialog(
                        onDismissRequest = { showEditProfileDialog = false },
                        title = {
                            Text(
                                text = if (lang == "ar") "تحديث بيانات الحساب الشخصي" else "Update Credentials",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                        },
                        containerColor = CharcoalMedium,
                        textContentColor = PlatinumWhite,
                        text = {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                OutlinedTextField(
                                    value = editName,
                                    onValueChange = { editName = it },
                                    label = { Text(if (lang == "ar") "الاسم الجديد" else "New Display Name") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GlassBorder,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = PlatinumWhite,
                                        focusedLabelColor = GoldPrimary,
                                        unfocusedLabelColor = PlatinumGray,
                                        focusedContainerColor = CharcoalLight,
                                        unfocusedContainerColor = CharcoalLight
                                    ),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = editEmail,
                                    onValueChange = { editEmail = it },
                                    label = { Text(if (lang == "ar") "البريد الإلكتروني الجديد" else "New Email Address") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GlassBorder,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = PlatinumWhite,
                                        focusedLabelColor = GoldPrimary,
                                        unfocusedLabelColor = PlatinumGray,
                                        focusedContainerColor = CharcoalLight,
                                        unfocusedContainerColor = CharcoalLight
                                    ),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = editPassword,
                                    onValueChange = { editPassword = it },
                                    label = { Text(if (lang == "ar") "كلمة المرور الجديدة" else "New Secure Password") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = GlassBorder,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = PlatinumWhite,
                                        focusedLabelColor = GoldPrimary,
                                        unfocusedLabelColor = PlatinumGray,
                                        focusedContainerColor = CharcoalLight,
                                        unfocusedContainerColor = CharcoalLight
                                    ),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    val current = viewModel.currentUser
                                    if (current != null && editName.isNotBlank() && editEmail.isNotBlank()) {
                                        val updated = current.copy(
                                            name = editName,
                                            email = editEmail,
                                            password = editPassword
                                        )
                                        viewModel.addOrUpdateUser(updated)
                                    }
                                    showEditProfileDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                            ) {
                                Text(
                                    text = if (lang == "ar") "تأكيد وتحديث" else "Save & Apply",
                                    color = CharcoalDark,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showEditProfileDialog = false }) {
                                Text(
                                    text = if (lang == "ar") "إلغاء" else "Cancel",
                                    color = PlatinumGray
                                )
                            }
                        }
                    )
                }
            }

            HorizontalDivider(color = GlassBorder)

            // Current role custom simulation selector in settings
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "محاكاة الرتبة التشغيليّة" else "Access Level Simulation Role",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "تغيير رتبة تسجيل الدخول مؤقتاً لتجربة لوحات الموظفين المختلفة" else "Swap roles to test designers, production masters, or accountant dashboards",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                var roleExpanded by remember { mutableStateOf(false) }
                Box {
                    Button(
                        onClick = { roleExpanded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                        border = BorderStroke(1.dp, GlassBorder),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(viewModel.currentRole, color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = roleExpanded,
                        onDismissRequest = { roleExpanded = false },
                        modifier = Modifier.background(CharcoalMedium)
                    ) {
                        listOf("Admin", "Designer", "Production", "Installer", "Accountant").forEach { roleName ->
                            DropdownMenuItem(
                                text = { Text(roleName, color = PlatinumWhite, fontSize = 13.sp) },
                                onClick = {
                                    viewModel.currentRole = roleName
                                    viewModel.logOperation("Simulated role swapped to $roleName")
                                    roleExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 2. WORKSPACE & DESIGN SETTINGS BLOCK
// -------------------------------------------------------------
object BrandIdentityState {
    var customLogoPath by mutableStateOf("")
}

@Composable
fun WorkspaceDesignSettingsBlock(viewModel: YaftaViewModel, lang: String) {
    val context = LocalContext.current

    val logoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    val logoFile = java.io.File(context.filesDir, "custom_brand_logo.png")
                    logoFile.outputStream().use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                    viewModel.customLogoUri = logoFile.absolutePath
                    viewModel.saveSettingsToPrefs()
                    
                    // Force update global state
                    BrandIdentityState.customLogoPath = logoFile.absolutePath
                    
                    viewModel.logOperation(if (lang == "ar") "تم تفعيل وتثبيت الشعار المخصص للمنشأة" else "Successfully configured and copied custom brand logo file")
                    Toast.makeText(context, if (lang == "ar") "تم حفظ وتفعيل شعارك الجديد بنجاح!" else "Brand logo copied and activated successfully!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                viewModel.logOperation("Failed to import custom logo: ${e.message}")
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // 1. BRAND IDENTITY CARD
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "الهوية البصرية واللوجو المخصص للمنشأة" else "Enterprise Brand & Visual Identity",
                icon = Icons.Default.CameraAlt
            )

            Text(
                text = if (lang == "ar") 
                    "بما أنك تستخدم تطبيق (يافطة) عبر متصفح الهاتف، يمكنك هنا رفع واستبدال اللوجو الرئيسي للمنشأة مباشرة من ألبوم الصور بهاتفك دون الحاجة لرفع ملف logo.png يدويًا في مجلدات الكود. سيظهر الشعار الجديد فورًا في كافة الفواتير، عروض الأسعار، المطبوعات، ومعاينات الاستوديو."
                    else "Configure and update your custom company brand logo directly from your device storage instead of manually editing project resource folders. This logo is automatically rendered on sidebars, client portals, design layers, and printable commercial bills.",
                color = PlatinumGray,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                textAlign = TextAlign.Start
            )

            Row(
                modifier = Modifier.fillMaxWidth().background(CharcoalDark, RoundedCornerShape(12.dp)).border(1.dp, GlassBorder, RoundedCornerShape(12.dp)).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Large Preview Area
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(CharcoalMedium, RoundedCornerShape(8.dp))
                        .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ProgrammaticLogoShield(modifier = Modifier.fillMaxSize())
                }

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (viewModel.customLogoUri.isNotEmpty()) (if (lang == "ar") "شعار مخصص نشط حاليًا" else "Custom Logo Active") else (if (lang == "ar") "الشعار الافتراضي للنظام" else "System Placeholder Active"),
                        color = if (viewModel.customLogoUri.isNotEmpty()) GoldPrimary else PlatinumWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (viewModel.customLogoUri.isNotEmpty()) (if (lang == "ar") "تم التحميل من ذاكرة الهاتف" else "Loaded from app filesDir directory") else (if (lang == "ar") "لوجو يافطة الكلاسيكي" else "Using default 3D vector shield"),
                        color = PlatinumGray,
                        fontSize = 10.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                        Button(
                            onClick = { logoLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(32.dp).testTag("select_custom_logo_btn")
                        ) {
                            Text(if (lang == "ar") "اختيار الشعار" else "Select Logo", color = CharcoalDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        if (viewModel.customLogoUri.isNotEmpty()) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.customLogoUri = ""
                                    viewModel.saveSettingsToPrefs()
                                    BrandIdentityState.customLogoPath = ""
                                    viewModel.logOperation(if (lang == "ar") "استعادة الشعار الافتراضي" else "Restored default system logo")
                                    Toast.makeText(context, if (lang == "ar") "تمت استعادة الشعار الافتراضي" else "Reverted to default logo", Toast.LENGTH_SHORT).show()
                                },
                                border = BorderStroke(1.dp, Color(0xFFEF5350)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF5350)),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(32.dp).testTag("reset_custom_logo_btn")
                            ) {
                                Text(if (lang == "ar") "حذف" else "Remove", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // 2. MEASUREMENT CALIBRATION CARD (Original)
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "خيارات القياس وبيئة المحاكاة العريضة" else "Workspace Calibration & Metrics",
                icon = Icons.Default.Straighten
            )

            // Measurement units default
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "وحدات القياس الافتراضيّة" else "Default Base Estimating Unit",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "الوحدة القياسية لتحديد أطوال وأعراض وخامات عروض الأسعار الذكيّة" else "Select primary target dimension unit for signage calculations",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                Row(
                    modifier = Modifier
                        .background(CharcoalDark, RoundedCornerShape(8.dp))
                        .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("m", "cm", "mm", "inch").forEach { unit ->
                        val isSelected = viewModel.defaultUnit == unit
                        Button(
                            onClick = {
                                viewModel.defaultUnit = unit
                                viewModel.saveSettingsToPrefs()
                                viewModel.logOperation("Changed default workspace unit metric to $unit")
                            },
                            colors = if (isSelected) ButtonDefaults.buttonColors(containerColor = GoldPrimary) else ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text(
                                text = unit,
                                color = if (isSelected) CharcoalDark else PlatinumWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = GlassBorder)

            // Auto save workspace
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "معدل الحفظ التلقائي للاستوديو" else "Design Auto-Save Interval",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "الفاصل الزمني لحفظ طبقات اللوحات النشطة للخلفية (${viewModel.autoSaveInterval} دقائق)" else "Minutes between capturing active custom layouts to local draft (${viewModel.autoSaveInterval}m)",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                Slider(
                    value = viewModel.autoSaveInterval.toFloat(),
                    onValueChange = {
                        viewModel.autoSaveInterval = it.toInt()
                    },
                    onValueChangeFinished = {
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Configured canvas auto-save time interval to ${viewModel.autoSaveInterval} minutes")
                    },
                    valueRange = 1f..60f,
                    modifier = Modifier.width(130.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = GoldPrimary,
                        activeTrackColor = GoldPrimary,
                        inactiveTrackColor = CharcoalDark
                    )
                )
            }

            HorizontalDivider(color = GlassBorder)

            // Canvas Grid snap
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "المحاذاة التلقائية على خطوط الشبكة" else "Snap Layers to Workstation Grid",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "المحاذاة المغناطيسية للنصوص والشعارات والأشكال للحواف فورا" else "Magnetically snap typography and stickers to geometric canvas lines",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = viewModel.defaultGridSnap,
                    onCheckedChange = {
                        viewModel.defaultGridSnap = it
                        viewModel.snapToGrid = it
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Toggled magnetic workspace grid snap to $it")
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldPrimary,
                        checkedTrackColor = GoldPrimary.copy(alpha = 0.4f),
                        uncheckedThumbColor = PlatinumGray,
                        uncheckedTrackColor = CharcoalDark
                    )
                )
            }
        }
    }

    // Design layout customizations
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "خصائص استوديو التصميم والخطوط والطبقات" else "Visual Studio Brush, Typography & Viewports",
                icon = Icons.Default.Palette
            )

            // Default Font Name Selection
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "خط الكتابة العربي الافتراضي" else "Default Studio Typography Asset",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "الخط المعتمد عند إنشاء طبقة نصية جديدة في لوحة تصميم الإعلانات" else "Google Fonts asset applied automatically to newly generated texts",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                var fontExpanded by remember { mutableStateOf(false) }
                Box {
                    Button(
                        onClick = { fontExpanded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                        border = BorderStroke(1.dp, GlassBorder),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(viewModel.defaultFontName, color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = fontExpanded,
                        onDismissRequest = { fontExpanded = false },
                        modifier = Modifier.background(CharcoalMedium)
                    ) {
                        viewModel.installedFonts.forEach { font ->
                            DropdownMenuItem(
                                text = { Text(font, color = PlatinumWhite, fontSize = 13.sp) },
                                onClick = {
                                    viewModel.defaultFontName = font
                                    viewModel.saveSettingsToPrefs()
                                    viewModel.logOperation("Changed default studio font typography to $font")
                                    fontExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = GlassBorder)

            // Default brush color hex
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "لون الريشة النشطة الافتراضي" else "Primary Canvas Pen Ink Hex",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "اللون لطبقة الفرشاة وتفنيشات الرسم بالفأرة أو القلم" else "Solid color code utilized when free-drawing bounding shapes",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                val colorsList = listOf("#D4AF37", "#EF5350", "#4CAF50", "#2196F3", "#9C27B0", "#FFFFFF")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    colorsList.forEach { hex ->
                        val selected = viewModel.defaultBrushColor == hex
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(Color(android.graphics.Color.parseColor(hex)), CircleShape)
                                .border(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) GoldPrimary else GlassBorder,
                                    shape = CircleShape
                                )
                                .clickable {
                                    viewModel.defaultBrushColor = hex
                                    viewModel.saveSettingsToPrefs()
                                    viewModel.logOperation("Updated basic studio drawing ink hex to $hex")
                                }
                        )
                    }
                }
            }

            HorizontalDivider(color = GlassBorder)

            // UI Panels View custom toggles
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "تخصيص اللوحات وعناصر العرض" else "Customize UX Workspace Panes",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "تبديل حالة النوافذ الجانبية وخطوط القطع والهوامش لاستغلال المساحات" else "Enable/Disable viewport tools, side anchors to fit screen ratios",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (lang == "ar") "اليسار" else "Left", color = PlatinumGray, fontSize = 9.sp)
                        Checkbox(
                            checked = viewModel.showLeftPanel,
                            onCheckedChange = {
                                viewModel.showLeftPanel = it
                                viewModel.saveSettingsToPrefs()
                            },
                            colors = CheckboxDefaults.colors(checkedColor = GoldPrimary, checkmarkColor = CharcoalDark)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (lang == "ar") "اليمين" else "Right", color = PlatinumGray, fontSize = 9.sp)
                        Checkbox(
                            checked = viewModel.showRightPanel,
                            onCheckedChange = {
                                viewModel.showRightPanel = it
                                viewModel.saveSettingsToPrefs()
                            },
                            colors = CheckboxDefaults.colors(checkedColor = GoldPrimary, checkmarkColor = CharcoalDark)
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (lang == "ar") "الشبكة" else "Grid", color = PlatinumGray, fontSize = 9.sp)
                        Checkbox(
                            checked = viewModel.canvasGridVisible,
                            onCheckedChange = {
                                viewModel.canvasGridVisible = it
                                viewModel.saveSettingsToPrefs()
                            },
                            colors = CheckboxDefaults.colors(checkedColor = GoldPrimary, checkmarkColor = CharcoalDark)
                        )
                    }
                }
            }

            HorizontalDivider(color = GlassBorder)

            // Manage Fonts & Templates Area
            // Fonts installer
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (lang == "ar") "إدارة الخطوط المثبتة بالنظام" else "Installed Workstation Fonts Inventory",
                    color = PlatinumWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                var newFontInput by remember { mutableStateOf("") }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newFontInput,
                        onValueChange = { newFontInput = it },
                        placeholder = { Text(if (lang == "ar") "اسم خط Google Fonts جديد..." else "Type new web font name...", fontSize = 11.sp, color = PlatinumGray) },
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("new_font_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GlassBorder,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = PlatinumWhite),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            if (newFontInput.isNotBlank() && !viewModel.installedFonts.contains(newFontInput)) {
                                viewModel.installedFonts.add(newFontInput.trim())
                                viewModel.logOperation("Installed design typography resource: $newFontInput")
                                Toast.makeText(context, if (lang == "ar") "تم تثبيت الخط بنجاح في الاستوديو!" else "Aesthetic font loaded successfully!", Toast.LENGTH_SHORT).show()
                                newFontInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                        border = BorderStroke(1.dp, GoldPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier.height(42.dp)
                    ) {
                        Text(if (lang == "ar") "تثبيت الخط" else "Install", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                FlowRowLayout(modifier = Modifier.fillMaxWidth()) {
                    viewModel.installedFonts.forEach { fName ->
                        Box(
                            modifier = Modifier
                                .padding(end = 6.dp, bottom = 6.dp)
                                .background(CharcoalDark, RoundedCornerShape(20.dp))
                                .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(fName, color = PlatinumWhite, fontSize = 11.sp, fontFamily = FontFamily.Serif)
                                if (fName != "Cairo" && fName != "Tajawal") {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Uninstall Font",
                                        tint = Color(0xFFEF5350),
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clickable {
                                                viewModel.installedFonts.remove(fName)
                                                if (viewModel.defaultFontName == fName) {
                                                    viewModel.defaultFontName = "Cairo"
                                                }
                                                viewModel.logOperation("Removed custom font resource: $fName")
                                            }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Custom flow row layout helper to list fonts cleanly inside a dynamic grid wrapping automatically
@Composable
fun FlowRowLayout(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    androidx.compose.ui.layout.Layout(
        content = content,
        modifier = modifier
    ) { measurables, constraints ->
        var xPosition = 0
        var yPosition = 0
        var rowHeight = 0
        val placeables = measurables.map { measurable ->
            val placeable = measurable.measure(constraints)
            if (xPosition + placeable.width > constraints.maxWidth) {
                xPosition = 0
                yPosition += rowHeight
                rowHeight = 0
            }
            rowHeight = Math.max(rowHeight, placeable.height)
            xPosition += placeable.width
            placeable
        }

        layout(constraints.maxWidth, Math.max(yPosition + rowHeight, 10)) {
            var currentX = 0
            var currentY = 0
            var maxH = 0
            placeables.forEach { placeable ->
                if (currentX + placeable.width > constraints.maxWidth) {
                    currentX = 0
                    currentY += maxH
                    maxH = 0
                }
                placeable.placeRelative(currentX, currentY)
                maxH = Math.max(maxH, placeable.height)
                currentX += placeable.width
            }
        }
    }
}

// -------------------------------------------------------------
// 3. AI SETTINGS BLOCK
// -------------------------------------------------------------
@Composable
fun AiSettingsBlock(viewModel: YaftaViewModel, lang: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "محرك الذكاء الاصطناعي التوليدي وإعدادات الخادم" else "Generative AI Core & Cloud Models",
                icon = Icons.Default.Psychology
            )

            // LLM Select
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "نموذج الاستدلال والابتكار الافتراضي" else "Target AI Processing Model",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "النموذج المستخدم لتحليل جداول عروض أسعار النيون والكلادينج فوراً" else "Define which cloud parameter weights generate creative copy suggestions",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                var modelExpanded by remember { mutableStateOf(false) }
                Box {
                    Button(
                        onClick = { modelExpanded = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                        border = BorderStroke(1.dp, GlassBorder),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(viewModel.selectedAiModel, color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = modelExpanded,
                        onDismissRequest = { modelExpanded = false },
                        modifier = Modifier.background(CharcoalMedium)
                    ) {
                        listOf("gemini-1.5-flash", "gemini-1.5-pro", "gemini-2.0-flash-exp", "yafta-local-neural-v2").forEach { model ->
                            DropdownMenuItem(
                                text = { Text(model, color = PlatinumWhite, fontSize = 13.sp) },
                                onClick = {
                                    viewModel.selectedAiModel = model
                                    viewModel.saveSettingsToPrefs()
                                    viewModel.logOperation("Changed default AI inference model weights to $model")
                                    modelExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = GlassBorder)

            // Temperature slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "معدل الإبداعية (Temperature)" else "AI Temperature (Creativity)",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "المستويات العالية تعطي اقتراحات إبداعية عريضة، والمستويات المنخفضة تعطي حسابات اقتصادية دقيقة (${String.format("%.2f", viewModel.aiTemperature)})" else "Higher values generate loose artistic taglines, lower is for exact ledger quotes (${String.format("%.2f", viewModel.aiTemperature)})",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                Slider(
                    value = viewModel.aiTemperature,
                    onValueChange = {
                        viewModel.aiTemperature = it
                    },
                    onValueChangeFinished = {
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Configured Generative AI temperature limit to ${viewModel.aiTemperature}")
                    },
                    valueRange = 0.1f..1.0f,
                    modifier = Modifier.width(130.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = GoldPrimary,
                        activeTrackColor = GoldPrimary,
                        inactiveTrackColor = CharcoalDark
                    )
                )
            }

            HorizontalDivider(color = GlassBorder)

            // Enable auto-tagging
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "الوسم التلقائي المساعد" else "Automated Content Tagging & Prompts",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "تحليل ووصف التصاميم الحية لإنشاء وسوم تصنيع مناسبة تلقائياً للخلفية" else "Analyze custom graphic layers dynamically to assign manufacturing categories",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = viewModel.enableAutoTagging,
                    onCheckedChange = {
                        viewModel.enableAutoTagging = it
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Toggled AI manufacturing auto-tagging capability to $it")
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldPrimary,
                        checkedTrackColor = GoldPrimary.copy(alpha = 0.4f),
                        uncheckedThumbColor = PlatinumGray,
                        uncheckedTrackColor = CharcoalDark
                    )
                )
            }
        }
    }
}

// -------------------------------------------------------------
// 4. PERFORMANCE & SYSTEM MONITOR SETTINGS BLOCK
// -------------------------------------------------------------
@Composable
fun PerformanceMonitorSettingsBlock(
    viewModel: YaftaViewModel,
    lang: String,
    logSearchQuery: String,
    onSearchChange: (String) -> Unit
) {
    val context = LocalContext.current
    var hardwareAcc by remember { mutableStateOf(viewModel.enableHardwareAcceleration) }
    var lowMemMode by remember { mutableStateOf(viewModel.lowMemoryMode) }
    var cacheSize by remember { mutableStateOf(viewModel.maxCacheSizeMb) }

    // Real-time animated simulation for System Status meters
    val infiniteTransition = rememberInfiniteTransition(label = "RadarSimulation")
    val simulatedCpu by infiniteTransition.animateFloat(
        initialValue = 0.015f,
        targetValue = 0.045f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "CpuPulse"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "تهيئة الأداء وترشيد استهلاك موارد الجهاز" else "Workstation Resource Calibration",
                icon = Icons.Default.Speed
            )

            // GPU Acceleration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "تسريع الرسوميات بواسطة معالج وحدة الرسوميات (GPU)" else "Hardware Graphic Acceleration (GPU)",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "استخدام تسريع العتاد لمعالجة الفرش ورندر الطبقات الإعلانية الضخمة بسلاسة" else "Render ultra-high resolution signage layout vector layers at high FPS",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = hardwareAcc,
                    onCheckedChange = {
                        hardwareAcc = it
                        viewModel.enableHardwareAcceleration = it
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Toggled GPU workstation hardware rendering to $it")
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldPrimary,
                        checkedTrackColor = GoldPrimary.copy(alpha = 0.4f),
                        uncheckedThumbColor = PlatinumGray,
                        uncheckedTrackColor = CharcoalDark
                    )
                )
            }

            HorizontalDivider(color = GlassBorder)

            // Low memory mode
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "نمط كفاءة الذاكرة للأجهزة الضعيفة" else "Low-Memory Resource Mode",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "تعطيل تخزين المعاينات السابقة مؤقتاً بالرامات لتجنب إغلاق التطبيق فجأة" else "Deallocate historical background undo buffers to save application RAM limits",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = lowMemMode,
                    onCheckedChange = {
                        lowMemMode = it
                        viewModel.lowMemoryMode = it
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Toggled system low RAM memory optimization mode to $it")
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldPrimary,
                        checkedTrackColor = GoldPrimary.copy(alpha = 0.4f),
                        uncheckedThumbColor = PlatinumGray,
                        uncheckedTrackColor = CharcoalDark
                    )
                )
            }

            HorizontalDivider(color = GlassBorder)

            // Cache size MB limit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "سقف تخزين الذاكرة المؤقتة (الكاش)" else "Workstation Cache Ceiling",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "الحد الأقصى المسموح لخام الكاش لتخزين صور خامات الكلادينج والليد ($cacheSize ميجابايت)" else "Memory boundary allowed for caching raw supplier catalogs and files ($cacheSize MB)",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                Slider(
                    value = cacheSize.toFloat(),
                    onValueChange = {
                        cacheSize = it.toInt()
                    },
                    onValueChangeFinished = {
                        viewModel.maxCacheSizeMb = cacheSize
                        viewModel.saveSettingsToPrefs()
                        viewModel.logOperation("Adjusted system disk cache maximum cap boundary to $cacheSize MB")
                    },
                    valueRange = 50f..1024f,
                    modifier = Modifier.width(130.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = GoldPrimary,
                        activeTrackColor = GoldPrimary,
                        inactiveTrackColor = CharcoalDark
                    )
                )
            }

            HorizontalDivider(color = GlassBorder)

            // Cache clear button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (lang == "ar") "تنظيف كاش الذاكرة والملفات الزائدة" else "Purge Workstation Temp Files & Cache",
                        color = PlatinumWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == "ar") "احذف ملفات الرندر المؤقتة ومسودات الطبقات لتنظيف مساحة الرامات فورا" else "Clear cached textures and temporary vectors to release device disk memory immediately",
                        color = PlatinumGray,
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = {
                        viewModel.errorLogs.add("[CLEANUP] Purged temporary sandbox system cache footprint successfully")
                        viewModel.logOperation("Cleaned up workstation application cache folder")
                        Toast.makeText(context, if (lang == "ar") "تم تنظيف ذاكرة الكاش بنجاح!" else "System cache flushed and cleared!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                    border = BorderStroke(1.dp, GoldPrimary),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text(if (lang == "ar") "تحرير وتنظيف الذاكرة" else "Clean Cache", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // System status monitor panel
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "مراقبة حالة موارد النظام والمخزن والبيانات" else "Live System Health & Storage Monitors",
                icon = Icons.Default.DeveloperMode
            )

            // Simulation metrics grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Monitor 1: CPU load simulator
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(CharcoalDark, RoundedCornerShape(8.dp))
                        .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(if (lang == "ar") "معالج التطبيق (CPU)" else "App CPU Load", color = PlatinumGray, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${String.format("%.1f", simulatedCpu * 100f)}%",
                        color = GoldPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = simulatedCpu,
                        color = GoldPrimary,
                        trackColor = CharcoalLight,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(CircleShape)
                    )
                }

                // Monitor 2: Database Storage status
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(CharcoalDark, RoundedCornerShape(8.dp))
                        .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(if (lang == "ar") "قاعدة البيانات المحلية (Sqlite)" else "Local SQLite Database", color = PlatinumGray, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "1.85 MB",
                        color = GoldPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "26 Tables, Normal Status",
                        color = PlatinumWhite,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center
                    )
                }

                // Monitor 3: Device general network/threads status
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(CharcoalDark, RoundedCornerShape(8.dp))
                        .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(if (lang == "ar") "حالة الاتصال والخدمات" else "Connectivity Status", color = PlatinumGray, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "ONLINE",
                        color = Color(0xFF4CAF50),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Gemini API Responding",
                        color = PlatinumWhite,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    // Live Logs List View Frame
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SettingsSectionHeader(
                    title = if (lang == "ar") "سجل الأخطاء والعمليات المستمر للنظام Logs" else "Diagnostic System Operations & Logs",
                    icon = Icons.Default.ListAlt
                )

                // Search query log field
                OutlinedTextField(
                    value = logSearchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text(if (lang == "ar") "ابحث عن ملف..." else "Search logs...", fontSize = 11.sp, color = PlatinumGray) },
                    modifier = Modifier
                        .width(180.dp)
                        .height(38.dp)
                        .testTag("search_logs_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedContainerColor = CharcoalDark,
                        unfocusedContainerColor = CharcoalDark
                    ),
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, color = PlatinumWhite),
                    singleLine = true
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(CharcoalDark, RoundedCornerShape(8.dp))
                    .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                val filteredLogs = viewModel.errorLogs.filter {
                    logSearchQuery.isBlank() || it.contains(logSearchQuery, ignoreCase = true)
                }

                if (filteredLogs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = if (lang == "ar") "لا توجد سجلات مطابقة للبحث" else "No matching operations logged",
                            color = PlatinumGray,
                            fontSize = 11.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filteredLogs.reversed()) { logLine ->
                            val textColor = when {
                                logLine.contains("[ERROR]") -> Color(0xFFEF5350)
                                logLine.contains("[SUCCESS]") -> Color(0xFF4CAF50)
                                logLine.contains("[OP]") -> GoldPrimary
                                else -> PlatinumWhite
                            }
                            Text(
                                text = logLine,
                                color = textColor,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 5. BACKUP & RESTORE SETTINGS BLOCK
// -------------------------------------------------------------
@Composable
fun BackupRestoreSettingsBlock(
    viewModel: YaftaViewModel,
    lang: String,
    onExportBackup: () -> Unit,
    onImportRestore: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SettingsSectionHeader(
                title = if (lang == "ar") "النسخ الاحتياطي المحموم واستيراد التعيينات" else "Data Preservation, Backup & Workspace Recovery",
                icon = Icons.Default.Backup
            )

            Text(
                text = if (lang == "ar")
                    "يوفر نظام يافطة ERP آلية متقدمة لتصدير كامل ملف إعداداتك ومقاساتك الافتراضية وحالتك التشغيلية لملف مشفر واحد صلب، يمكنك الاحتفاظ به أو استخدامه للمزامنة الفورية عبر الأجهزة الكفية."
                else
                    "YAFTA ERP features structured state-level exports to dump system parameters, metric parameters, and operational roles into high contrast backups.",
                color = PlatinumGray,
                fontSize = 11.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Export Button
                Button(
                    onClick = onExportBackup,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("export_backup_btn")
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, tint = CharcoalDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == "ar") "تصدير ونسخ التكوينات" else "Export & Copy JSON",
                        color = CharcoalDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // Import Button
                Button(
                    onClick = onImportRestore,
                    colors = ButtonDefaults.buttonColors(containerColor = CharcoalLight),
                    border = BorderStroke(1.dp, GoldPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("import_restore_btn")
                ) {
                    Icon(imageVector = Icons.Default.Publish, contentDescription = null, tint = GoldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (lang == "ar") "استيراد واستعادة التكوين" else "Import & Restore Archive",
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            HorizontalDivider(color = GlassBorder)

            // Export Settings (PDF Format Quality, Folder)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (lang == "ar") "إعدادات تصدير التقارير وعقود التنفيذ الافتراضية" else "Signage Documentation & PDF Export Defaults",
                    color = PlatinumWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                // Select default export file format
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == "ar") "صيغة المستندات المصدرة القياسية" else "Default Export Document Format",
                        color = PlatinumWhite,
                        fontSize = 12.sp
                    )

                    var formatExpanded by remember { mutableStateOf(false) }
                    Box {
                        Button(
                            onClick = { formatExpanded = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                            border = BorderStroke(1.dp, GlassBorder),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(viewModel.defaultExportFormat, color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(14.dp))
                        }
                        DropdownMenu(
                            expanded = formatExpanded,
                            onDismissRequest = { formatExpanded = false },
                            modifier = Modifier.background(CharcoalMedium)
                        ) {
                            listOf("PDF", "PNG", "JPEG", "SVG").forEach { fmt ->
                                DropdownMenuItem(
                                    text = { Text(fmt, color = PlatinumWhite, fontSize = 12.sp) },
                                    onClick = {
                                        viewModel.defaultExportFormat = fmt
                                        viewModel.saveSettingsToPrefs()
                                        viewModel.logOperation("Configured default document export format extension to $fmt")
                                        formatExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Select default export resolution quality
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (lang == "ar") "جودة التصدير والطباعة القياسية" else "Standard Render Target Precision",
                        color = PlatinumWhite,
                        fontSize = 12.sp
                    )

                    var qualityExpanded by remember { mutableStateOf(false) }
                    Box {
                        Button(
                            onClick = { qualityExpanded = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalDark),
                            border = BorderStroke(1.dp, GlassBorder),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(viewModel.defaultExportQuality, color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(14.dp))
                        }
                        DropdownMenu(
                            expanded = qualityExpanded,
                            onDismissRequest = { qualityExpanded = false },
                            modifier = Modifier.background(CharcoalMedium)
                        ) {
                            listOf("High (300 DPI)", "Medium (150 DPI)", "Low (72 DPI)").forEach { qlt ->
                                DropdownMenuItem(
                                    text = { Text(qlt, color = PlatinumWhite, fontSize = 12.sp) },
                                    onClick = {
                                        viewModel.defaultExportQuality = qlt
                                        viewModel.saveSettingsToPrefs()
                                        viewModel.logOperation("Configured default print DPI render target precision to $qlt")
                                        qualityExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Save folder input field
                Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (lang == "ar") "مجلد الحفظ المحلي الافتراضي" else "Workstation Target Storage Folder",
                        color = PlatinumWhite,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = viewModel.exportFolder,
                        onValueChange = {
                            viewModel.exportFolder = it
                            viewModel.saveSettingsToPrefs()
                        },
                        placeholder = { Text("/sdcard/Download/Yafta", color = PlatinumGray) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("export_folder_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GlassBorder,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = PlatinumWhite),
                        singleLine = true
                    )
                }
            }
        }
    }
}
