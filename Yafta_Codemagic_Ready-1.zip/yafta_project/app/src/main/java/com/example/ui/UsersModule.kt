package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CustomRole
import com.example.data.User
import com.example.ui.theme.*
import com.example.viewmodel.YaftaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    viewModel: YaftaViewModel,
    onLoginSuccess: () -> Unit
) {
    val lang = viewModel.language
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(CharcoalDark, CharcoalMedium)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 440.dp)
                .testTag("login_card"),
            colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
            border = BorderStroke(1.dp, GlassBorder),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Enterprise Header Brand Shield
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(GoldPrimary.copy(alpha = 0.1f))
                        .border(1.dp, GoldPrimary, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (lang == "ar") "يافطة للدعاية والإعلان" else "Yafita for Advertising",
                    color = PlatinumWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = if (lang == "ar") "بوابة تسجيل الدخول الآمن" else "Secure Gateway Authentication",
                    color = GoldPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Username or Email Address field
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; errorMessage = "" },
                    label = { Text(if (lang == "ar") "اسم المستخدم أو البريد" else "Username or Email") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = PlatinumWhite,
                        focusedContainerColor = CharcoalLight,
                        unfocusedContainerColor = CharcoalLight
                    ),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = GoldPrimary) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_email_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Password field
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; errorMessage = "" },
                    label = { Text(if (lang == "ar") "كلمة المرور" else "Password") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = PlatinumWhite,
                        focusedContainerColor = CharcoalLight,
                        unfocusedContainerColor = CharcoalLight
                    ),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Password, contentDescription = null, tint = GoldPrimary) },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                tint = PlatinumGray
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_password_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = Color(0xFFEF5350),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (email.isBlank() || password.isBlank()) {
                            errorMessage = if (lang == "ar") "برجاء ملء جميع الحقول!" else "Please fill all fields!"
                            return@Button
                        }
                        isLoading = true
                        viewModel.loginUser(email, password) { success, msg ->
                            isLoading = false
                            if (success) {
                                onLoginSuccess()
                            } else {
                                errorMessage = msg
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("login_submit_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoading
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = CharcoalDark, modifier = Modifier.size(24.dp))
                    } else {
                        Text(
                            text = if (lang == "ar") "مصادقة وولوج" else "Authenticate & Enter",
                            color = CharcoalDark,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (lang == "ar") "بيانات المدير العام الافتراضية:\nاسم المستخدم: Admen | كلمة المرور: 116210464"
                           else "Default General Manager Credentials:\nUsername: Admen | Password: 116210464",
                    color = PlatinumGray,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersModule(
    viewModel: YaftaViewModel,
    usersList: List<User>,
    rolesList: List<CustomRole>
) {
    val lang = viewModel.language
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = if (lang == "ar") {
        listOf("المستخدمين", "أدوار الصلاحيات", "إعدادات المسؤول")
    } else {
        listOf("Users List", "Permissions Roles", "Root Admin Calibration")
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            Column(modifier = Modifier.background(CharcoalMedium)) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = CharcoalMedium,
                    contentColor = GoldPrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = GoldPrimary
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedTab == index) GoldPrimary else PlatinumGray
                                )
                            },
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> UsersListTab(viewModel, usersList, rolesList)
                1 -> RolesPermissionsTab(viewModel, rolesList)
                2 -> RootAdminCalibrationTab(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersListTab(
    viewModel: YaftaViewModel,
    users: List<User>,
    roles: List<CustomRole>
) {
    val lang = viewModel.language

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedUserForEdit by remember { mutableStateOf<User?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (lang == "ar") "إدارة مستخدمي النظام (${users.size})" else "System Users Administration (${users.size})",
                color = PlatinumWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            // Button to Add User
            if (viewModel.hasAccess("users", "add")) {
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = CharcoalDark)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (lang == "ar") "مستخدم جديد" else "New User",
                        color = CharcoalDark,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (users.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (lang == "ar") "لا يوجد مستخدمين متاحين حالياً" else "No users registered currently",
                    color = PlatinumGray,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(users) { user ->
                    val matchedRole = roles.firstOrNull { it.roleName.equals(user.role, ignoreCase = true) }
                    val roleDisplayName = if (matchedRole != null) {
                        if (lang == "ar") matchedRole.displayNameAr else matchedRole.displayNameEn
                    } else {
                        user.role
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, if (user.isActive) GlassBorder else Color(0x33EF5350))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = user.name,
                                        color = PlatinumWhite,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    // Status Badge
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                if (user.isActive) Color(0xFF4CAF50).copy(alpha = 0.15f)
                                                else Color(0xFFEF5350).copy(alpha = 0.15f)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (lang == "ar") {
                                                if (user.isActive) "نشط" else "معطل"
                                            } else {
                                                if (user.isActive) "Active" else "Deactivated"
                                            },
                                            color = if (user.isActive) Color(0xFF81C784) else Color(0xFFE57373),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = user.email,
                                    color = PlatinumGray,
                                    fontSize = 12.sp
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Shield,
                                        contentDescription = null,
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = roleDisplayName,
                                        color = GoldPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (user.password.isNotEmpty()) {
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Icon(
                                            imageVector = Icons.Default.Key,
                                            contentDescription = null,
                                            tint = PlatinumGray,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "•••••• (${user.password})",
                                            color = PlatinumGray,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            // Actions
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                // Toggle active state check access
                                if (viewModel.hasAccess("users", "edit") && !user.role.equals("Admin", ignoreCase = true)) {
                                    IconButton(
                                        onClick = {
                                            viewModel.addOrUpdateUser(user.copy(isActive = !user.isActive))
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (user.isActive) Icons.Default.PersonOff else Icons.Default.Person2,
                                            contentDescription = "Toggle Active Status",
                                            tint = if (user.isActive) Color(0xFFEF5350) else Color(0xFF4CAF50),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                // Edit button check access
                                if (viewModel.hasAccess("users", "edit")) {
                                    IconButton(onClick = { selectedUserForEdit = user }) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Edit User",
                                            tint = GoldPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                // Delete button check access
                                if (viewModel.hasAccess("users", "delete") && !user.role.equals("Admin", ignoreCase = true)) {
                                    IconButton(
                                        onClick = {
                                            viewModel.deleteUser(user.id, user.name)
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete User",
                                            tint = Color(0xFFEF5350),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add User Dialog
    if (showAddDialog) {
        AddOrEditUserDialog(
            userToEdit = null,
            rolesList = roles,
            language = lang,
            onDismiss = { showAddDialog = false },
            onConfirm = { newUser ->
                viewModel.addOrUpdateUser(newUser)
                showAddDialog = false
            }
        )
    }

    // Edit User Dialog
    if (selectedUserForEdit != null) {
        AddOrEditUserDialog(
            userToEdit = selectedUserForEdit,
            rolesList = roles,
            language = lang,
            onDismiss = { selectedUserForEdit = null },
            onConfirm = { updatedUser ->
                viewModel.addOrUpdateUser(updatedUser)
                selectedUserForEdit = null
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrEditUserDialog(
    userToEdit: User?,
    rolesList: List<CustomRole>,
    language: String,
    onDismiss: () -> Unit,
    onConfirm: (User) -> Unit
) {
    var name by remember { mutableStateOf(userToEdit?.name ?: "") }
    var email by remember { mutableStateOf(userToEdit?.email ?: "") }
    var selectedRole by remember { mutableStateOf(userToEdit?.role ?: "Employee") }
    var password by remember { mutableStateOf(userToEdit?.password ?: "123456") }
    var isActive by remember { mutableStateOf(userToEdit?.isActive ?: true) }
    var dropDownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (userToEdit == null) {
                    if (language == "ar") "إضافة حساب مستخدم جديد" else "Register New User Account"
                } else {
                    if (language == "ar") "تعديل حساب المستخدم" else "Modify User Account Settings"
                },
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary
            )
        },
        containerColor = CharcoalMedium,
        textContentColor = PlatinumWhite,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (language == "ar") "الاسم الكامل" else "Full Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = PlatinumWhite,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray,
                        focusedContainerColor = CharcoalLight,
                        unfocusedContainerColor = CharcoalLight
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Email
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text(if (language == "ar") "البريد الإلكتروني" else "Email Address") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = PlatinumWhite,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray,
                        focusedContainerColor = CharcoalLight,
                        unfocusedContainerColor = CharcoalLight
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Password
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(if (language == "ar") "كلمة المرور" else "Password") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = PlatinumWhite,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray,
                        focusedContainerColor = CharcoalLight,
                        unfocusedContainerColor = CharcoalLight
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Role Dropdown Selection
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (language == "ar") "رتبة الصلاحيات (الدور)" else "Permissions Role",
                        fontSize = 11.sp,
                        color = PlatinumGray,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                            .clickable { dropDownExpanded = true }
                            .padding(horizontal = 14.dp, vertical = 14.dp)
                    ) {
                        val activeRoleObj = rolesList.firstOrNull { it.roleName.equals(selectedRole, ignoreCase = true) }
                        val activeDisplayName = if (activeRoleObj != null) {
                            if (language == "ar") activeRoleObj.displayNameAr else activeRoleObj.displayNameEn
                        } else {
                            selectedRole
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = activeDisplayName, color = GoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = PlatinumGray)
                        }

                        DropdownMenu(
                            expanded = dropDownExpanded,
                            onDismissRequest = { dropDownExpanded = false },
                            modifier = Modifier.background(CharcoalLight)
                        ) {
                            rolesList.forEach { role ->
                                val rName = if (language == "ar") role.displayNameAr else role.displayNameEn
                                DropdownMenuItem(
                                    text = { Text(rName, color = PlatinumWhite, fontSize = 13.sp) },
                                    onClick = {
                                        selectedRole = role.roleName
                                        dropDownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Active Switch (Do not let disable Root Admin)
                if (userToEdit == null || !userToEdit.role.equals("Admin", ignoreCase = true)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (language == "ar") "حالة تفعيل الحساب" else "Account Activation Status",
                            color = PlatinumWhite,
                            fontSize = 13.sp
                        )

                        Switch(
                            checked = isActive,
                            onCheckedChange = { isActive = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = GoldPrimary,
                                checkedTrackColor = GoldPrimary.copy(alpha = 0.4f),
                                uncheckedThumbColor = CharcoalLight,
                                uncheckedTrackColor = GlassBorder
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank() || email.isBlank()) return@Button
                    val finalUser = User(
                        id = userToEdit?.id ?: 0,
                        name = name,
                        email = email,
                        role = selectedRole,
                        password = password,
                        isActive = isActive,
                        permissions = userToEdit?.permissions ?: ""
                    )
                    onConfirm(finalUser)
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
            ) {
                Text(
                    text = if (language == "ar") "تأكيد وحفظ" else "Save & Confirm",
                    color = CharcoalDark,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = if (language == "ar") "إلغاء الأمر" else "Cancel",
                    color = PlatinumGray
                )
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RolesPermissionsTab(
    viewModel: YaftaViewModel,
    roles: List<CustomRole>
) {
    val lang = viewModel.language

    var showAddNewRoleDialog by remember { mutableStateOf(false) }
    var selectedRoleForEditing by remember { mutableStateOf<CustomRole?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (lang == "ar") "نظام الأدوار العضوية والصلاحيات التفاعلية" else "Role Matrix & Permission Management",
                color = PlatinumWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            // Button to Add Custom Role
            if (viewModel.hasAccess("users", "add")) {
                Button(
                    onClick = { showAddNewRoleDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = CharcoalDark)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (lang == "ar") "دور جديد" else "New Role",
                        color = CharcoalDark,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(roles) { role ->
                val permList = role.permissions.split(",").filter { it.isNotEmpty() }
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CharcoalMedium),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GlassBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (lang == "ar") role.displayNameAr else role.displayNameEn,
                                    color = PlatinumWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Role Key: ${role.roleName}",
                                    color = PlatinumGray,
                                    fontSize = 11.sp
                                )
                            }

                            Row {
                                // Toggle Details/Configure button
                                if (viewModel.hasAccess("users", "edit")) {
                                    IconButton(onClick = { selectedRoleForEditing = role }) {
                                        Icon(
                                            imageVector = Icons.Default.Settings,
                                            contentDescription = "Configure Permissions",
                                            tint = GoldPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                // Delete Role (Cannot delete Master Admin)
                                if (viewModel.hasAccess("users", "delete") && !role.roleName.equals("Admin", ignoreCase = true)) {
                                    IconButton(onClick = { viewModel.deleteRole(role.roleName) }) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete Role",
                                            tint = Color(0xFFEF5350),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (lang == "ar") "إجمالي القواعد والميزات المسموحة: ${permList.size}" else "Total active feature controls: ${permList.size}",
                            color = GoldPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Render a flow / sequence of small chips showing summaries of access
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val modulesWithAccess = permList.map { it.substringBefore(":") }.distinct()
                            modulesWithAccess.forEach { mod ->
                                Box(
                                    modifier = Modifier
                                        .padding(bottom = 6.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CharcoalLight)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = mod,
                                        color = PlatinumWhite,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog for configuring customized role-matrix permissions
    if (selectedRoleForEditing != null) {
        RolePermissionsEditorDialog(
            role = selectedRoleForEditing!!,
            language = lang,
            onDismiss = { selectedRoleForEditing = null },
            onConfirm = { updatedRole ->
                viewModel.addOrUpdateRole(updatedRole)
                selectedRoleForEditing = null
            }
        )
    }

    // Dialog for adding a new empty Role
    if (showAddNewRoleDialog) {
        AddNewRoleDialog(
            language = lang,
            onDismiss = { showAddNewRoleDialog = false },
            onConfirm = { newRole ->
                viewModel.addOrUpdateRole(newRole)
                showAddNewRoleDialog = false
            }
        )
    }
}

@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    content: @Composable () -> Unit
) {
    Row(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = horizontalArrangement,
        content = { content() }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddNewRoleDialog(
    language: String,
    onDismiss: () -> Unit,
    onConfirm: (CustomRole) -> Unit
) {
    var rawName by remember { mutableStateOf("") }
    var displayNameAr by remember { mutableStateOf("") }
    var displayNameEn by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (language == "ar") "إنشاء رتبة صلاحيات جديدة" else "Create New Custom System Role",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = GoldPrimary
            )
        },
        containerColor = CharcoalMedium,
        textContentColor = PlatinumWhite,
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Key identifier
                OutlinedTextField(
                    value = rawName,
                    onValueChange = { rawName = it.replace(" ", "") },
                    label = { Text(if (language == "ar") "مفتاح الربط البرمجي (مثال: SalesManager)" else "Unique ID Key (e.g. SalesManager)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = PlatinumWhite,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray,
                        focusedContainerColor = CharcoalLight,
                        unfocusedContainerColor = CharcoalLight
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Arabic title
                OutlinedTextField(
                    value = displayNameAr,
                    onValueChange = { displayNameAr = it },
                    label = { Text(if (language == "ar") "الاسم المعروض بالعربية (مثال: مدير المبيعات)" else "Display Title (Arabic)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = PlatinumWhite,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray,
                        focusedContainerColor = CharcoalLight,
                        unfocusedContainerColor = CharcoalLight
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // English title
                OutlinedTextField(
                    value = displayNameEn,
                    onValueChange = { displayNameEn = it },
                    label = { Text(if (language == "ar") "الاسم المعروض بالإنجليزية" else "Display Title (English)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GlassBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = PlatinumWhite,
                        focusedLabelColor = GoldPrimary,
                        unfocusedLabelColor = PlatinumGray,
                        focusedContainerColor = CharcoalLight,
                        unfocusedContainerColor = CharcoalLight
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (rawName.isBlank() || displayNameAr.isBlank()) return@Button
                    val coreNewRole = CustomRole(
                        roleName = rawName,
                        displayNameAr = displayNameAr,
                        displayNameEn = displayNameEn.ifBlank { rawName },
                        permissions = "dashboard:view" // Automatically grant dashboard view
                    )
                    onConfirm(coreNewRole)
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
            ) {
                Text(
                    text = if (language == "ar") "تفعيل وحفظ" else "Save & Create",
                    color = CharcoalDark,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = if (language == "ar") "إلغاء الأمر" else "Cancel",
                    color = PlatinumGray
                )
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RolePermissionsEditorDialog(
    role: CustomRole,
    language: String,
    onDismiss: () -> Unit,
    onConfirm: (CustomRole) -> Unit
) {
    // Current permissions in a mutable set
    val activePerms = remember { role.permissions.split(",").filter { it.isNotEmpty() }.toMutableStateList() }

    // List of Modules inside the signboards enterprise platform
    val platformModules = listOf(
        Pair("dashboard", if (language == "ar") "لوحة العدادات الرئيسية" else "Dashboard Status Hub"),
        Pair("customers", if (language == "ar") "إدارة ملفات العملاء" else "Customers Ledger"),
        Pair("quotations", if (language == "ar") "المقايسات والتقدير الذكي" else "Quotations & Smart Measurements"),
        Pair("projects", if (language == "ar") "المشروعات ومتابعة الإنشاء" else "Projects Overseer"),
        Pair("studio", if (language == "ar") "استوديو التصميم الهندسي" else "Layout Design Studio"),
        Pair("design_dept", if (language == "ar") "التصاميم والمراجعات الإبداعية" else "Design Review Board"),
        Pair("production", if (language == "ar") "لوحة الورشة والتشغيل" else "Production Workshop"),
        Pair("installation", if (language == "ar") "موقع التركيب والخرائط" else "Field Sites & Maps"),
        Pair("inventory", if (language == "ar") "مسؤول المخزون والأرصدة" else "Secure Inventory Ledger"),
        Pair("suppliers", if (language == "ar") "سجل الموردين والمشتريات" else "Suppliers Directory"),
        Pair("finance", if (language == "ar") "المالية والحسابات العاجلة" else "Accounting & VAT Ledger"),
        Pair("staff", if (language == "ar") "الحضور والرواتب والكادر" else "Staff Directory"),
        Pair("settings", if (language == "ar") "إعدادات تفضيلات النظام" else "System Configurations"),
        Pair("users", if (language == "ar") "إدارة المستخدمين والصلاحيات" else "ACL Users Portal")
    )

    // Allowed action states inside the modules
    val actionStates = listOf(
        Pair("view", if (language == "ar") "عرض" else "View"),
        Pair("add", if (language == "ar") "إضافة" else "Add"),
        Pair("edit", if (language == "ar") "تعديل" else "Edit"),
        Pair("delete", if (language == "ar") "حذف" else "Delete"),
        Pair("export", if (language == "ar") "تصدير" else "Excel/Export"),
        Pair("print", if (language == "ar") "طباعة" else "PDF/Print"),
        Pair("settings", if (language == "ar") "إعدادات" else "Setup")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = if (language == "ar") "رسم مصفوفة صلاحيات لدور" else "Configure System Matrix Access",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldPrimary
                )
                Text(
                    text = if (language == "ar") "الدور المحدد: ${role.displayNameAr}" else "Active Role: ${role.displayNameEn}",
                    fontSize = 12.sp,
                    color = PlatinumGray,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        },
        containerColor = CharcoalMedium,
        textContentColor = PlatinumWhite,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                platformModules.forEach { (moduleKey, moduleLabel) ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .background(CharcoalLight, RoundedCornerShape(12.dp))
                            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = moduleLabel,
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        // Draw Grid checkboxes for each action
                        actionStates.forEach { (actionKey, actionLabel) ->
                            val permissionValue = "$moduleKey:$actionKey"
                            val isChecked = activePerms.contains(permissionValue)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isChecked) {
                                            activePerms.remove(permissionValue)
                                        } else {
                                            activePerms.add(permissionValue)
                                        }
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        if (checked == true) {
                                            if (!activePerms.contains(permissionValue)) activePerms.add(permissionValue)
                                        } else {
                                            activePerms.remove(permissionValue)
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = GoldPrimary,
                                        uncheckedColor = PlatinumGray,
                                        checkmarkColor = CharcoalDark
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = actionLabel, color = PlatinumWhite, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalRoleString = activePerms.joinToString(",")
                    onConfirm(role.copy(permissions = finalRoleString))
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
            ) {
                Text(
                    text = if (language == "ar") "حفظ وضبط" else "Synchronize Matrix",
                    color = CharcoalDark,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = if (language == "ar") "رجوع" else "Discard",
                    color = PlatinumGray
                )
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RootAdminCalibrationTab(
    viewModel: YaftaViewModel
) {
    val lang = viewModel.language
    var adminEmail by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var messageColor by remember { mutableStateOf(GoldPrimary) }

    // Populate currently logged in admin details if available
    LaunchedEffect(Unit) {
        val allUsers = viewModel.users.value
        val rootAdmin = allUsers.firstOrNull { it.role == "Admin" }
        if (rootAdmin != null) {
            adminEmail = rootAdmin.email
            adminPassword = rootAdmin.password
            confirmPassword = rootAdmin.password
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = if (lang == "ar") "تعديل بيانات الدخول للمشرف الرئيسي (Admin Email & Pass)"
                   else "Master Administrator Gateway Settings",
            color = PlatinumWhite,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = if (lang == "ar") "تتيح لك الواجهة التالية تغيير البريد الإلكتروني الافتراضي وكلمة المرور الرئيسية لإدارة النظام بالكامل."
                   else "Use this utility screen to calibrate primary gateway credentials. These values are persisted securely inside Room DB.",
            color = PlatinumGray,
            fontSize = 11.sp,
            lineHeight = 16.sp
        )

        HorizontalDivider(color = GlassBorder)

        // Email field
        OutlinedTextField(
            value = adminEmail,
            onValueChange = { adminEmail = it },
            label = { Text(if (lang == "ar") "البريد الإلكتروني الأساسي للمدير العام" else "Root Manager Email") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GlassBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = PlatinumWhite,
                focusedLabelColor = GoldPrimary,
                unfocusedLabelColor = PlatinumGray,
                focusedContainerColor = CharcoalLight,
                unfocusedContainerColor = CharcoalLight
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        // Password field
        OutlinedTextField(
            value = adminPassword,
            onValueChange = { adminPassword = it },
            label = { Text(if (lang == "ar") "رقم المرور الحاسم الجديد" else "Root Manager Password") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GlassBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = PlatinumWhite,
                focusedLabelColor = GoldPrimary,
                unfocusedLabelColor = PlatinumGray,
                focusedContainerColor = CharcoalLight,
                unfocusedContainerColor = CharcoalLight
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        // Confirm Password field
        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text(if (lang == "ar") "تأكيد رقم المرور الجديد" else "Confirm Root Manager Password") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = GlassBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = PlatinumWhite,
                focusedLabelColor = GoldPrimary,
                unfocusedLabelColor = PlatinumGray,
                focusedContainerColor = CharcoalLight,
                unfocusedContainerColor = CharcoalLight
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (message.isNotEmpty()) {
            Text(
                text = message,
                color = messageColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                if (adminEmail.isBlank() || adminPassword.isBlank()) {
                    message = if (lang == "ar") "من فضلك املأ جميع التفاصيل الحيوية" else "Must provide valid email/password details"
                    messageColor = Color(0xFFEF5350)
                    return@Button
                }
                if (adminPassword != confirmPassword) {
                    message = if (lang == "ar") "كلمتا المرور غير متطابقتين!" else "Passwords do not match!"
                    messageColor = Color(0xFFEF5350)
                    return@Button
                }

                viewModel.updatePrimaryAdminConfigs(adminEmail, adminPassword) { success ->
                    if (success) {
                        message = if (lang == "ar") "تم تحديث كلمة مرور المشرف بنجاح" else "System Admin login calibrated successfully!"
                        messageColor = Color(0xFF4CAF50)
                    } else {
                        message = if (lang == "ar") "عذراً، فشل تكرار العملية" else "Operation calibration failure"
                        messageColor = Color(0xFFEF5350)
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(
                text = if (lang == "ar") "معايرة وتحديث وحفظ هويتي" else "Sync Login Identity Credentials",
                color = CharcoalDark,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
    }
}
