package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface YaftaErpDao {

    // --- Users ---
    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUserById(id: Int)

    // --- Custom Roles ---
    @Query("SELECT * FROM custom_roles")
    fun getAllCustomRoles(): Flow<List<CustomRole>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomRole(role: CustomRole)

    @Query("DELETE FROM custom_roles WHERE roleName = :roleName")
    suspend fun deleteCustomRole(roleName: String)

    @Query("SELECT * FROM custom_roles WHERE roleName = :roleName")
    suspend fun getCustomRoleByName(roleName: String): CustomRole?

    // --- Customers ---
    @Query("SELECT * FROM customers ORDER BY id DESC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: Int): Customer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer): Long

    @Update
    suspend fun updateCustomer(customer: Customer)

    @Query("DELETE FROM customers WHERE id = :id")
    suspend fun deleteCustomerById(id: Int)

    // --- Quotations ---
    @Query("SELECT * FROM quotations ORDER BY id DESC")
    fun getAllQuotations(): Flow<List<Quotation>>

    @Query("SELECT * FROM quotations WHERE id = :id")
    suspend fun getQuotationById(id: Int): Quotation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuotation(quotation: Quotation): Long

    @Update
    suspend fun updateQuotation(quotation: Quotation)

    @Query("DELETE FROM quotations WHERE id = :id")
    suspend fun deleteQuotationById(id: Int)

    // --- Quotation Items ---
    @Query("SELECT * FROM quotation_items WHERE quotationId = :quotationId")
    fun getItemsForQuotation(quotationId: Int): Flow<List<QuotationItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuotationItem(item: QuotationItem)

    @Query("DELETE FROM quotation_items WHERE quotationId = :quotationId")
    suspend fun deleteItemsForQuotation(quotationId: Int)

    // --- Projects ---
    @Query("SELECT * FROM projects ORDER BY id DESC")
    fun getAllProjects(): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectById(id: Int): Project?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project): Long

    @Update
    suspend fun updateProject(project: Project)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: Int)

    // --- Design Files ---
    @Query("SELECT * FROM design_files WHERE projectId = :projectId ORDER BY id DESC")
    fun getDesignFilesForProject(projectId: Int): Flow<List<DesignFile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDesignFile(file: DesignFile)

    @Update
    suspend fun updateDesignFile(file: DesignFile)

    // --- Production Jobs ---
    @Query("SELECT * FROM production_jobs ORDER BY id DESC")
    fun getAllProductionJobs(): Flow<List<ProductionJob>>

    @Query("SELECT * FROM production_jobs WHERE projectId = :projectId")
    suspend fun getProductionJobByProject(projectId: Int): ProductionJob?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProductionJob(job: ProductionJob)

    @Update
    suspend fun updateProductionJob(job: ProductionJob)

    // --- Installation Jobs ---
    @Query("SELECT * FROM installation_jobs ORDER BY id DESC")
    fun getAllInstallationJobs(): Flow<List<InstallationJob>>

    @Query("SELECT * FROM installation_jobs WHERE projectId = :projectId")
    suspend fun getInstallationJobByProject(projectId: Int): InstallationJob?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstallationJob(job: InstallationJob)

    @Update
    suspend fun updateInstallationJob(job: InstallationJob)

    // --- Inventory ---
    @Query("SELECT * FROM inventory ORDER BY id DESC")
    fun getAllInventoryItems(): Flow<List<InventoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventoryItem(item: InventoryItem)

    @Update
    suspend fun updateInventoryItem(item: InventoryItem)

    @Query("DELETE FROM inventory WHERE id = :id")
    suspend fun deleteInventoryItemById(id: Int)

    // --- Suppliers ---
    @Query("SELECT * FROM suppliers ORDER BY id DESC")
    fun getAllSuppliers(): Flow<List<Supplier>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: Supplier)

    @Update
    suspend fun updateSupplier(supplier: Supplier)

    // --- Invoices ---
    @Query("SELECT * FROM invoices ORDER BY id DESC")
    fun getAllInvoices(): Flow<List<Invoice>>

    @Query("SELECT * FROM invoices WHERE id = :id")
    suspend fun getInvoiceById(id: Int): Invoice?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: Invoice): Long

    @Update
    suspend fun updateInvoice(invoice: Invoice)

    // --- Payments ---
    @Query("SELECT * FROM payments WHERE invoiceId = :invoiceId ORDER BY id DESC")
    fun getPaymentsForInvoice(invoiceId: Int): Flow<List<Payment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment)

    // --- Expenses ---
    @Query("SELECT * FROM expenses ORDER BY id DESC")
    fun getAllExpenses(): Flow<List<Expense>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: Expense)

    // --- Employees ---
    @Query("SELECT * FROM employees ORDER BY id DESC")
    fun getAllEmployees(): Flow<List<Employee>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: Employee)

    @Update
    suspend fun updateEmployee(employee: Employee)

    // --- Activity Logs ---
    @Query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 100")
    fun getAllActivityLogs(): Flow<List<ActivityLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivityLog(log: ActivityLog)

    // --- Notifications ---
    @Query("SELECT * FROM notifications ORDER BY id DESC")
    fun getAllNotifications(): Flow<List<Notification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: Notification)

    @Query("UPDATE notifications SET isRead = :isRead WHERE id = :id")
    suspend fun updateNotificationReadStatus(id: Int, isRead: Boolean)

    // --- Attachments ---
    @Query("SELECT * FROM attachments WHERE parentType = :parentType AND parentId = :parentId")
    fun getAttachmentsForParent(parentType: String, parentId: Int): Flow<List<AttachmentModel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachment(attachment: AttachmentModel)
}
