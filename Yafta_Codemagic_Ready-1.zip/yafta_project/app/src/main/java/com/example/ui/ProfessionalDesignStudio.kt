package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.zIndex
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.viewmodel.YaftaViewModel
import com.example.viewmodel.DesignLayer
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import kotlin.math.roundToInt

// Cosmic Design Premium Color Palette
val CosmicDeepBg = Color(0xFF09090C)
val CosmicPanelBg = Color(0xFF111116)
val CosmicPanelLight = Color(0xFF1B1B22)
val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFFFDF7A)
val EmeraldNeon = Color(0xFF00E676)
val RubyRed = Color(0xFFFF1744)
val PlatinumWhite = Color(0xFFF5F5F7)
val PlatinumGray = Color(0xFF8E8E93)
val GlassBorder = Color(0xFF282835)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RealProfessionalDesignStudio(viewModel: YaftaViewModel, onExit: (() -> Unit)? = null) {
    val lang = viewModel.language
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // --- 1. DOCKING & COLLAPSIBILITY LAYOUT SYSTEM ---
    var isLeftPanelVisible by remember { mutableStateOf(false) }
    var isRightPanelVisible by remember { mutableStateOf(false) }
    var leftPanelDockMode by remember { mutableStateOf("Docked") } // "Docked", "Floating"
    var rightPanelDockMode by remember { mutableStateOf("Docked") } // "Docked", "Floating"
    
    var leftFloatOffset by remember { mutableStateOf(Offset(40f, 150f)) }
    var rightFloatOffset by remember { mutableStateOf(Offset(800f, 150f)) }
    
    // Left sidebar dedicated navigation panel tabs
    var leftActiveTab by remember { mutableStateOf("Colors") } // Colors, Fonts, Elements, AI, Assets
    var rightActiveTab by remember { mutableStateOf("Layers") } // Layers, Detail, ProjectInfo

    // --- 2. MULTI-PAGE/DESIGN CONTROLLER STATE ---
    var pagesList by remember { mutableStateOf<List<List<DesignLayer>>>(
        listOf(
            listOf(
                DesignLayer("1", "الخلفية الافتراضية", "shape", "Rectangle", x = 0f, y = 0f, scaleX = 1000f, scaleY = 700f, colorHex = "#0E0E12", isLocked = true),
                DesignLayer("2", "شعار يافطة المذهب", "image", "logo", x = 110f, y = 30f, scaleX = 0.5f, scaleY = 0.5f),
                DesignLayer("3", "عنوان اللافتة الفخم", "text", "مؤسسة النخبة التجارية", x = 40f, y = 140f, fontSize = 24f, colorHex = "#D4AF37", fontName = "Cairo")
            )
        )
    ) }
    var activePageIndex by remember { mutableStateOf(0) }
    var pageNames by remember { mutableStateOf(listOf("لوحة الواجهة الرئيسية")) }

    // Init first page if canvas is empty
    LaunchedEffect(Unit) {
        if (viewModel.canvasLayers.isEmpty()) {
            viewModel.canvasLayers = pagesList[0]
        }
    }

    // Sync from ViewModel to our multi-page bank
    LaunchedEffect(viewModel.canvasLayers) {
        val updated = pagesList.toMutableList()
        if (activePageIndex < updated.size) {
            updated[activePageIndex] = viewModel.canvasLayers
            pagesList = updated
        }
    }

    // --- 3. CORE STUDIO CONTROLLERS STATE ---
    var textInputText by remember { mutableStateOf("حملة صيف 2026") }
    var textInputSize by remember { mutableStateOf("28") }
    var aiPromptText by remember { mutableStateOf("") }
    var protectDesignWatermark by remember { mutableStateOf(false) }

    // Dialog flags
    var showNewProjectDialog by remember { mutableStateOf(false) }
    var showOpenProjectDialog by remember { mutableStateOf(false) }
    var showSaveProjectDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showPreferencesDialog by remember { mutableStateOf(false) }
    
    // Preferences values
    var prefSnapGridSize by remember { mutableStateOf(40f) }
    var prefGuideColor by remember { mutableStateOf("#FF1744") } // Ruby red snapping line
    var prefThemeName by remember { mutableStateOf("Cosmic Dark") }
    var prefAutoSave by remember { mutableStateOf(true) }

    // New Project Dialog state
    var newProjName by remember { mutableStateOf("تصميم معرض النخبة الفاخر") }
    var newProjWidth by remember { mutableStateOf("300") }
    var newProjHeight by remember { mutableStateOf("120") }
    var newProjUnit by remember { mutableStateOf("CM") } // PX, CM, MM, Inch, Meter
    var isSavingPreset by remember { mutableStateOf(false) }
    var presetNameInput by remember { mutableStateOf("") }
    
    var customPresetsList by remember { mutableStateOf(listOf<Pair<String, Map<String, String>>>()) }
    var recentFilesList by remember { mutableStateOf(listOf("elite_outdoor_facade.yafta_proj", "commercial_neon_ribs.yafta_proj", "roadside_unipole_led.yafta_proj")) }

    // Undo/Redo tracking stacks
    var undoStack by remember { mutableStateOf<List<List<DesignLayer>>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<List<DesignLayer>>>(emptyList()) }
    
    val registerStateChange: (List<DesignLayer>) -> Unit = { currentLayers ->
        undoStack = undoStack + listOf(currentLayers.map { it.copy() })
        redoStack = emptyList()
    }

    // Pen tool active anchor points for path construction
    var penAnchorPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var selectedAnchorIndex by remember { mutableStateOf<Int?>(null) }
    
    // AI Activity Visual Simulation
    var aiActionLabel by remember { mutableStateOf("") }
    var aiActionProgress by remember { mutableStateOf(0f) }
    var showAiProcessOverlay by remember { mutableStateOf(false) }

    // Top Header Dropdowns active focus
    var activeMenuDropdown by remember { mutableStateOf<String?>(null) }

    // --- 4. SMART ALIGNMENT GUIDES CONTROLLER ---
    // Guides triggers when layer coordinates match central alignment lines
    var smartGuideX by remember { mutableStateOf<Float?>(null) }
    var smartGuideY by remember { mutableStateOf<Float?>(null) }
    var smartGuideLabel by remember { mutableStateOf("") }

    // Color Swatches Lists pointing to materials
    val dynamicColorsList = listOf(
        Pair("الملكي الذهبي", "#D4AF37"),
        Pair("البرونزي الكلاسيكي", "#A67C1E"),
        Pair("الأبيض النيون اللامع", "#FFFFFF"),
        Pair("الأسود كلادينج فاخر", "#0D0D0D"),
        Pair("الأحمر فليكس مضيء", "#FF1744"),
        Pair("الأخضر ليد زمردي", "#00E676"),
        Pair("الأزرق إستيل معتد", "#2979FF"),
        Pair("الأصفر توهج دافئ", "#FFD54F")
    )

    // Predefined size preset list
    val standardPresetsCategories = listOf("علامات الواجهات وإعلانات الطرق", "المقاسات المطبوعة والبروشور والميديا")

    // Project metadata mapping to local DB
    val projectsList by viewModel.projects.collectAsStateWithLifecycle(initialValue = emptyList())
    var activeLinkedProject by remember { mutableStateOf<com.example.data.Project?>(null) }
    var showProjectSelectorDialog by remember { mutableStateOf(false) }
    var showSuccessLinkDialog by remember { mutableStateOf(false) }

    // Pathfinder operations helper
    val executePathfinder: (String) -> Unit = { operation ->
        val layers = viewModel.canvasLayers
        if (layers.size >= 2) {
            registerStateChange(layers)
            val selected = layers.filter { it.id == viewModel.selectedLayerId }
            val other = layers.filter { it.id != viewModel.selectedLayerId }
            if (selected.isNotEmpty()) {
                val primary = selected.first()
                val targetName = when(operation) {
                    "Union" -> "Pathfinder [دمج متراكب]"
                    "Subtract" -> "Pathfinder [طرح العنصر]"
                    else -> "Pathfinder [تقاطع هندسي]"
                }
                val updatedPrimary = primary.copy(
                    name = targetName,
                    type = "vector",
                    scaleX = if (operation == "Union") primary.scaleX * 1.25f else primary.scaleX * 0.85f,
                    scaleY = if (operation == "Union") primary.scaleY * 1.25f else primary.scaleY * 0.85f,
                    vectorPathPoints = "30,30 180,30 220,170 80,220 30,170"
                )
                viewModel.canvasLayers = other + updatedPrimary
                Toast.makeText(context, "$operation executed successfully!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Please create at least 2 layers for Boolean Pathfinder", Toast.LENGTH_SHORT).show()
        }
    }

    // AI simulation task builder
    val runSimulatedAiEngine: (String, () -> Unit) -> Unit = { action, onComplete ->
        aiActionLabel = action
        aiActionProgress = 0f
        showAiProcessOverlay = true
        coroutineScope.launch {
            while (aiActionProgress < 1.0f) {
                kotlinx.coroutines.delay(120)
                aiActionProgress += 0.15f
            }
            onComplete()
            showAiProcessOverlay = false
            Toast.makeText(context, "تمت المعالجة الذكية بنجاح!", Toast.LENGTH_SHORT).show()
        }
    }

    // Main Workstation Layout
    Column(modifier = Modifier.fillMaxSize().background(CosmicDeepBg)) {

        // ==========================================
        // 1. FILE & ACTION TOP CONTROL BAR (Figma Style)
        // ==========================================
        Card(
            colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
            shape = RectangleShape,
            modifier = Modifier.fillMaxWidth().border(1.dp, GlassBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Leftside Options: Traditional Design Menu Dropdowns
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onExit != null) {
                        IconButton(
                            onClick = onExit,
                            modifier = Modifier.size(32.dp).background(CosmicPanelLight, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Exit to Dashboard",
                                tint = GoldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Logo Badge
                    Box(
                        modifier = Modifier
                            .background(GoldPrimary.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .border(1.dp, GoldPrimary, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("YAFTA PRO 5.0", color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    val menuTabs = listOf("File", "Edit", "View", "Window", "Help")
                    menuTabs.forEach { tab ->
                        Box {
                            Text(
                                text = if (lang == "ar") {
                                    when(tab) {
                                        "File" -> "ملف"
                                        "Edit" -> "تحرير"
                                        "View" -> "عرض"
                                        "Window" -> "نوافذ"
                                        else -> "مساعدة"
                                    }
                                } else tab,
                                color = if (activeMenuDropdown == tab) GoldPrimary else PlatinumWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { activeMenuDropdown = if (activeMenuDropdown == tab) null else tab }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            )

                            DropdownMenu(
                                expanded = activeMenuDropdown == tab,
                                onDismissRequest = { activeMenuDropdown = null },
                                modifier = Modifier.background(CosmicPanelLight).border(1.dp, GlassBorder)
                            ) {
                                when(tab) {
                                    "File" -> {
                                        DropdownMenuItem(
                                            text = { Text("مشروع جديد (New Project)...", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; showNewProjectDialog = true }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("قوالب العمل الجاهزة (Open)...", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; showOpenProjectDialog = true }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("حفظ التغييرات (Save)", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; showSaveProjectDialog = true }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("حفظ باسم (Save As)...", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; showSaveProjectDialog = true }
                                        )
                                        HorizontalDivider(color = GlassBorder)
                                        DropdownMenuItem(
                                            text = { Text("ربط بمشاريع ERP المزامنة...", color = GoldPrimary, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; showProjectSelectorDialog = true }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("تصدير ملفات تصنيع CNC/Neon (Export)...", color = EmeraldNeon, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; showExportDialog = true }
                                        )
                                    }
                                    "Edit" -> {
                                        DropdownMenuItem(
                                            text = { Text("تراجع خطوة (Undo)", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = {
                                                activeMenuDropdown = null
                                                if (undoStack.isNotEmpty()) {
                                                    redoStack = redoStack + listOf(viewModel.canvasLayers.map { it.copy() })
                                                    viewModel.canvasLayers = undoStack.last()
                                                    undoStack = undoStack.dropLast(1)
                                                }
                                            },
                                            enabled = undoStack.isNotEmpty()
                                        )
                                        DropdownMenuItem(
                                            text = { Text("إعادة تطبيق (Redo)", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = {
                                                activeMenuDropdown = null
                                                if (redoStack.isNotEmpty()) {
                                                    undoStack = undoStack + listOf(viewModel.canvasLayers.map { it.copy() })
                                                    viewModel.canvasLayers = redoStack.last()
                                                    redoStack = redoStack.dropLast(1)
                                                }
                                            },
                                            enabled = redoStack.isNotEmpty()
                                        )
                                        HorizontalDivider(color = GlassBorder)
                                        DropdownMenuItem(
                                            text = { Text("Pathfinder: دمج الطبقات", color = GoldPrimary, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; executePathfinder("Union") }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Pathfinder: طرح الطبقة", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; executePathfinder("Subtract") }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("خيارات الاستوديو (Preferences)...", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; showPreferencesDialog = true }
                                        )
                                    }
                                    "View" -> {
                                        DropdownMenuItem(
                                            text = { Text(if (viewModel.snapToGrid) "إخفاء الشبكة المساعدة" else "تفعيل المحاذاة للشبكة (Snap Grid)", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; viewModel.snapToGrid = !viewModel.snapToGrid }
                                        )
                                        DropdownMenuItem(
                                            text = { Text(if (protectDesignWatermark) "إلغاء العلامة المائية" else "تفعيل العلامة المائية الأمنية", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; protectDesignWatermark = !protectDesignWatermark }
                                        )
                                    }
                                    "Window" -> {
                                        DropdownMenuItem(
                                            text = { Text(if (isLeftPanelVisible) "إخفاء لوحة الأدوات اليسرى" else "إظهار لوحة الأدوات اليسرى", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; isLeftPanelVisible = !isLeftPanelVisible }
                                        )
                                        DropdownMenuItem(
                                            text = { Text(if (isRightPanelVisible) "إخفاء لوحة الطبقات اليمنى" else "إظهار لوحة الطبقات اليمنى", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; isRightPanelVisible = !isRightPanelVisible }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("تحويل اليسرى إلى لوحة عائمة", color = GoldPrimary, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; leftPanelDockMode = if (leftPanelDockMode == "Docked") "Floating" else "Docked" }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("تحويل اليمنى إلى لوحة عائمة", color = GoldPrimary, fontSize = 11.sp) },
                                            onClick = { activeMenuDropdown = null; rightPanelDockMode = if (rightPanelDockMode == "Docked") "Floating" else "Docked" }
                                        )
                                    }
                                    else -> {
                                        DropdownMenuItem(
                                            text = { Text("دروس التصميم والاختصارات...", color = PlatinumWhite, fontSize = 11.sp) },
                                            onClick = {
                                                activeMenuDropdown = null
                                                Toast.makeText(context, "الجيل الخامس لمصمم لوحات الإعلانات:\n- للرسم اضغط Pen وطقطق على الكانفاس\n- اسحب العناصر لتحديث موقعها", Toast.LENGTH_LONG).show()
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Middle: Micro Action Controllers (Undo, Redo, Zoom, Duplicate, Delete)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Undo File level
                    IconButton(
                        onClick = {
                            if (undoStack.isNotEmpty()) {
                                redoStack = redoStack + listOf(viewModel.canvasLayers.map { it.copy() })
                                viewModel.canvasLayers = undoStack.last()
                                undoStack = undoStack.dropLast(1)
                            }
                        },
                        enabled = undoStack.isNotEmpty(),
                        modifier = Modifier.size(32.dp).background(CosmicPanelLight, CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Undo, "Undo", tint = if (undoStack.isNotEmpty()) GoldPrimary else PlatinumGray.copy(alpha = 0.3f), modifier = Modifier.size(14.dp))
                    }

                    // Redo File level
                    IconButton(
                        onClick = {
                            if (redoStack.isNotEmpty()) {
                                undoStack = undoStack + listOf(viewModel.canvasLayers.map { it.copy() })
                                viewModel.canvasLayers = redoStack.last()
                                redoStack = redoStack.dropLast(1)
                            }
                        },
                        enabled = redoStack.isNotEmpty(),
                        modifier = Modifier.size(32.dp).background(CosmicPanelLight, CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Redo, "Redo", tint = if (redoStack.isNotEmpty()) GoldPrimary else PlatinumGray.copy(alpha = 0.3f), modifier = Modifier.size(14.dp))
                    }

                    // Duplicate
                    IconButton(
                        onClick = { viewModel.duplicateLayer() },
                        enabled = viewModel.selectedLayerId != null,
                        modifier = Modifier.size(32.dp).background(CosmicPanelLight, CircleShape)
                    ) {
                        Icon(Icons.Default.ContentCopy, "Duplicate", tint = if (viewModel.selectedLayerId != null) GoldPrimary else PlatinumGray.copy(alpha = 0.3f), modifier = Modifier.size(14.dp))
                    }

                    // Delete Layer
                    IconButton(
                        onClick = { viewModel.deleteSelectedLayer() },
                        enabled = viewModel.selectedLayerId != null,
                        modifier = Modifier.size(32.dp).background(CosmicPanelLight, CircleShape)
                    ) {
                        Icon(Icons.Default.Delete, "Delete", tint = if (viewModel.selectedLayerId != null) RubyRed else PlatinumGray.copy(alpha = 0.3f), modifier = Modifier.size(14.dp))
                    }

                    VerticalDivider(color = GlassBorder, modifier = Modifier.height(20.dp).padding(horizontal = 4.dp))

                    // Zoom Actions
                    Text("Zoom: ${(viewModel.canvasZoom * 100).roundToInt()}%", color = GoldenSliderColor(viewModel.canvasZoom), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { viewModel.canvasZoom = (viewModel.canvasZoom + 0.15f).coerceAtMost(3.0f) }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.ZoomIn, "Zoom In", tint = PlatinumWhite, modifier = Modifier.size(14.dp))
                    }
                    IconButton(onClick = { viewModel.canvasZoom = (viewModel.canvasZoom - 0.15f).coerceAtLeast(0.4f) }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.ZoomOut, "Zoom Out", tint = PlatinumWhite, modifier = Modifier.size(14.dp))
                    }
                    IconButton(onClick = { viewModel.canvasZoom = 1.0f; viewModel.canvasPanX = 0f; viewModel.canvasPanY = 0f }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Fullscreen, "Fit Screen", tint = PlatinumWhite, modifier = Modifier.size(14.dp))
                    }
                }

                // Rightside: Docking Reset & Preferences Shortcut
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (activeLinkedProject != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(EmeraldNeon.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
                                .border(1.dp, EmeraldNeon, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(activeLinkedProject?.title ?: "", color = EmeraldNeon, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    IconButton(onClick = { showPreferencesDialog = true }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Settings, contentDescription = "Preferences", tint = PlatinumGray, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        // ==========================================
        // 2. DYNAMIC PROPERTIES STRIP (Context-Aware Properties Bar)
        // ==========================================
        val activeLayer = viewModel.canvasLayers.find { it.id == viewModel.selectedLayerId }
        Card(
            colors = CardDefaults.cardColors(containerColor = CosmicPanelLight),
            shape = RectangleShape,
            modifier = Modifier.fillMaxWidth().border(1.dp, GlassBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (activeLayer == null) "الكانفا العام" else "خصائص [${activeLayer.name}]:",
                    color = GoldPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                if (activeLayer == null) {
                    // Standard Canvas general params
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("أبعاد اللوحة الميدانية:", color = PlatinumWhite, fontSize = 10.sp)
                        Text("${viewModel.signageWidthCm.toInt()} × ${viewModel.signageHeightCm.toInt()} CM", color = GoldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        
                        VerticalDivider(Modifier.height(14.dp).background(GlassBorder))
                        Text("وحدات القياس:", color = PlatinumWhite, fontSize = 10.sp)
                        Text("سنتيمتر (Metric)", color = PlatinumGray, fontSize = 10.sp)

                        VerticalDivider(Modifier.height(14.dp).background(GlassBorder))
                        Text("أداة التفاعل الحالية:", color = PlatinumWhite, fontSize = 10.sp)
                        AssistChip(
                            onClick = { },
                            label = { Text(viewModel.activeTool, fontSize = 9.sp, color = GoldPrimary) },
                            colors = AssistChipDefaults.assistChipColors(containerColor = CosmicPanelBg)
                        )
                    }
                } else {
                    // Context-aware dynamic property bar based on selected DesignLayer
                    when(activeLayer.type) {
                        "text" -> {
                            // Text modifications
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Text Editor
                                WidthLimitedPropertyField(
                                    label = "النص",
                                    value = activeLayer.content,
                                    width = 140
                                ) {
                                    registerStateChange(viewModel.canvasLayers)
                                    viewModel.updateSelectedLayerProperties(content = it)
                                }

                                // Font size slider
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("الحجم: ${activeLayer.fontSize.roundToInt()}", color = PlatinumWhite, fontSize = 10.sp)
                                    Slider(
                                        value = activeLayer.fontSize,
                                        onValueChange = {
                                            viewModel.updateSelectedLayerProperties(fontSize = it)
                                        },
                                        valueRange = 12f..100f,
                                        modifier = Modifier.width(100.dp)
                                    )
                                }

                                // Font Style Pick
                                Button(
                                    onClick = {
                                        registerStateChange(viewModel.canvasLayers)
                                        val currentFont = activeLayer.fontName
                                        val nextFont = if (currentFont == "Cairo") "Montserrat" else "Cairo"
                                        viewModel.updateSelectedLayerProperties(fontName = nextFont)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CosmicPanelBg),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.padding(2.dp)
                                ) {
                                    Text("الخط: ${activeLayer.fontName}", color = GoldPrimary, fontSize = 9.sp)
                                }

                                // Text curve option
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = activeLayer.isCurved,
                                        onCheckedChange = {
                                            registerStateChange(viewModel.canvasLayers)
                                            viewModel.updateSelectedLayerProperties(isCurved = it)
                                        },
                                        colors = CheckboxDefaults.colors(checkedColor = GoldPrimary)
                                    )
                                    Text("نص مقوس نيون", color = PlatinumWhite, fontSize = 9.sp)
                                }
                            }
                        }
                        "shape" -> {
                            // Shape modifications
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("نوع الشكل:", color = PlatinumWhite, fontSize = 10.sp)
                                var expandedShapeDrop by remember { mutableStateOf(false) }
                                Box {
                                    Text(
                                        text = activeLayer.content,
                                        color = GoldPrimary,
                                        fontSize = 10.sp,
                                        modifier = Modifier
                                            .background(CosmicPanelBg, RoundedCornerShape(4.dp))
                                            .clickable { expandedShapeDrop = true }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                    DropdownMenu(
                                        expanded = expandedShapeDrop,
                                        onDismissRequest = { expandedShapeDrop = false },
                                        modifier = Modifier.background(CosmicPanelBg)
                                    ) {
                                        listOf("Rectangle", "Circle", "Triangle", "Star").forEach { s ->
                                            DropdownMenuItem(
                                                text = { Text(s, color = PlatinumWhite, fontSize = 10.sp) },
                                                onClick = {
                                                    expandedShapeDrop = false
                                                    registerStateChange(viewModel.canvasLayers)
                                                    viewModel.updateSelectedLayerProperties(content = s)
                                                }
                                            )
                                        }
                                    }
                                }

                                Text("الشفافية:", color = PlatinumWhite, fontSize = 10.sp)
                                Slider(
                                    value = activeLayer.opacity,
                                    onValueChange = { viewModel.updateSelectedLayerProperties(opacity = it) },
                                    valueRange = 0f..1f,
                                    modifier = Modifier.width(100.dp)
                                )
                            }
                        }
                        "image" -> {
                            // Image adjustments
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("السطوع: ${activeLayer.brightness}", color = PlatinumWhite, fontSize = 9.sp)
                                Slider(
                                    value = activeLayer.brightness,
                                    onValueChange = { viewModel.updateSelectedLayerProperties(brightness = it) },
                                    valueRange = -1f..1f,
                                    modifier = Modifier.width(80.dp)
                                )
                                Text("التباين: ${activeLayer.contrast}", color = PlatinumWhite, fontSize = 9.sp)
                                Slider(
                                    value = activeLayer.contrast,
                                    onValueChange = { viewModel.updateSelectedLayerProperties(contrast = it) },
                                    valueRange = 0.5f..2f,
                                    modifier = Modifier.width(80.dp)
                                )
                                Text("التبخر/الحيوية:", color = PlatinumWhite, fontSize = 9.sp)
                                Slider(
                                    value = activeLayer.saturation,
                                    onValueChange = { viewModel.updateSelectedLayerProperties(saturation = it) },
                                    valueRange = 0f..2f,
                                    modifier = Modifier.width(80.dp)
                                )
                            }
                        }
                        "vector" -> {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("سماكة أنبوب النيون:", color = PlatinumWhite, fontSize = 10.sp)
                                Slider(
                                    value = activeLayer.lineWidth,
                                    onValueChange = { viewModel.updateSelectedLayerProperties(lineWidth = it) },
                                    valueRange = 2f..15f,
                                    modifier = Modifier.width(120.dp)
                                )
                                Text("اللون الحشوي:", color = PlatinumWhite, fontSize = 10.sp)
                                Surface(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .background(Color(android.graphics.Color.parseColor(activeLayer.colorHex)))
                                        .border(1.dp, GoldPrimary)
                                ) {}
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 3. MAIN EDITOR WORKSPACE
        // ==========================================
        BoxWithConstraints(modifier = Modifier.fillMaxWidth().weight(1f)) {
            val isCompact = maxWidth < 750.dp
            Row(modifier = Modifier.fillMaxSize()) {

                // SLIM LEFT TOOLBAR (Always visible, small professional icons)
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(48.dp)
                        .background(CosmicDeepBg)
                        .border(1.dp, GlassBorder)
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val tabs = listOf(
                        Triple("Colors", Icons.Default.Palette, "الألوان"),
                        Triple("Fonts", Icons.Default.TextFields, "الخطوط"),
                        Triple("Elements", Icons.Default.Category, "الأشكال"),
                        Triple("AI", Icons.Default.AutoAwesome, "الذكاء"),
                        Triple("Assets", Icons.Default.PhotoLibrary, "الأصول")
                    )
                    
                    tabs.forEach { (tab, icon, label) ->
                        val isSelected = isLeftPanelVisible && leftActiveTab == tab
                        IconButton(
                            onClick = {
                                if (leftActiveTab == tab && isLeftPanelVisible) {
                                    isLeftPanelVisible = false
                                } else {
                                    leftActiveTab = tab
                                    isLeftPanelVisible = true
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(if (isSelected) GoldPrimary.copy(alpha = 0.15f) else Color.Transparent, RoundedCornerShape(8.dp))
                                .border(1.dp, if (isSelected) GoldPrimary else Color.Transparent, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) GoldPrimary else PlatinumGray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // LEFT TOOL PANEL (Tabbed Colors, Fonts, Assets, AI, Elements) - Docked
                if (isLeftPanelVisible && leftPanelDockMode == "Docked" && !isCompact) {
                    LeftSidebarDockPanel(
                        activeTab = leftActiveTab,
                        onTabChange = { leftActiveTab = it },
                        textInputText = textInputText,
                        onTextChange = { textInputText = it },
                        textInputSize = textInputSize,
                        onSizeChange = { textInputSize = it },
                        aiPrompt = aiPromptText,
                        onAiPromptChange = { aiPromptText = it },
                        luxuryPaletteColors = dynamicColorsList,
                        viewModel = viewModel,
                        pagesList = pagesList,
                        onPagesChange = { pagesList = it },
                        activePageIndex = activePageIndex,
                        onActivePageChange = { activePageIndex = it },
                        pageNames = pageNames,
                        onPageNamesChange = { pageNames = it },
                        registerStateChange = registerStateChange,
                        runSimulatedAiEngine = runSimulatedAiEngine,
                        customPresetsList = customPresetsList,
                        recentFilesList = recentFilesList,
                        showProjectSelectorDialog = { showProjectSelectorDialog = true },
                        showNewProjectDialog = { showNewProjectDialog = true },
                        onDockToggle = { leftPanelDockMode = "Floating" }
                    )
                }

                // CENTER CANVAS WITH RULERS AND SMART SNAP LINES
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(CosmicDeepBg)
                        .clip(RectangleShape)
                ) {
                    
                    // Main Canvas Inner Wrapper
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { centroid, pan, zoom, rotation ->
                                    viewModel.canvasZoom = (viewModel.canvasZoom * zoom).coerceIn(0.4f, 3.0f)
                                    viewModel.canvasPanX += pan.x / viewModel.canvasZoom
                                    viewModel.canvasPanY += pan.y / viewModel.canvasZoom
                                }
                            }
                    ) {
                        
                        // Dimensions Board calculations
                        val maxBoardWidth = 320f
                        val maxBoardHeight = 220f
                        val boardRatio = viewModel.signageWidthCm / viewModel.signageHeightCm
                        val boardWidth: Float
                        val boardHeight: Float
                        if (boardRatio > maxBoardWidth / maxBoardHeight) {
                            boardWidth = maxBoardWidth
                            boardHeight = maxBoardWidth / boardRatio
                        } else {
                            boardHeight = maxBoardHeight
                            boardWidth = maxBoardHeight * boardRatio
                        }

                        // Central Work Board Box
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .scale(viewModel.canvasZoom)
                                .offset(x = viewModel.canvasPanX.dp, y = viewModel.canvasPanY.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            
                            // Visual horizontal & vertical rulers for measurement
                            Box(
                                modifier = Modifier
                                    .size((boardWidth + 30).dp, (boardHeight + 30).dp)
                                    .drawBehind {
                                        // Top Ruler metric intervals
                                        val numDivisions = 10
                                        val rulerHeight = 15.dp.toPx()
                                        val stepX = (boardWidth.dp.toPx() / numDivisions)
                                        val cmStep = viewModel.signageWidthCm / numDivisions
                                        
                                        // Draw top ruler background
                                        drawRect(
                                            color = CosmicPanelLight,
                                            size = androidx.compose.ui.geometry.Size(boardWidth.dp.toPx(), rulerHeight),
                                            topLeft = Offset(15.dp.toPx(), 0f)
                                        )
                                        
                                        for (i in 0..numDivisions) {
                                            val xPos = 15.dp.toPx() + (i * stepX)
                                            drawLine(
                                                color = GoldPrimary.copy(alpha = 0.5f),
                                                start = Offset(xPos, 0f),
                                                end = Offset(xPos, rulerHeight * if (i % 2 == 0) 0.8f else 0.5f),
                                                strokeWidth = 1.5f
                                            )
                                        }

                                        // Left Ruler metric intervals
                                        val stepY = (boardHeight.dp.toPx() / numDivisions)
                                        drawRect(
                                            color = CosmicPanelLight,
                                            size = androidx.compose.ui.geometry.Size(rulerHeight, boardHeight.dp.toPx()),
                                            topLeft = Offset(0f, 15.dp.toPx())
                                        )

                                        for (i in 0..numDivisions) {
                                            val yPos = 15.dp.toPx() + (i * stepY)
                                            drawLine(
                                                color = GoldPrimary.copy(alpha = 0.5f),
                                                start = Offset(0f, yPos),
                                                end = Offset(rulerHeight * if (i % 2 == 0) 0.8f else 0.5f, yPos),
                                                strokeWidth = 1.5f
                                            )
                                        }
                                    }
                            ) {
                                
                                // The actual board workspace where elements live
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(boardWidth.dp, boardHeight.dp)
                                        .shadow(16.dp, shape = RoundedCornerShape(4.dp), spotColor = GoldPrimary)
                                        .background(Color.Black, shape = RoundedCornerShape(4.dp))
                                        .border(BorderStroke(1.dp, GlassBorder), shape = RoundedCornerShape(4.dp))
                                        .pointerInput(viewModel.activeTool) {
                                            detectTapGestures { offset ->
                                                if (viewModel.activeTool == "Pen") {
                                                    penAnchorPoints = penAnchorPoints + listOf(offset)
                                                    registerStateChange(viewModel.canvasLayers)
                                                    val pointsString = penAnchorPoints.joinToString(" ") { "${it.x},${it.y}" }
                                                    val selectedLayer = viewModel.canvasLayers.find { it.id == viewModel.selectedLayerId }
                                                    if (selectedLayer != null && selectedLayer.type == "vector") {
                                                        viewModel.updateSelectedLayerProperties(vectorPathPoints = pointsString)
                                                    } else {
                                                        val newId = UUID.randomUUID().toString()
                                                        viewModel.canvasLayers = viewModel.canvasLayers + DesignLayer(
                                                            id = newId,
                                                            name = "مسار نيون عشوائي",
                                                            type = "vector",
                                                            content = "CustomPath",
                                                            vectorPathPoints = pointsString,
                                                            colorHex = "#FFBF00",
                                                            lineWidth = 4f
                                                        )
                                                        viewModel.selectedLayerId = newId
                                                    }
                                                }
                                            }
                                        }
                                ) {
                                    
                                    // Plot layers
                                    viewModel.canvasLayers.forEach { layer ->
                                        if (layer.isVisible) {
                                            val isSelected = viewModel.selectedLayerId == layer.id
                                            val matrix = remember(layer) {
                                                val mat = ColorMatrix()
                                                mat.setToSaturation(layer.saturation)
                                                val contrast = layer.contrast
                                                val bright = layer.brightness * 128f
                                                val scaleArr = floatArrayOf(
                                                    contrast, 0f, 0f, 0f, bright + layer.adjustExposure * 40f,
                                                    0f, contrast, 0f, 0f, bright + layer.adjustExposure * 40f,
                                                    0f, 0f, contrast, 0f, bright + layer.adjustExposure * 40f,
                                                    0f, 0f, 0f, 1f, 0f
                                                )
                                                mat.timesAssign(ColorMatrix(scaleArr))
                                                mat
                                            }

                                            val activeBlendMode = when(layer.blendMode) {
                                                "Multiply" -> BlendMode.Multiply
                                                "Screen" -> BlendMode.Screen
                                                "Overlay" -> BlendMode.Overlay
                                                "Darken" -> BlendMode.Darken
                                                "Lighten" -> BlendMode.Lighten
                                                else -> BlendMode.SrcOver
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .offset(x = layer.x.dp, y = layer.y.dp)
                                                    .rotate(layer.rotation)
                                                    .scale(layer.scaleX, layer.scaleY)
                                                    .alpha(layer.opacity)
                                                    .drawWithContent {
                                                        if (activeBlendMode != BlendMode.SrcOver) {
                                                            drawIntoCanvas { canvas ->
                                                                canvas.saveLayer(Rect(0f, 0f, size.width, size.height), Paint().apply { blendMode = activeBlendMode })
                                                                drawContent()
                                                                canvas.restore()
                                                            }
                                                        } else {
                                                            drawContent()
                                                        }
                                                    }
                                                    .pointerInput(layer.id) {
                                                        detectDragGestures(
                                                            onDragStart = {
                                                                if (!layer.isLocked) {
                                                                    viewModel.selectedLayerId = layer.id
                                                                }
                                                            },
                                                            onDragEnd = {
                                                                smartGuideX = null
                                                                smartGuideY = null
                                                            },
                                                            onDragCancel = {
                                                                smartGuideX = null
                                                                smartGuideY = null
                                                            },
                                                            onDrag = { change, dragAmount ->
                                                                if (!layer.isLocked) {
                                                                    change.consume()
                                                                    registerStateChange(viewModel.canvasLayers)
                                                                    
                                                                    // Raw position proposal
                                                                    val rawX = layer.x + (dragAmount.x / viewModel.canvasZoom)
                                                                    val rawY = layer.y + (dragAmount.y / viewModel.canvasZoom)
                                                                    
                                                                    // Auto snap logic to center grid
                                                                    val boardCenterX = boardWidth / 2f
                                                                    val boardCenterY = boardHeight / 2f
                                                                    
                                                                    var finalX = rawX
                                                                    var finalY = rawY
                                                                    
                                                                    // Check proximity within 8.dp to draw snap guidelines
                                                                    if (java.lang.Math.abs(rawX - boardCenterX) < 8f) {
                                                                        finalX = boardCenterX
                                                                        smartGuideX = boardCenterX
                                                                        smartGuideLabel = "محاذاة في المركز الأفقي"
                                                                    } else {
                                                                        smartGuideX = null
                                                                    }

                                                                    if (java.lang.Math.abs(rawY - boardCenterY) < 8f) {
                                                                        finalY = boardCenterY
                                                                        smartGuideY = boardCenterY
                                                                        smartGuideLabel = "محاذاة في المركز الرأسي"
                                                                    } else {
                                                                        smartGuideY = null
                                                                    }

                                                                    viewModel.updateSelectedLayerProperties(
                                                                        x = finalX,
                                                                        y = finalY
                                                                    )
                                                                }
                                                            }
                                                        )
                                                    }
                                                    .clickable {
                                                        if (!layer.isLocked) viewModel.selectedLayerId = layer.id
                                                    }
                                                    .border(
                                                        width = if (isSelected) 1.5.dp else 0.dp,
                                                        color = if (isSelected) GoldPrimary else Color.Transparent,
                                                        shape = RoundedCornerShape(2.dp)
                                                    )
                                                    .padding(2.dp)
                                            ) {
                                                when(layer.type) {
                                                    "text" -> {
                                                        val fontStyle = if (layer.fontName == "Cairo") FontFamily.SansSerif else FontFamily.Default
                                                        val brushColor = if (layer.gradientColorStartHex != null && layer.gradientColorEndHex != null) {
                                                            Brush.linearGradient(listOf(
                                                                Color(android.graphics.Color.parseColor(layer.gradientColorStartHex)),
                                                                Color(android.graphics.Color.parseColor(layer.gradientColorEndHex))
                                                            ))
                                                        } else {
                                                            Brush.linearGradient(listOf(
                                                                Color(android.graphics.Color.parseColor(layer.colorHex)),
                                                                Color(android.graphics.Color.parseColor(layer.colorHex))
                                                            ))
                                                        }
                                                        Text(
                                                            text = layer.content,
                                                            style = androidx.compose.ui.text.TextStyle(
                                                                brush = brushColor,
                                                                fontSize = layer.fontSize.sp,
                                                                fontFamily = fontStyle,
                                                                fontWeight = FontWeight.Bold,
                                                                letterSpacing = layer.letterSpacing.sp,
                                                                shadow = Shadow(
                                                                    color = Color(android.graphics.Color.parseColor(layer.shadowColorHex)),
                                                                    offset = Offset(layer.shadowOffsetX, layer.shadowOffsetY),
                                                                    blurRadius = layer.shadowRadius
                                                                )
                                                            )
                                                        )
                                                    }
                                                    "shape" -> {
                                                        Canvas(modifier = Modifier.size(100.dp, 80.dp)) {
                                                            val col = Color(android.graphics.Color.parseColor(layer.colorHex))
                                                            when(layer.content) {
                                                                "Rectangle" -> drawRect(color = col, size = size)
                                                                "Circle" -> drawCircle(color = col, radius = size.minDimension / 2f)
                                                                "Triangle" -> {
                                                                    val path = Path().apply {
                                                                        moveTo(size.width / 2f, 0f)
                                                                        lineTo(size.width, size.height)
                                                                        lineTo(0f, size.height)
                                                                        close()
                                                                    }
                                                                    drawPath(path, color = col)
                                                                }
                                                                "Star" -> {
                                                                    val path = Path().apply {
                                                                        val centerX = size.width / 2f
                                                                        val centerY = size.height / 2f
                                                                        val outerRadius = size.width / 2f
                                                                        val innerRadius = size.width / 5f
                                                                        val points = 5
                                                                        var angle = -Math.PI / 2
                                                                        val nextAngle = Math.PI / points
                                                                        moveTo(
                                                                            (centerX + outerRadius * Math.cos(angle)).toFloat(),
                                                                            (centerY + outerRadius * Math.sin(angle)).toFloat()
                                                                        )
                                                                        for (i in 0 until points * 2) {
                                                                            angle += nextAngle
                                                                            val r = if (i % 2 == 0) innerRadius else outerRadius
                                                                            lineTo(
                                                                                (centerX + r * Math.cos(angle)).toFloat(),
                                                                                (centerY + r * Math.sin(angle)).toFloat()
                                                                            )
                                                                        }
                                                                        close()
                                                                    }
                                                                    drawPath(path, color = col)
                                                                }
                                                            }
                                                        }
                                                    }
                                                    "image" -> {
                                                        Box(modifier = Modifier.size(90.dp)) {
                                                            if (layer.content == "logo") {
                                                                ProgrammaticLogoShield(
                                                                    modifier = Modifier
                                                                        .fillMaxSize()
                                                                        .drawWithContent {
                                                                            val filter = ColorFilter.colorMatrix(matrix)
                                                                            drawIntoCanvas { canvas ->
                                                                                canvas.saveLayer(Rect(0f, 0f, size.width, size.height), Paint().apply { colorFilter = filter })
                                                                                drawContent()
                                                                                canvas.restore()
                                                                            }
                                                                        }
                                                                )
                                                            } else {
                                                                Box(
                                                                    modifier = Modifier
                                                                        .fillMaxSize()
                                                                        .background(CosmicPanelLight, RoundedCornerShape(4.dp))
                                                                        .border(BorderStroke(1.dp, GoldPrimary), RoundedCornerShape(4.dp)),
                                                                    contentAlignment = Alignment.Center
                                                                ) {
                                                                    Text(layer.name, color = GoldLight, fontSize = 9.sp, textAlign = TextAlign.Center)
                                                                }
                                                            }
                                                        }
                                                    }
                                                    "vector" -> {
                                                        Canvas(modifier = Modifier.size(150.dp, 150.dp)) {
                                                            val strokeCol = Color(android.graphics.Color.parseColor(layer.colorHex))
                                                            val pathPoints = try {
                                                                layer.vectorPathPoints.split(" ").filter { it.isNotEmpty() }.map {
                                                                    val p = it.split(",")
                                                                    Offset(p[0].toFloat(), p[1].toFloat())
                                                                }
                                                            } catch(e: Exception) {
                                                                emptyList()
                                                            }

                                                            if (pathPoints.isNotEmpty()) {
                                                                val path = Path().apply {
                                                                    moveTo(pathPoints[0].x, pathPoints[0].y)
                                                                    for (i in 1 until pathPoints.size) {
                                                                        lineTo(pathPoints[i].x, pathPoints[i].y)
                                                                    }
                                                                }
                                                                drawPath(path, color = strokeCol, style = Stroke(width = layer.lineWidth))
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                // Dynamic Layer dimensions label overlays showing coordinates
                                                if (isSelected) {
                                                    Box(
                                                        modifier = Modifier
                                                            .align(Alignment.TopStart)
                                                            .offset(y = (-15).dp)
                                                            .background(GoldPrimary, RoundedCornerShape(2.dp))
                                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("X:${layer.x.toInt()} Y:${layer.y.toInt()}", color = CosmicDeepBg, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Guide overlay drawings indicating active Smart-snip guides
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        prefGuideColor.let { colHex ->
                                            val guideCol = Color(android.graphics.Color.parseColor(colHex))
                                            
                                            smartGuideX?.let { sx ->
                                                drawLine(
                                                    color = guideCol,
                                                    start = Offset(sx * (boardWidth / 320f), 0f),
                                                    end = Offset(sx * (boardWidth / 320f), size.height),
                                                    strokeWidth = 1.5f,
                                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                                                )
                                            }

                                            smartGuideY?.let { sy ->
                                                drawLine(
                                                    color = guideCol,
                                                    start = Offset(0f, sy * (boardHeight / 220f)),
                                                    end = Offset(size.width, sy * (boardHeight / 220f)),
                                                    strokeWidth = 1.5f,
                                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                                                )
                                            }
                                        }
                                    }

                                    // Active Guide tag labels bubble
                                    if (smartGuideX != null || smartGuideY != null) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopCenter)
                                                .padding(6.dp)
                                                .background(RubyRed, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(smartGuideLabel, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Watermarks protection rendering
                                    if (protectDesignWatermark) {
                                        Box(
                                            modifier = Modifier.matchParentSize(),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "YAFTA STUDIO PRO • CONFIDENTIAL\n© يافطة للدعاية والإعلان - حماية سرية",
                                                color = GoldPrimary.copy(alpha = 0.05f),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.rotate(-28f),
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }

                                    // Crop marks indication
                                    if (viewModel.showCropMarks) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(4.dp)
                                                .drawBehind {
                                                    val lSize = 8.dp.toPx()
                                                    val sW = 1.5.dp.toPx()
                                                    val col = RubyRed.copy(alpha = 0.6f)
                                                    drawLine(col, Offset(0f, 0f), Offset(lSize, 0f), sW)
                                                    drawLine(col, Offset(0f, 0f), Offset(0f, lSize), sW)
                                                    drawLine(col, Offset(size.width, 0f), Offset(size.width - lSize, 0f), sW)
                                                    drawLine(col, Offset(size.width, 0f), Offset(size.width, lSize), sW)
                                                }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Floating Miniature indicator showing current selected page index
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp)
                            .background(CosmicPanelBg.copy(alpha = 0.85f), RoundedCornerShape(12.dp))
                            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("الصفحة النشطة: ${pageNames[activePageIndex]}", color = GoldPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            VerticalDivider(modifier = Modifier.height(10.dp).background(GlassBorder))
                            Text("أبعاد العمل: ${viewModel.signageWidthCm.toInt()} x ${viewModel.signageHeightCm.toInt()} cm", color = PlatinumWhite, fontSize = 9.sp)
                        }
                    }
                }

                // RIGHT SIDE PANEL: MASTER PSD LAYERS INDEX
                if (isRightPanelVisible && rightPanelDockMode == "Docked" && !isCompact) {
                    RightSidebarDockPanel(
                        activeTab = rightActiveTab,
                        onTabChange = { rightActiveTab = it },
                        viewModel = viewModel,
                        registerStateChange = registerStateChange,
                        activeLinkedProject = activeLinkedProject,
                        onLinkProject = { showProjectSelectorDialog = true },
                        onDockToggle = { rightPanelDockMode = "Floating" }
                    )
                }

                // SLIM RIGHT TOOLBAR (Always visible, small professional icons)
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(48.dp)
                        .background(CosmicDeepBg)
                        .border(1.dp, GlassBorder)
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val rightTabs = listOf(
                        Triple("Layers", Icons.Default.Layers, "طبقات"),
                        Triple("Detail", Icons.Default.Link, "مزامنة ERP")
                    )
                    
                    rightTabs.forEach { (tab, icon, label) ->
                        val isSelected = isRightPanelVisible && rightActiveTab == tab
                        IconButton(
                            onClick = {
                                if (rightActiveTab == tab && isRightPanelVisible) {
                                    isRightPanelVisible = false
                                } else {
                                    rightActiveTab = tab
                                    isRightPanelVisible = true
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(if (isSelected) GoldPrimary.copy(alpha = 0.15f) else Color.Transparent, RoundedCornerShape(8.dp))
                                .border(1.dp, if (isSelected) GoldPrimary else Color.Transparent, RoundedCornerShape(8.dp))
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) GoldPrimary else PlatinumGray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // ==========================================
            // 4. FLOATING/RESPONSIVE OVERLAY PANELS
            // ==========================================
            if (isLeftPanelVisible && (leftPanelDockMode == "Floating" || isCompact)) {
                val overlayOffset = if (isCompact) 48.dp else 0.dp
                Box(
                    modifier = Modifier
                        .zIndex(20f)
                        .align(Alignment.TopStart)
                        .padding(start = overlayOffset, top = if (isCompact) 10.dp else 40.dp)
                        .then(
                            if (leftPanelDockMode == "Floating" && !isCompact) {
                                Modifier.offset { IntOffset(leftFloatOffset.x.roundToInt(), leftFloatOffset.y.roundToInt()) }
                                .shadow(24.dp, RoundedCornerShape(12.dp))
                                .pointerInput(Unit) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        leftFloatOffset = Offset(leftFloatOffset.x + dragAmount.x, leftFloatOffset.y + dragAmount.y)
                                    }
                                }
                            } else {
                                Modifier.shadow(16.dp, RoundedCornerShape(12.dp))
                            }
                        )
                        .width(280.dp)
                        .fillMaxHeight(if (isCompact) 0.85f else 0.9f)
                ) {
                    LeftSidebarDockPanel(
                        activeTab = leftActiveTab,
                        onTabChange = { leftActiveTab = it },
                        textInputText = textInputText,
                        onTextChange = { textInputText = it },
                        textInputSize = textInputSize,
                        onSizeChange = { textInputSize = it },
                        aiPrompt = aiPromptText,
                        onAiPromptChange = { aiPromptText = it },
                        luxuryPaletteColors = dynamicColorsList,
                        viewModel = viewModel,
                        pagesList = pagesList,
                        onPagesChange = { pagesList = it },
                        activePageIndex = activePageIndex,
                        onActivePageChange = { activePageIndex = it },
                        pageNames = pageNames,
                        onPageNamesChange = { pageNames = it },
                        registerStateChange = registerStateChange,
                        runSimulatedAiEngine = runSimulatedAiEngine,
                        customPresetsList = customPresetsList,
                        recentFilesList = recentFilesList,
                        showProjectSelectorDialog = { showProjectSelectorDialog = true },
                        showNewProjectDialog = { showNewProjectDialog = true },
                        onDockToggle = { if (!isCompact) leftPanelDockMode = "Docked" }
                    )
                }
            }

            if (isRightPanelVisible && (rightPanelDockMode == "Floating" || isCompact)) {
                val overlayOffset = if (isCompact) 48.dp else 0.dp
                Box(
                    modifier = Modifier
                        .zIndex(20f)
                        .align(Alignment.TopEnd)
                        .padding(end = overlayOffset, top = if (isCompact) 10.dp else 40.dp)
                        .then(
                            if (rightPanelDockMode == "Floating" && !isCompact) {
                                Modifier.offset { IntOffset(rightFloatOffset.x.roundToInt(), rightFloatOffset.y.roundToInt()) }
                                .shadow(24.dp, RoundedCornerShape(12.dp))
                                .pointerInput(Unit) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        rightFloatOffset = Offset(rightFloatOffset.x + dragAmount.x, rightFloatOffset.y + dragAmount.y)
                                    }
                                }
                            } else {
                                Modifier.shadow(16.dp, RoundedCornerShape(12.dp))
                            }
                        )
                        .width(280.dp)
                        .fillMaxHeight(if (isCompact) 0.85f else 0.9f)
                ) {
                    RightSidebarDockPanel(
                        activeTab = rightActiveTab,
                        onTabChange = { rightActiveTab = it },
                        viewModel = viewModel,
                        registerStateChange = registerStateChange,
                        activeLinkedProject = activeLinkedProject,
                        onLinkProject = { showProjectSelectorDialog = true },
                        onDockToggle = { if (!isCompact) rightPanelDockMode = "Docked" }
                    )
                }
            }
        }

        // ==========================================
        // 5. STATUS DOCK (Information Indicator)
        // ==========================================
        Card(
            colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
            shape = RectangleShape,
            modifier = Modifier.fillMaxWidth().border(1.dp, GlassBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("أداة التفاعل: ${viewModel.activeTool}", color = PlatinumWhite, fontSize = 9.sp)
                    Text("عدد الطبقات: ${viewModel.canvasLayers.size}", color = PlatinumWhite, fontSize = 9.sp)
                    Text("دقة التبويب: ${viewModel.dpiValidation} DPI (Auto)", color = PlatinumWhite, fontSize = 9.sp)
                }
                
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Quick collapse indicators
                    TextButton(onClick = { isLeftPanelVisible = !isLeftPanelVisible }, contentPadding = PaddingValues(0.dp)) {
                        Text(if (isLeftPanelVisible) "إخفاء شريط الأدوات ◀" else "إظهار شريط الأدوات ▶", color = GoldPrimary, fontSize = 9.sp)
                    }
                    TextButton(onClick = { isRightPanelVisible = !isRightPanelVisible }, contentPadding = PaddingValues(0.dp)) {
                        Text(if (isRightPanelVisible) "إخفاء الطبقات ▶" else "إظهار الطبقات ◀", color = GoldPrimary, fontSize = 9.sp)
                    }
                }
            }
        }
    }

    // ==========================================
    // 6. POPUP SCREEN SPECIFICATIONS (DIALOGS)
    // ==========================================

    // A. PREMIUM NEW PROJECT DIALOG (With Square Meters specs & Standard preset categories)
    if (showNewProjectDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNewProjectDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, GoldPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 580.dp)
                    .padding(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(18.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("تخصيص لوحة لافتة جديدة (Wizard)", color = GoldPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    
                    OutlinedTextField(
                        value = newProjName,
                        onValueChange = { newProjName = it },
                        label = { Text("اسم المشروع الإعلاني", color = PlatinumGray, fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, focusedLabelColor = GoldPrimary, focusedTextColor = PlatinumWhite, unfocusedTextColor = PlatinumWhite),
                        textStyle = androidx.compose.ui.text.TextStyle(color = PlatinumWhite),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = newProjWidth,
                            onValueChange = { newProjWidth = it },
                            label = { Text("عرض اللوحة", color = PlatinumGray, fontSize = 11.sp) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, focusedLabelColor = GoldPrimary, focusedTextColor = PlatinumWhite, unfocusedTextColor = PlatinumWhite),
                            textStyle = androidx.compose.ui.text.TextStyle(color = PlatinumWhite),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = newProjHeight,
                            onValueChange = { newProjHeight = it },
                            label = { Text("ارتفاع اللوحة", color = PlatinumGray, fontSize = 11.sp) },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = GoldPrimary, focusedLabelColor = GoldPrimary, focusedTextColor = PlatinumWhite, unfocusedTextColor = PlatinumWhite),
                            textStyle = androidx.compose.ui.text.TextStyle(color = PlatinumWhite),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Unit selector row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("وحدة القياس المعتمدة:", color = PlatinumWhite, fontSize = 11.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("PX", "CM", "MM", "Inch", "Meter").forEach { unit ->
                                val isActive = newProjUnit == unit
                                Box(
                                    modifier = Modifier
                                        .clickable { newProjUnit = unit }
                                        .background(if (isActive) GoldPrimary else CosmicPanelLight, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(unit, color = if (isActive) CosmicDeepBg else PlatinumWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Dynamic Area calculation
                    val parsedW = newProjWidth.toFloatOrNull() ?: 300f
                    val parsedH = newProjHeight.toFloatOrNull() ?: 120f
                    val areaM2Calculated = when(newProjUnit) {
                        "Meter" -> parsedW * parsedH
                        "CM" -> (parsedW / 100f) * (parsedH / 100f)
                        "MM" -> (parsedW / 1000f) * (parsedH / 1000f)
                        "Inch" -> (parsedW * 0.0254f) * (parsedH * 0.0254f)
                        else -> (parsedW * 0.00026f) * (parsedH * 0.00026f) // pixel approx
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CosmicPanelLight, RoundedCornerShape(8.dp))
                            .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("المساحة الكلية للمشروع تلقائياً:", color = PlatinumWhite, fontSize = 10.sp)
                            Text(String.format("%.3f م² (Square Meter)", areaM2Calculated), color = EmeraldNeon, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Predefined Standards Categories
                    Text("مكتبة المقاسات والديكورات الجاهزة:", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    
                    standardPresetsCategories.forEach { category ->
                        Text(category, color = PlatinumGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (category.contains("الواجهات")) {
                                item {
                                    PresetChip("شارع تجاري كلادينج (400x150cm CM)") {
                                        newProjWidth = "400"; newProjHeight = "150"; newProjUnit = "CM"
                                    }
                                }
                                item {
                                    PresetChip("مكتب استقبال داخلي (150x80cm CM)") {
                                        newProjWidth = "150"; newProjHeight = "80"; newProjUnit = "CM"
                                    }
                                }
                                item {
                                    PresetChip("لوحة طريق يونيبول (1200x400cm CM)") {
                                        newProjWidth = "1200"; newProjHeight = "400"; newProjUnit = "CM"
                                    }
                                }
                                item {
                                    PresetChip("صندوق ليد خارجي (80x80cm CM)") {
                                        newProjWidth = "80"; newProjHeight = "80"; newProjUnit = "CM"
                                    }
                                }
                            } else {
                                item {
                                    PresetChip("مربع انستقرام (1080x1080 px)") {
                                        newProjWidth = "1080"; newProjHeight = "1080"; newProjUnit = "PX"
                                    }
                                }
                                item {
                                    PresetChip("غلاف فيس بوك (1200x630 px)") {
                                        newProjWidth = "1200"; newProjHeight = "630"; newProjUnit = "PX"
                                    }
                                }
                                item {
                                    PresetChip("بروشور قياسي A4 (29.7x21 cm)") {
                                        newProjWidth = "29.7"; newProjHeight = "21"; newProjUnit = "CM"
                                    }
                                }
                                item {
                                    PresetChip("كارت شخصي ستاندرد (9x5 cm)") {
                                        newProjWidth = "9"; newProjHeight = "5"; newProjUnit = "CM"
                                    }
                                }
                            }
                        }
                    }

                    if (isSavingPreset) {
                        OutlinedTextField(
                            value = presetNameInput,
                            onValueChange = { presetNameInput = it },
                            label = { Text("اسم القالب لحفظه بالمقاسات", color = PlatinumGray) },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = PlatinumWhite, unfocusedTextColor = PlatinumWhite),
                            textStyle = androidx.compose.ui.text.TextStyle(color = PlatinumWhite),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { showNewProjectDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicPanelLight),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء", color = PlatinumWhite)
                        }
                        Button(
                            onClick = {
                                if (isSavingPreset && presetNameInput.isNotEmpty()) {
                                    val newMap = mapOf("w" to newProjWidth, "h" to newProjHeight, "u" to newProjUnit)
                                    customPresetsList = customPresetsList + listOf(Pair(presetNameInput, newMap))
                                }
                                showNewProjectDialog = false
                                isSavingPreset = false
                                viewModel.signageWidthCm = when(newProjUnit) {
                                    "PX" -> parsedW * 0.026f
                                    "MM" -> parsedW / 10f
                                    "Inch" -> parsedW * 2.54f
                                    "Meter" -> parsedW * 100f
                                    else -> parsedW
                                }
                                viewModel.signageHeightCm = when(newProjUnit) {
                                    "PX" -> parsedH * 0.026f
                                    "MM" -> parsedH / 10f
                                    "Inch" -> parsedH * 2.54f
                                    "Meter" -> parsedH * 100f
                                    else -> parsedH
                                }
                                registerStateChange(viewModel.canvasLayers)
                                viewModel.canvasLayers = listOf(
                                    DesignLayer("1", "الخلفية الافتراضية للوحة", "shape", "Rectangle", x = 0f, y = 0f, scaleX = 1000f, scaleY = 700f, colorHex = "#0E0E12", isLocked = true),
                                    DesignLayer("2", "جملة يافطة مخصصة", "text", newProjName, x = 60f, y = 140f, fontSize = 21f, colorHex = "#D4AF37")
                                )
                                viewModel.selectedLayerId = "2"
                                Toast.makeText(context, "تم تهيئة لوحة العمل بالمقاس والتدرج المالي بنجاح!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Text("إنشاء اللوحة", color = CosmicDeepBg, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // B. EXPORT DIALOG
    if (showExportDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showExportDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth().padding(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("تصدير التصاميم لوحدات الإنتاج والعملاء", color = GoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("اختر صيغة الملف المتوافقة مع ماكينة الفرز أو ليزر النيون:", color = PlatinumGray, fontSize = 10.sp)
                    
                    ExportOptionCard(title = "تصدير متجهات راوتر SVG - Router Cutout", subtitle = "مثالي لقص الكلادينج والخشب والمواد الأكريليكية") {
                        showExportDialog = false
                        val svgText = generateSvgString(viewModel.signageWidthCm, viewModel.signageHeightCm, viewModel.canvasLayers)
                        shareFile(context, "cyan_milled_facing.svg", svgText, "image/svg+xml")
                    }

                    ExportOptionCard(title = "تصدير ملف أوتوكاد DXF - Laser Cutting Paths", subtitle = "متطابق مع ماكينات الليزر وثني الإستيل والألومنيوم") {
                        showExportDialog = false
                        val dxfText = generateDxfString(viewModel.canvasLayers)
                        shareFile(context, "facade_mill_cut.dxf", dxfText, "application/dxf")
                    }

                    ExportOptionCard(title = "تصدير صورة معالجة بريزنتشن JPG - High Quality Presentation", subtitle = "لمشاركتها عبر الواتساب مع العميل لاعتماد العقد واللوحة") {
                        showExportDialog = false
                        Toast.makeText(context, "جاري تحويل متجهات البيكسل والريل-تايم لصورة ...", Toast.LENGTH_LONG).show()
                        coroutineScope.launch {
                            kotlinx.coroutines.delay(1000)
                            Toast.makeText(context, "تم إعداد صورة العرض بجودة 300 DPI للمعاينة!", Toast.LENGTH_SHORT).show()
                        }
                    }

                    Button(
                        onClick = { showExportDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicPanelLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إلغاء", color = PlatinumWhite)
                    }
                }
            }
        }
    }

    // C. PREFERENCES DIALOG
    if (showPreferencesDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showPreferencesDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GlassBorder),
                modifier = Modifier.fillMaxWidth().padding(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("تخصيص بيئة عمل الاستوديو (Preferences)", color = GoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("حجم شبكة المحاذاة المساعدة:", color = PlatinumWhite, fontSize = 10.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(20f, 40f, 60f).forEach { g ->
                                val active = prefSnapGridSize == g
                                Box(
                                    modifier = Modifier
                                        .clickable { prefSnapGridSize = g }
                                        .background(if (active) GoldPrimary else CosmicPanelLight, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("${g.toInt()}px", color = if (active) CosmicDeepBg else PlatinumWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("لون خطوط المحاذاة الذكية (Smart Guides):", color = PlatinumWhite, fontSize = 10.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("#FF1744", "#00E676", "#2979FF", "#FFD54F").forEach { colHex ->
                                val isSelected = prefGuideColor == colHex
                                Surface(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .background(Color(android.graphics.Color.parseColor(colHex)), CircleShape)
                                        .clickable { prefGuideColor = colHex }
                                        .border(if (isSelected) 2.dp else 0.dp, PlatinumWhite, CircleShape)
                                ) {}
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("سمة الواجهة الاحترافية:", color = PlatinumWhite, fontSize = 10.sp)
                        Text(prefThemeName, color = GoldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Cosmic Dark", "Slate Slate", "Midnight Blue").forEach { thName ->
                            val active = prefThemeName == thName
                            Box(
                                modifier = Modifier
                                    .clickable { prefThemeName = thName }
                                    .background(if (active) GoldPrimary else CosmicPanelLight, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(thName, color = if (active) CosmicDeepBg else PlatinumWhite, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Button(
                        onClick = { showPreferencesDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("حفظ التخصيص والرجوع", color = CosmicDeepBg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // D. ERP PROJECT FINDER AND ACCORDION SYNCS
    if (showProjectSelectorDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showProjectSelectorDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth().padding(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("مزامنة هذا التصميم بمشروع ERP قائم مسبقاً", color = GoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("اختر العقد/المشروع للربط المباشر مع حركة التصنيع:", color = PlatinumGray, fontSize = 10.sp)

                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().height(160.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(projectsList) { p ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CosmicPanelLight, RoundedCornerShape(6.dp))
                                    .clickable {
                                        activeLinkedProject = p
                                        showProjectSelectorDialog = false
                                        showSuccessLinkDialog = true
                                    }
                                    .border(1.dp, GlassBorder, RoundedCornerShape(6.dp))
                                    .padding(10.dp)
                            ) {
                                Column {
                                    Text(p.title, color = PlatinumWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("اسم العميل: " + p.customerName + " | التقدم: " + p.status, color = PlatinumGray, fontSize = 9.sp)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { showProjectSelectorDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicPanelLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("إلغاء", color = PlatinumWhite)
                    }
                }
            }
        }
    }

    if (showSuccessLinkDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showSuccessLinkDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.5.dp, EmeraldNeon),
                modifier = Modifier.fillMaxWidth().padding(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(36.dp))
                    Text("تمت مطابقة المشروع بنجاح!", color = EmeraldNeon, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("تم ربط لوحة التصاميم المتجهة بالمقايسة المالية للمشروع: [ " + (activeLinkedProject?.title ?: "") + " ] في بيئة الفروع بنجاح.", color = PlatinumWhite, fontSize = 10.sp, textAlign = TextAlign.Center)
                    Button(
                        onClick = { showSuccessLinkDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon)
                    ) {
                        Text("موافق", color = CosmicDeepBg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // AI simulated overlay spinner
    if (showAiProcessOverlay) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GoldPrimary),
                modifier = Modifier.width(260.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    CircularProgressIndicator(color = GoldPrimary)
                    Text("توليد الذكاء الاصطناعي ...", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(aiActionLabel, color = PlatinumWhite, fontSize = 9.sp, textAlign = TextAlign.Center)
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(CosmicPanelLight, RoundedCornerShape(2.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(aiActionProgress)
                                .background(GoldPrimary, RoundedCornerShape(2.dp))
                        )
                    }
                }
            }
        }
    }
}

// Left utility side panel
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun LeftSidebarDockPanel(
    activeTab: String,
    onTabChange: (String) -> Unit,
    textInputText: String,
    onTextChange: (String) -> Unit,
    textInputSize: String,
    onSizeChange: (String) -> Unit,
    aiPrompt: String,
    onAiPromptChange: (String) -> Unit,
    luxuryPaletteColors: List<Pair<String, String>>,
    viewModel: YaftaViewModel,
    pagesList: List<List<DesignLayer>>,
    onPagesChange: (List<List<DesignLayer>>) -> Unit,
    activePageIndex: Int,
    onActivePageChange: (Int) -> Unit,
    pageNames: List<String>,
    onPageNamesChange: (List<String>) -> Unit,
    registerStateChange: (List<DesignLayer>) -> Unit,
    runSimulatedAiEngine: (String, () -> Unit) -> Unit,
    customPresetsList: List<Pair<String, Map<String, String>>>,
    recentFilesList: List<String>,
    showProjectSelectorDialog: () -> Unit,
    showNewProjectDialog: () -> Unit,
    onDockToggle: () -> Unit
) {
    val context = LocalContext.current
    Row(
        modifier = Modifier
            .fillMaxHeight()
            .width(280.dp)
            .background(CosmicPanelBg)
            .border(1.dp, GlassBorder)
    ) {
        // Vertical Tab Strip Selector
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .width(62.dp)
                .background(CosmicDeepBg)
                .border(1.dp, GlassBorder),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))
            val tabs = listOf(
                Triple("Colors", Icons.Default.Palette, "الألوان"),
                Triple("Fonts", Icons.Default.TextFields, "الخطوط"),
                Triple("Elements", Icons.Default.Category, "الأشكال"),
                Triple("AI", Icons.Default.AutoAwesome, "الذكاء"),
                Triple("Assets", Icons.Default.PhotoLibrary, "الأصول")
            )
            tabs.forEach { (tab, icon, label) ->
                val isSelected = activeTab == tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onTabChange(tab) }
                        .padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) GoldPrimary else PlatinumGray,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = label,
                        color = if (isSelected) GoldPrimary else PlatinumGray,
                        fontSize = 8.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            IconButton(onClick = onDockToggle, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.PinDrop, "Undock", tint = PlatinumGray, modifier = Modifier.size(12.dp))
            }
        }

        // Sub-panel details container
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = when(activeTab) {
                        "Colors" -> "لوحة الألوان الملكية (Colors)"
                        "Fonts" -> "لوحة طباعة العناوين (Fonts)"
                        "Elements" -> "مكتبة المتجهات الجافة (Elements)"
                        "AI" -> "محرك المظهر الاصطناعي (AI)"
                        else -> "لوحة المطبوعات والأصول (Assets)"
                    },
                    color = GoldPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            when(activeTab) {
                "Colors" -> {
                    Text("اختر اللون الحشوي أو تدرج النيون فليكس:", color = PlatinumGray, fontSize = 9.sp)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        luxuryPaletteColors.forEach { (name, hex) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable {
                                        registerStateChange(viewModel.canvasLayers)
                                        viewModel.updateSelectedLayerProperties(
                                            colorHex = hex,
                                            gradientColorStartHex = null,
                                            gradientColorEndHex = null
                                        )
                                        Toast
                                            .makeText(context, "تم تطبيق اللون $name", Toast.LENGTH_SHORT)
                                            .show()
                                    }
                                    .padding(2.dp)
                            ) {
                                Surface(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(Color(android.graphics.Color.parseColor(hex)), RoundedCornerShape(4.dp))
                                        .border(1.dp, GlassBorder, RoundedCornerShape(4.dp))
                                ) {}
                                Text(name, color = PlatinumGray, fontSize = 7.sp)
                            }
                        }
                    }

                    HorizontalDivider(color = GlassBorder)
                    Text("بناء تدرج ألوان مخصص (Gradients):", color = GoldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    
                    var gradStart by remember { mutableStateOf("#D4AF37") }
                    var gradEnd by remember { mutableStateOf("#FF1744") }
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = gradStart,
                            onValueChange = { gradStart = it },
                            label = { Text("الأول (HEX)", fontSize = 8.sp, color = PlatinumGray) },
                            modifier = Modifier.weight(1f),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 9.sp, color = PlatinumWhite)
                        )
                        OutlinedTextField(
                            value = gradEnd,
                            onValueChange = { gradEnd = it },
                            label = { Text("الثاني (HEX)", fontSize = 8.sp, color = PlatinumGray) },
                            modifier = Modifier.weight(1f),
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 9.sp, color = PlatinumWhite)
                        )
                    }

                    Button(
                        onClick = {
                            registerStateChange(viewModel.canvasLayers)
                            viewModel.updateSelectedLayerProperties(
                                gradientColorStartHex = gradStart,
                                gradientColorEndHex = gradEnd
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("تطبيق تدرج واجهات LED", color = CosmicDeepBg, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                "Fonts" -> {
                    Text("العناوين العربية والإنجليزية الفخمة:", color = PlatinumGray, fontSize = 9.sp)
                    listOf("Cairo", "Montserrat", "Dubai Amman", "Riyadh Kufic").forEach { font ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CosmicPanelLight, RoundedCornerShape(4.dp))
                                .clickable {
                                    registerStateChange(viewModel.canvasLayers)
                                    viewModel.updateSelectedLayerProperties(fontName = font)
                                }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(font, color = PlatinumWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.TextFields, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(12.dp))
                        }
                    }

                    HorizontalDivider(color = GlassBorder)
                    Text("إضافة نص أو عنوان جديد:", color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = textInputText,
                        onValueChange = onTextChange,
                        label = { Text("محتوى النص الإعلاني", fontSize = 9.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(color = PlatinumWhite, fontSize = 11.sp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            registerStateChange(viewModel.canvasLayers)
                            viewModel.addTextLayer(
                                textInputText,
                                "Cairo",
                                "#D4AF37",
                                textInputSize.toFloatOrNull() ?: 24f
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("إضافة عنوان للوحة مذهب", color = CosmicDeepBg, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                "Elements" -> {
                    Text("أشكال هندسية لتأطير الحروف:", color = PlatinumGray, fontSize = 9.sp)
                    listOf(
                        Triple("إطار مستطيل كلادينج", "Rectangle", "#D4AF37"),
                        Triple("دائرة نيون خلفية صلبة", "Circle", "#FF1744"),
                        Triple("مثلث تحذيري عاكس", "Triangle", "#FFD54F"),
                        Triple("نجمة تميز خماسية مضيئة", "Star", "#FFFF05")
                    ).forEach { (label, type, color) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CosmicPanelLight, RoundedCornerShape(4.dp))
                                .clickable {
                                    registerStateChange(viewModel.canvasLayers)
                                    viewModel.addShapeLayer(type, color)
                                }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, color = PlatinumWhite, fontSize = 10.sp)
                            Icon(Icons.Default.Category, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(12.dp))
                        }
                    }

                    HorizontalDivider(color = GlassBorder)
                    Text("أداة القلم الحر (Pen Vector):", color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("نشّط أداة القلم ثم انقر على الكانفاس بلمسات متتالية لتوليد متجهات نيون مضيئة:", color = PlatinumGray, fontSize = 8.sp)
                    Button(
                        onClick = {
                            viewModel.activeTool = if (viewModel.activeTool == "Pen") "Move" else "Pen"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (viewModel.activeTool == "Pen") RubyRed else CosmicPanelLight),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(if (viewModel.activeTool == "Pen") "تعطيل القلم (قيد الرسم)" else "تفعيل أداة القلم المتجهي Pen", color = PlatinumWhite, fontSize = 9.sp)
                    }
                }
                "AI" -> {
                    Text("توليد الذكاء الإبداعي (Gemini UI):", color = PlatinumGray, fontSize = 9.sp)
                    OutlinedTextField(
                        value = aiPrompt,
                        onValueChange = onAiPromptChange,
                        label = { Text("شعار أو وصف المحل التجاري (برجر، عيادة، فندق)", fontSize = 9.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(color = PlatinumWhite, fontSize = 10.sp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            runSimulatedAiEngine("فحص وتصميم تخطيط ألوان يافطة ذكي لـ $aiPrompt") {
                                registerStateChange(viewModel.canvasLayers)
                                viewModel.canvasLayers = listOf(
                                    DesignLayer("1", "الخلفية الداكنة الفخمة", "shape", "Rectangle", x = 0f, y = 0f, scaleX = 1000f, scaleY = 700f, colorHex = "#050505", isLocked = true),
                                    DesignLayer("2", "حلقة إضاءة خلفية نيون", "shape", "Circle", x = 200f, y = 30f, scaleX = 220f, scaleY = 220f, colorHex = "#FF1744"),
                                    DesignLayer("3", "شعار اليافطة الذكي", "image", "logo", x = 280f, y = 80f, scaleX = 0.5f, scaleY = 0.5f),
                                    DesignLayer("4", "يافطة $aiPrompt المطلوبة", "text", aiPrompt.uppercase(), x = 50f, y = 140f, fontSize = 28f, colorHex = "#D4AF37", fontName = "Cairo")
                                )
                                viewModel.selectedLayerId = "4"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        enabled = aiPrompt.isNotEmpty()
                    ) {
                        Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(12.dp), tint = CosmicDeepBg)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("توليد تصميم متكامل بالـ AI", color = CosmicDeepBg, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                else -> {
                    Text("قوالب وأصول سريعة جاهزة:", color = PlatinumGray, fontSize = 9.sp)
                    Button(
                        onClick = {
                            registerStateChange(viewModel.canvasLayers)
                            val newId = UUID.randomUUID().toString()
                            viewModel.canvasLayers = viewModel.canvasLayers + DesignLayer(
                                id = newId, name = "شعار العميل المعتد", type = "image", content = "logo", x = 110f, y = 30f
                            )
                            viewModel.selectedLayerId = newId
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicPanelLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Upload, null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("استيراد شعار PNG/SVG", fontSize = 9.sp)
                    }

                    HorizontalDivider(color = GlassBorder)
                    Text("تنظيم وتعدد تصاميم المشروع (Pages):", color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    
                    // Add Page Row
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                val nextIdx = pagesList.size
                                val newPageName = "تصميم الصفحة ${nextIdx + 1}"
                                val newPageLayers = listOf(
                                    DesignLayer("1", "الخلفية الافتراضية للوحة", "shape", "Rectangle", x = 0f, y = 0f, scaleX = 1000f, scaleY = 700f, colorHex = "#0A0A0E", isLocked = true),
                                    DesignLayer("2", "جملة الصفحة البديلة", "text", "الصفحة الإضافية الفخمة", x = 60f, y = 140f, fontSize = 21f, colorHex = "#D4AF37")
                                )
                                val updatedList = pagesList + listOf(newPageLayers)
                                onPageNamesChange(pageNames + newPageName)
                                onPagesChange(updatedList)
                                onActivePageChange(nextIdx)
                                viewModel.canvasLayers = newPageLayers
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicPanelLight),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("+ صفحة جديدة", fontSize = 9.sp)
                        }
                    }

                    // Pages Index List
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 140.dp)
                    ) {
                        itemsIndexed(pageNames) { idx, name ->
                            val isCurrent = idx == activePageIndex
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isCurrent) GoldPrimary.copy(alpha = 0.15f) else CosmicPanelLight, RoundedCornerShape(4.dp))
                                    .border(1.dp, if (isCurrent) GoldPrimary else GlassBorder, RoundedCornerShape(4.dp))
                                    .clickable {
                                        onActivePageChange(idx)
                                        viewModel.canvasLayers = pagesList[idx]
                                    }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(name, color = if (isCurrent) GoldPrimary else PlatinumWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                if (isCurrent) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(12.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Right Master PSD Layers panel
@Composable
fun RightSidebarDockPanel(
    activeTab: String,
    onTabChange: (String) -> Unit,
    viewModel: YaftaViewModel,
    registerStateChange: (List<DesignLayer>) -> Unit,
    activeLinkedProject: com.example.data.Project?,
    onLinkProject: () -> Unit,
    onDockToggle: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CosmicPanelBg),
        shape = RectangleShape,
        modifier = Modifier
            .fillMaxHeight()
            .width(280.dp)
            .border(width = 1.dp, color = GlassBorder)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CosmicDeepBg)
                    .border(1.dp, GlassBorder)
            ) {
                listOf("Layers", "Detail").forEach { tab ->
                    val isChosen = activeTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onTabChange(tab) }
                            .background(if (isChosen) CosmicPanelBg else Color.Transparent)
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (tab == "Layers") "طبقات اللوحة (PSD)" else "الربط التقني (ERP)",
                            color = if (isChosen) GoldPrimary else PlatinumGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                IconButton(onClick = onDockToggle, modifier = Modifier.size(34.dp).padding(4.dp)) {
                    Icon(Icons.Default.PinDrop, "Undock", tint = PlatinumGray, modifier = Modifier.size(12.dp))
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when(activeTab) {
                    "Layers" -> {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("الطبقات المرتبة تصاعدياً:", color = PlatinumWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(onClick = { viewModel.reorderSelectedLayer(forward = true) }, modifier = Modifier.size(24.dp), enabled = viewModel.selectedLayerId != null) {
                                    Icon(Icons.Default.ArrowUpward, null, tint = GoldPrimary, modifier = Modifier.size(12.dp))
                                }
                                IconButton(onClick = { viewModel.reorderSelectedLayer(forward = false) }, modifier = Modifier.size(24.dp), enabled = viewModel.selectedLayerId != null) {
                                    Icon(Icons.Default.ArrowDownward, null, tint = GoldPrimary, modifier = Modifier.size(12.dp))
                                }
                            }
                        }

                        viewModel.canvasLayers.reversed().forEach { layer ->
                            val isSelected = layer.id == viewModel.selectedLayerId
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isSelected) GoldPrimary.copy(alpha = 0.12f) else CosmicPanelLight, RoundedCornerShape(6.dp))
                                    .border(1.dp, if (isSelected) GoldPrimary else GlassBorder, RoundedCornerShape(6.dp))
                                    .clickable { viewModel.selectedLayerId = layer.id }
                                    .padding(6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = when(layer.type) {
                                            "text" -> Icons.Default.TextFields
                                            "shape" -> Icons.Default.Category
                                            "image" -> Icons.Default.Image
                                            else -> Icons.Default.Gesture
                                        },
                                        contentDescription = null,
                                        tint = if (isSelected) GoldPrimary else PlatinumGray,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = layer.name + if (layer.isLocked) " 🔒" else "",
                                        color = if (isSelected) GoldPrimary else PlatinumWhite,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    IconButton(
                                        onClick = {
                                            registerStateChange(viewModel.canvasLayers)
                                            viewModel.canvasLayers = viewModel.canvasLayers.map {
                                                if (it.id == layer.id) it.copy(isVisible = !it.isVisible) else it
                                            }
                                        },
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (layer.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                            contentDescription = null,
                                            tint = PlatinumGray,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            registerStateChange(viewModel.canvasLayers)
                                            viewModel.canvasLayers = viewModel.canvasLayers.map {
                                                if (it.id == layer.id) it.copy(isLocked = !it.isLocked) else it
                                            }
                                        },
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (layer.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                            contentDescription = null,
                                            tint = PlatinumGray,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("مزامنة ومتابعة الإنتاج المالي:", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("يربط هذا الاستوديو تلقائياً بين رسم المتجهات وحسابات التكلفة وسعر البيع في المقايسة المعتمدة للعميل بالمصنع.", color = PlatinumGray, fontSize = 10.sp)
                        
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CosmicPanelLight, RoundedCornerShape(8.dp))
                                .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("حالة الربط المالي:", color = PlatinumWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                if (activeLinkedProject != null) {
                                    Text("المشروع: " + activeLinkedProject.title, color = EmeraldNeon, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("حالة التنفيذ: " + activeLinkedProject.status, color = PlatinumWhite, fontSize = 9.sp)
                                    Text("العميل المعتمد: " + activeLinkedProject.customerName, color = PlatinumGray, fontSize = 9.sp)
                                } else {
                                    Text("غير متصل بمشروع ERP حالياً", color = RubyRed, fontSize = 10.sp)
                                    Button(
                                        onClick = onLinkProject,
                                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("ربط مع مشروع مالي", color = CosmicDeepBg, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PresetChip(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(CosmicPanelLight, RoundedCornerShape(6.dp))
            .border(1.dp, GlassBorder, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, color = PlatinumWhite, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ExportOptionCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CosmicPanelLight),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = GoldLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = PlatinumGray, fontSize = 8.sp)
            }
            Icon(Icons.Default.ArrowOutward, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
fun WidthLimitedPropertyField(
    label: String,
    value: String,
    width: Int,
    onValueChange: (String) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text("$label:", color = PlatinumGray, fontSize = 10.sp)
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            textStyle = androidx.compose.ui.text.TextStyle(color = PlatinumWhite, fontSize = 11.sp),
            modifier = Modifier
                .width(width.dp)
                .background(CosmicPanelBg, RoundedCornerShape(4.dp))
                .border(1.dp, GlassBorder, RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 4.dp)
        )
    }
}

// Golden Slider color based on scale
fun GoldenSliderColor(scale: Float): Color {
    return if (scale > 2.0f) RubyRed else if (scale > 1.2f) GoldLight else GoldPrimary
}

// Canva Sub-card elements
@Composable
fun CanvaAssetItemCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CosmicPanelLight),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, GlassBorder)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = PlatinumWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = PlatinumGray, fontSize = 9.sp)
            }
            Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(14.dp), tint = GoldPrimary)
        }
    }
}
