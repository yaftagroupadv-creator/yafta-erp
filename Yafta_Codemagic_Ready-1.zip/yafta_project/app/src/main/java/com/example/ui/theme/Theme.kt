package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = GoldPrimary,
    secondary = GoldSecondary,
    tertiary = PlatinumGray,
    background = CharcoalDark,
    surface = CharcoalMedium,
    onPrimary = CharcoalDark,
    onSecondary = PlatinumWhite,
    onTertiary = CharcoalLight,
    onBackground = PlatinumWhite,
    onSurface = PlatinumWhite
  )

private val LightColorScheme =
  darkColorScheme( // We default to high-premium dark styling for both modes to maintain the luxury enterprise theme
    primary = GoldPrimary,
    secondary = GoldSecondary,
    tertiary = PlatinumGray,
    background = CharcoalDark,
    surface = CharcoalMedium,
    onPrimary = CharcoalDark,
    onSecondary = PlatinumWhite,
    onTertiary = CharcoalLight,
    onBackground = PlatinumWhite,
    onSurface = PlatinumWhite
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic color to enforce luxury golden branding
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
