package com.example.data

import kotlinx.coroutines.flow.Flow

class YaftaRepository(private val dao: YaftaErpDao) {

    // --- Users ---
    val allUsers: Flow<List<User>> = dao.getAllUsers()
    suspend fun insertUser(user: User) = dao.insertUser(user)
    suspend fun deleteUser(id: Int) = dao.deleteUserById(id)

    // --- Custom Roles ---
    val allCustomRoles: Flow<List<CustomRole>> = dao.getAllCustomRoles()
    suspend fun insertCustomRole(role: CustomRole) = dao.insertCustomRole(role)
    suspend fun deleteCustomRole(roleName: String) = dao.deleteCustomRole(roleName)
    suspend fun getCustomRoleByName(roleName: String) = dao.getCustomRoleByName(roleName)

    // --- Customers ---
    val allCustomers: Flow<List<Customer>> = dao.getAllCustomers()
    suspend fun getCustomerById(id: Int) = dao.getCustomerById(id)
    suspend fun insertCustomer(customer: Customer) = dao.insertCustomer(customer)
    suspend fun updateCustomer(customer: Customer) = dao.updateCustomer(customer)
    suspend fun deleteCustomer(id: Int) = dao.deleteCustomerById(id)

    // --- Quotations ---
    val allQuotations: Flow<List<Quotation>> = dao.getAllQuotations()
    suspend fun getQuotationById(id: Int) = dao.getQuotationById(id)
    suspend fun insertQuotation(quotation: Quotation): Long = dao.insertQuotation(quotation)
    suspend fun updateQuotation(quotation: Quotation) = dao.updateQuotation(quotation)
    suspend fun deleteQuotation(id: Int) = dao.deleteQuotationById(id)

    // --- Quotation Items ---
    fun getItemsForQuotation(quotationId: Int): Flow<List<QuotationItem>> = dao.getItemsForQuotation(quotationId)
    suspend fun insertQuotationItem(item: QuotationItem) = dao.insertQuotationItem(item)
    suspend fun clearQuotationItems(quotationId: Int) = dao.deleteItemsForQuotation(quotationId)

    // --- Projects ---
    val allProjects: Flow<List<Project>> = dao.getAllProjects()
    suspend fun getProjectById(id: Int) = dao.getProjectById(id)
    suspend fun insertProject(project: Project) = dao.insertProject(project)
    suspend fun updateProject(project: Project) = dao.updateProject(project)
    suspend fun deleteProject(id: Int) = dao.deleteProjectById(id)

    // --- Design Files ---
    fun getDesignFiles(projectId: Int) = dao.getDesignFilesForProject(projectId)
    suspend fun insertDesignFile(file: DesignFile) = dao.insertDesignFile(file)
    suspend fun updateDesignFile(file: DesignFile) = dao.updateDesignFile(file)

    // --- Production Jobs ---
    val allProductionJobs: Flow<List<ProductionJob>> = dao.getAllProductionJobs()
    suspend fun getProductionJobByProject(projectId: Int) = dao.getProductionJobByProject(projectId)
    suspend fun insertProductionJob(job: ProductionJob) = dao.insertProductionJob(job)
    suspend fun updateProductionJob(job: ProductionJob) = dao.updateProductionJob(job)

    // --- Installation Jobs ---
    val allInstallationJobs: Flow<List<InstallationJob>> = dao.getAllInstallationJobs()
    suspend fun getInstallationJobByProject(projectId: Int) = dao.getInstallationJobByProject(projectId)
    suspend fun insertInstallationJob(job: InstallationJob) = dao.insertInstallationJob(job)
    suspend fun updateInstallationJob(job: InstallationJob) = dao.updateInstallationJob(job)

    // --- Inventory ---
    val allInventory: Flow<List<InventoryItem>> = dao.getAllInventoryItems()
    suspend fun insertInventoryItem(item: InventoryItem) = dao.insertInventoryItem(item)
    suspend fun updateInventoryItem(item: InventoryItem) = dao.updateInventoryItem(item)
    suspend fun deleteInventoryItem(id: Int) = dao.deleteInventoryItemById(id)

    // --- Suppliers ---
    val allSuppliers: Flow<List<Supplier>> = dao.getAllSuppliers()
    suspend fun insertSupplier(supplier: Supplier) = dao.insertSupplier(supplier)
    suspend fun updateSupplier(supplier: Supplier) = dao.updateSupplier(supplier)

    // --- Invoices ---
    val allInvoices: Flow<List<Invoice>> = dao.getAllInvoices()
    suspend fun getInvoiceById(id: Int) = dao.getInvoiceById(id)
    suspend fun insertInvoice(invoice: Invoice) = dao.insertInvoice(invoice)
    suspend fun updateInvoice(invoice: Invoice) = dao.updateInvoice(invoice)

    // --- Payments ---
    fun getPayments(invoiceId: Int) = dao.getPaymentsForInvoice(invoiceId)
    suspend fun insertPayment(payment: Payment) = dao.insertPayment(payment)

    // --- Expenses ---
    val allExpenses: Flow<List<Expense>> = dao.getAllExpenses()
    suspend fun insertExpense(expense: Expense) = dao.insertExpense(expense)

    // --- Employees ---
    val allEmployees: Flow<List<Employee>> = dao.getAllEmployees()
    suspend fun insertEmployee(employee: Employee) = dao.insertEmployee(employee)
    suspend fun updateEmployee(employee: Employee) = dao.updateEmployee(employee)

    // --- Activity Logs ---
    val allActivityLogs: Flow<List<ActivityLog>> = dao.getAllActivityLogs()
    suspend fun insertActivityLog(log: ActivityLog) = dao.insertActivityLog(log)

    // --- Notifications ---
    val allNotifications: Flow<List<Notification>> = dao.getAllNotifications()
    suspend fun insertNotification(notification: Notification) = dao.insertNotification(notification)
    suspend fun markNotificationRead(id: Int, isRead: Boolean) = dao.updateNotificationReadStatus(id, isRead)

    // --- Attachments ---
    fun getAttachments(parentType: String, parentId: Int) = dao.getAttachmentsForParent(parentType, parentId)
    suspend fun insertAttachment(attachment: AttachmentModel) = dao.insertAttachment(attachment)
}
