package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val email: String,
    val role: String, // "Admin", "Manager", "Designer", "Sales", "Inventory", "Accountant", "Employee" or custom role name
    val permissions: String = "", // Override of specific module permissions if any
    val password: String = "123456",
    val isActive: Boolean = true
)

@Entity(tableName = "custom_roles")
data class CustomRole(
    @PrimaryKey val roleName: String,
    val displayNameAr: String,
    val displayNameEn: String,
    val permissions: String // Comma separated: "customers:view,customers:add,quotations:view"
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val companyName: String = "",
    val phone: String,
    val whatsapp: String,
    val email: String,
    val address: String,
    val notes: String = "",
    val attachments: String = "", // Comma separated file paths/uris
    val history: String = "", // String log of history
    val balanceEgp: Double = 0.0
)

@Entity(tableName = "quotations")
data class Quotation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val quotationNumber: String, // e.g. QTN-2026-0001
    val customerName: String,
    val customerPhone: String,
    val date: String,
    val totalPrice: Double,
    val notes: String = "",
    val status: String = "Draft", // "Draft", "Approved", "Converted to Project"
    // Smart Measurement Fields
    val length: Double = 0.0,
    val width: Double = 0.0,
    val area: Double = 0.0,
    val materialCost: Double = 0.0,
    val laborCost: Double = 0.0,
    val productionCost: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val profit: Double = 0.0,
    val profitMargin: Double = 0.0
)

@Entity(tableName = "quotation_items")
data class QuotationItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val quotationId: Int,
    val name: String,
    val length: Double,
    val width: Double,
    val qty: Int,
    val unitPrice: Double,
    val totalPrice: Double
)

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val customerName: String,
    val customerPhone: String,
    val status: String = "Design", // "Design", "Production", "Installation", "Completed"
    val progress: Float = 0.0f,
    val startDate: String,
    val endDate: String,
    val notes: String = "",
    val quotationId: Int = 0
)

@Entity(tableName = "design_files")
data class DesignFile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val title: String,
    val filePath: String, // Path on disk/sandbox
    val version: Int = 1,
    val approvalStatus: String = "Pending", // "Pending", "Approved", "Rejected"
    val notes: String = "",
    val uploadDate: String
)

@Entity(tableName = "production_jobs")
data class ProductionJob(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val projectTitle: String,
    val materialCost: Double,
    val laborCost: Double,
    val productionCost: Double,
    val sellingPrice: Double,
    val profit: Double,
    val profitMargin: Double,
    val status: String = "Pending" // "Pending", "In Progress", "Completed"
)

@Entity(tableName = "installation_jobs")
data class InstallationJob(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val projectTitle: String,
    val teamName: String,
    val beforePhoto: String = "", // URI/path
    val afterPhoto: String = "", // URI/path
    val customerSignature: String = "", // Path to drawing bitmap
    val gpsLatitude: Double = 0.0,
    val gpsLongitude: Double = 0.0,
    val status: String = "Scheduled" // "Scheduled", "In Progress", "Installed"
)

@Entity(tableName = "inventory")
data class InventoryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val materialName: String,
    val warehouseName: String,
    val barcode: String = "",
    val qrCode: String = "",
    val quantity: Double,
    val lowStockAlertLimit: Double,
    val unit: String = "Pcs" // "Pcs", "Meters", "Sqm"
)

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val balance: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "invoices")
data class Invoice(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val invoiceNumber: String, // e.g. INV-2026-0001
    val customerName: String,
    val date: String,
    val totalPrice: Double,
    val paidAmount: Double,
    val balance: Double,
    val status: String = "Unpaid", // "Unpaid", "Partially Paid", "Paid"
    val notes: String = ""
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val invoiceId: Int,
    val amount: Double,
    val date: String,
    val paymentMethod: String // "Cash", "Bank Transfer", "Vodafone Cash"
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val amount: Double,
    val date: String,
    val category: String // "Payroll", "Suppliers", "Materials", "Rent", "Utility", "Tax (VAT)"
)

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val position: String,
    val salary: Double,
    val attendance: Int = 0, // days present this month
    val leaveRequests: Int = 0, // pending leave request count
    val status: String = "Active" // "Active", "On Leave", "Terminated"
)

@Entity(tableName = "notifications")
data class Notification(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val message: String,
    val date: String,
    val isRead: Boolean = false
)

@Entity(tableName = "activity_logs")
data class ActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userName: String,
    val action: String,
    val timestamp: String,
    val details: String = ""
)

@Entity(tableName = "attachments")
data class AttachmentModel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val parentType: String, // "Customer", "Project", "Quotation", "Inventory"
    val parentId: Int,
    val fileName: String,
    val filePath: String
)
